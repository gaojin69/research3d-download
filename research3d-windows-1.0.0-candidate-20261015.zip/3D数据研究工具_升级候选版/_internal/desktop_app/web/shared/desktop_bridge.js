(function(root){'use strict';
 const VERSION='1.0.0',CODE=13;
 function releaseText(r){if(!r||r.status!=='available'||r.platform!=='windows'||typeof r.version!=='string'||!/^\d+\.\d+\.\d+$/.test(r.version)||!Number.isSafeInteger(r.version_code)||r.version_code<1||!/^research3d-windows-[a-zA-Z0-9._-]+\.zip$/.test(r.archive_url)||!Number.isSafeInteger(r.bytes)||r.bytes<1000||r.bytes>100*1048576||!/^[a-f0-9]{64}$/.test(r.sha256))throw Error('电脑版发布信息尚未就绪，请打开下载页');const a=r.version.split('.').map(Number),b=VERSION.split('.').map(Number);if([...a,...b].some(v=>!Number.isSafeInteger(v)))throw Error('电脑版版本数字无效');let order=0;for(let i=0;i<3;i++)if(!order&&a[i]!==b[i])order=Math.sign(a[i]-b[i]);if(Math.sign(r.version_code-CODE)!==order)throw Error('电脑版版本与序号不一致');return order>0?'有电脑版新版本 '+r.version+'，请打开下载页更新':order<0?'已安装电脑版 '+VERSION+'；下载页版本较旧，无需降级':'目前已是电脑版 '+VERSION+(r.release_stage==='candidate'?' 升级候选版':' 版');}
 root.ResearchDesktopBridge={releaseText};if(typeof module==='object')module.exports={releaseText};
 if(typeof document==='undefined')return;
 const legacy=()=>document.getElementById('open-legacy-research');
 if(root.location.protocol!=='file:'){document.addEventListener('DOMContentLoaded',()=>{if(legacy())legacy().disabled=true;});return;}
 let readyResolve,readyReject;const ready=new Promise((resolve,reject)=>{readyResolve=resolve;readyReject=reject;}),timer=setTimeout(()=>readyReject(Error('桌面服务尚未就绪，请重新打开应用')),15000);ready.catch(()=>{});
 function initialized(){if(root.pywebview&&root.pywebview.api){clearTimeout(timer);readyResolve(root.pywebview.api);}}
 root.addEventListener('pywebviewready',initialized,{once:true});initialized();
 const notice=text=>{const panel=document.getElementById('feedback-panel'),note=document.getElementById('feedback-note');if(panel&&!panel.classList.contains('hidden')&&note){note.textContent=text;return;}const n=document.getElementById('toast');if(n){n.textContent=text;n.classList.remove('hidden');}};
 async function invoke(method,...args){const api=await ready;if(typeof api[method]!=='function')throw Error('桌面功能暂不可用');const result=await api[method](...args);if(!result||!result.ok)throw Error(result&&result.error||'桌面操作失败');return result.data;}
 async function reply(method,id,...args){try{const data=await invoke(method,...args);root.nativeReply(id,{ok:true,...data});}catch(e){root.nativeReply(id,{ok:false,error:e.message});}}
 let seed;
 async function anchorRow(lottery,issue){if(!seed)seed=fetch('history.json').then(r=>r.json());const baseline=(await seed)[lottery],raw=localStorage.getItem('research3d.android.v1.history.'+lottery);let current=baseline;ResearchCore.validateHistory(baseline);try{const saved=raw?JSON.parse(raw):null;if(saved)current=ResearchWorkbench.recovery.mergeCached(baseline,saved,lottery,new Date().toLocaleDateString('sv-SE',{timeZone:'Asia/Shanghai'}));}catch(e){if(e.historyConflict)throw Error('本地历史存在冲突，暂停更新');}const row=current.find(r=>r[0]===issue);if(!row)throw Error('缺少当前开奖参考，原数据保留');return {issue:row[0],date:row[1],number:row[2]};}
 root.Phone={version:()=>VERSION,versionCode:()=>CODE,supportsAutoSync:()=>true,supportsTrial:()=>true,
  update:(id,lottery,issue)=>{anchorRow(lottery,issue).then(anchor=>reply('shared_update',id,lottery,anchor)).catch(e=>root.nativeReply(id,{ok:false,error:e.message}));},
  trial:(id,lottery)=>reply('shared_trial',id,lottery),checkRelease:id=>reply('shared_release',id),
  copy:value=>{invoke('shared_copy_text',value).then(()=>notice('已复制')).catch(e=>notice(e.message));},
  export:value=>{invoke('shared_save_text',value).then(result=>notice(result?'导出完成':'已取消导出')).catch(e=>notice(e.message));},
  openDownload:()=>{invoke('open_shared_download').catch(e=>notice(e.message));},
  openTrialSource:lottery=>{invoke('open_shared_trial',lottery).catch(e=>notice(e.message));}};
 document.addEventListener('DOMContentLoaded',()=>{const n=legacy();if(n)n.onclick=async()=>{n.disabled=true;try{await invoke('open_legacy_research');}catch(e){notice(e.message);}finally{n.disabled=false;}};});
})(typeof globalThis==='object'?globalThis:this);
