// Release identity injected into both production views. Older embedders retain their own identity.
(function(root){root.ResearchBuild=Object.freeze({version:'1.0.1',code:14,channel:'candidate'});})(globalThis);
