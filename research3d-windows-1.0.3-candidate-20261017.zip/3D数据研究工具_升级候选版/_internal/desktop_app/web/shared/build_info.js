// Release identity injected into both production views. Older embedders retain their own identity.
(function(root){root.ResearchBuild=Object.freeze({version:'1.0.3',code:16,channel:'candidate'});})(globalThis);
