(function(root){'use strict';
 // Standalone legacy embedders can omit build_info; production HTML always includes it.
 const VERSION=root.ResearchBuild?root.ResearchBuild.version:'1.0.0',CODE=root.ResearchBuild?root.ResearchBuild.code:13;
 function selectionUI(){return root.ResearchSelectionUI||(typeof require==='function'?require('../android_app/assets/selection_ui.js'):null);}
 function directConditionSelection(...args){const api=selectionUI();return api?api.directConditionSelection(...args):false;}
 function enhanceSavedBase(...args){const api=selectionUI();return api?api.enhanceSavedBase(...args):false;}
 function directSelectionHints(...args){const api=selectionUI();return api?api.directSelectionHints(...args):false;}
 function releaseText(r){if(!r||r.status!=='available'||r.platform!=='windows'||typeof r.version!=='string'||!/^\d+\.\d+\.\d+$/.test(r.version)||!Number.isSafeInteger(r.version_code)||r.version_code<1||!/^research3d-windows-[a-zA-Z0-9._-]+\.zip$/.test(r.archive_url)||!Number.isSafeInteger(r.bytes)||r.bytes<1000||r.bytes>100*1048576||!/^[a-f0-9]{64}$/.test(r.sha256))throw Error('电脑版发布信息尚未就绪，请打开下载页');const a=r.version.split('.').map(Number),b=VERSION.split('.').map(Number);if([...a,...b].some(v=>!Number.isSafeInteger(v)))throw Error('电脑版版本数字无效');let order=0;for(let i=0;i<3;i++)if(!order&&a[i]!==b[i])order=Math.sign(a[i]-b[i]);if(Math.sign(r.version_code-CODE)!==order)throw Error('电脑版版本与序号不一致');return order>0?'有电脑版新版本 '+r.version+'，请打开下载页更新':order<0?'已安装电脑版 '+VERSION+'；下载页版本较旧，无需降级':'目前已是电脑版 '+VERSION+(r.release_stage==='candidate'?' 升级候选版':' 版');}
 function mountDesktopLayout(doc){
  const by=id=>doc.getElementById(id),filter=by('filter'),categories=by('condition-categories'),quick=by('quick-cards');
  if(!filter||by('desktop-workspace')||!categories||categories.children.length!==20||!quick||quick.children.length!==6)return false;
  const el=(tag,text,id)=>{const n=doc.createElement(tag);if(text!==undefined)n.textContent=text;if(id)n.id=id;return n;};
  const heading=el('div',undefined,'desktop-filter-heading'),title=el('div');
  title.append(filter.querySelector('h1'),by('condition-instructions'));heading.append(title,by('quick-flow'));
  const workspace=el('div',undefined,'desktop-workspace'),directory=el('aside',undefined,'desktop-condition-directory'),editors=el('div',undefined,'desktop-editors'),results=el('aside',undefined,'desktop-results');
  directory.setAttribute('aria-label','完整缩水条件目录');editors.setAttribute('aria-label','条件设置');results.setAttribute('aria-label','缩水结果和已选条件');
  directory.append(el('h2','全部缩水条件'));
  const search=el('input',undefined,'desktop-condition-search');search.type='search';search.placeholder='查找条件';search.setAttribute('aria-label','查找缩水条件');directory.append(search);
  const menu=el('div',undefined,'desktop-condition-links'),links=[];
  function link(label,target,readStatus){
   const button=el('button'),name=el('span',label),status=el('small');button.type='button';button.title=label;button.append(name,status);
   button.onclick=()=>{const all=by('condition-mode-all');if(all)all.click();const card=typeof target==='function'?target():target;if(!card)return;const summary=card.querySelector('summary'),details=summary&&summary.closest('details');if(details&&!details.open)summary.click();card.classList.remove('hidden');card.scrollIntoView({block:'nearest',behavior:'auto'});for(const item of links)item.button.classList.toggle('active',item.button===button);};
   menu.append(button);links.push({button,status,label,readStatus});
  }
  const catalog=root.ResearchConditions.CATALOG,group=(label,keys)=>{menu.append(el('h3',label));for(const key of keys){const index=catalog.findIndex(c=>c[0]===key);if(index<0)continue;const current=()=>categories.children[index];link(catalog[index][1],current,()=>current()?.querySelector('.condition-status')?.textContent||'');}};
  group('常用条件',['dan','kill','sum','tail','span','pattern']);
  group('数字与形态',['size','parity','prime','sorted','cyclic','bigmiddle','mod','direction','shape']);
  group('两码条件',['pairSum','pairTail','pairDiff','pairCombined','unordered']);
  menu.append(el('h3','大底与组合'));
  link('大底设置',by('workbench-base'));for(const [key,label] of Object.entries(root.ResearchWorkbench.RULES))link(label,by('quick-card-'+key),()=>by('quick-card-'+key).querySelector('.condition-status')?.textContent||'');
  const position=by('positions').closest('details'),ranges=by('ranges').closest('details'),snapshot=by('snapshot').closest('.card');
  link('百十个位定位',position,()=>by('positions').querySelector('.active')||by('pattern').value!=='all'?'已选':'未使用');link('组选间距 / 数值范围',ranges,()=>by('ranges').querySelector('button')||by('extended-gap-editor')?.querySelector('input:checked')?'已选':'未使用');link('预测带入条件',snapshot,()=>by('clear-snapshot').classList.contains('hidden')?'未使用':'已选');
  const empty=el('p','没有找到这个条件','desktop-condition-empty');empty.hidden=true;directory.append(menu,empty);
  search.oninput=()=>{const term=search.value.trim();let found=0;for(const item of links){item.button.hidden=Boolean(term&&!item.label.includes(term));if(!item.button.hidden)found++;}for(const h of menu.querySelectorAll('h3'))h.hidden=Boolean(term);empty.hidden=found>0;};
  const selected=by('filter-explanation'),numbers=by('number-panel'),actions=by('run-filter').parentElement,remaining=by('remaining');
  results.append(el('h2','缩水结果'),remaining,selected,numbers,actions);numbers.open=true;
  editors.append(by('workbench-base'),by('condition-panel-actions'),by('condition-category-nav'),categories,by('workbench-rules'),position,ranges,snapshot);
  by('quick-condition-menu').classList.add('desktop-redundant-menu');workspace.append(directory,editors,results);filter.prepend(heading);filter.append(workspace);
  const conditionJump=by('quick-flow').querySelectorAll('button')[1];if(conditionJump)conditionJump.onclick=()=>categories.scrollIntoView({block:'start',behavior:'auto'});
  quick.addEventListener('change',directConditionSelection);quick.addEventListener('input',directConditionSelection);
  function refreshBadges(){for(const item of links){const value=item.readStatus?item.readStatus():'';const selected=value&&!['未使用','未启用'].includes(value);if(item.status.textContent!==(selected?value:''))item.status.textContent=selected?value:'';item.button.classList.toggle('desktop-condition-used',Boolean(selected));}directSelectionHints(quick,doc);}
  if(typeof root.MutationObserver==='function'){const observer=new root.MutationObserver(refreshBadges);observer.observe(categories,{subtree:true,childList:true,characterData:true});observer.observe(quick,{subtree:true,childList:true,characterData:true});observer.observe(by('filter-selected'),{subtree:true,childList:true,characterData:true});}
  refreshBadges();by('condition-mode-all').click();
  return true;
 }
 function watchDesktopLayout(){
  if(typeof root.MutationObserver!=='function'||typeof root.matchMedia!=='function')return;
  const begin=()=>{if(mountDesktopLayout(document))return;const filter=document.getElementById('filter');if(!filter)return;const observer=new root.MutationObserver(()=>{if(mountDesktopLayout(document))observer.disconnect();});observer.observe(filter,{subtree:true,childList:true});};
  document.addEventListener('DOMContentLoaded',begin);
 }
 root.ResearchDesktopBridge={releaseText,mountDesktopLayout,enhanceSavedBase,directConditionSelection,directSelectionHints};if(typeof module==='object')module.exports={releaseText,mountDesktopLayout,enhanceSavedBase,directConditionSelection,directSelectionHints};
 if(typeof document==='undefined')return;
 watchDesktopLayout();
 const legacy=()=>document.getElementById('open-legacy-research');
 if(root.location.protocol!=='file:'){document.addEventListener('DOMContentLoaded',()=>{if(legacy())legacy().disabled=true;});return;}
 let readyResolve,readyReject;const ready=new Promise((resolve,reject)=>{readyResolve=resolve;readyReject=reject;}),timer=setTimeout(()=>readyReject(Error('桌面服务尚未就绪，请重新打开应用')),15000);ready.catch(()=>{});
 function initialized(){if(root.pywebview&&root.pywebview.api){clearTimeout(timer);readyResolve(root.pywebview.api);}}
 root.addEventListener('pywebviewready',initialized,{once:true});initialized();
 const notice=text=>{const panel=document.getElementById('feedback-panel'),note=document.getElementById('feedback-note');if(panel&&!panel.classList.contains('hidden')&&note){note.textContent=text;return;}const n=document.getElementById('toast');if(n){n.textContent=text;n.classList.remove('hidden');}};
 async function invoke(method,...args){const api=await ready;if(typeof api[method]!=='function')throw Error('桌面功能暂不可用');const result=await api[method](...args);if(!result||!result.ok)throw Error(result&&result.error||'桌面操作失败');return result.data;}
 async function reply(method,id,...args){try{const data=await invoke(method,...args);root.nativeReply(id,{ok:true,...data});}catch(e){root.nativeReply(id,{ok:false,error:e.message});}}
 let seed;
 async function anchorRow(lottery,issue){if(!seed)seed=fetch('history.json').then(r=>r.json());const baseline=(await seed)[lottery],raw=localStorage.getItem('research3d.android.v1.history.'+lottery);let current=baseline;ResearchCore.validateHistory(baseline);try{const saved=raw?JSON.parse(raw):null;if(saved)current=ResearchWorkbench.recovery.mergeCached(baseline,saved,lottery,new Date().toLocaleDateString('sv-SE',{timeZone:'Asia/Shanghai'}));}catch(e){if(e.historyConflict)throw Error('本地历史存在冲突，暂停更新');}const row=current.find(r=>r[0]===issue);if(!row)throw Error('缺少当前开奖参考，原数据保留');return {issue:row[0],date:row[1],number:row[2]};}
 root.Phone={version:()=>VERSION,versionCode:()=>CODE,supportsAutoSync:()=>true,supportsTrial:()=>true,
  update:(id,lottery,issue)=>{anchorRow(lottery,issue).then(anchor=>reply('shared_update',id,lottery,anchor)).catch(e=>root.nativeReply(id,{ok:false,error:e.message}));},
  trial:(id,lottery)=>reply('shared_trial',id,lottery),checkRelease:id=>reply('shared_release',id),
  copy:value=>{invoke('shared_copy_text',value).then(()=>notice('已复制')).catch(e=>notice(e.message));},
  export:value=>{invoke('shared_save_text',value).then(result=>notice(result?'导出完成':'已取消导出')).catch(e=>notice(e.message));},
  openDownload:()=>{invoke('open_shared_download').catch(e=>notice(e.message));},
  openTrialSource:lottery=>{invoke('open_shared_trial',lottery).catch(e=>notice(e.message));}};
 document.addEventListener('DOMContentLoaded',()=>{const n=legacy();if(n)n.onclick=async()=>{n.disabled=true;try{await invoke('open_legacy_research');}catch(e){notice(e.message);}finally{n.disabled=false;}};});
})(typeof globalThis==='object'?globalThis:this);
