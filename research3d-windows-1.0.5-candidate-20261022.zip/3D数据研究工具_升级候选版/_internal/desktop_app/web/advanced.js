// Desktop form adapter only. No filtering, scoring or hash algorithm here.
const advancedCatalog = {
  sitePrimeSum: {name:'质数和（网站约定）',type:'values',field:'site_prime_sum',maximum:21,supplemental:true,help:'按网站约定累加1、2、3、5、7，重复按位置计。107为8；不是数学素数定义，不改变原M2质数条件。'},
  siteCompositeSum: {name:'合数和（网站约定）',type:'values',field:'site_composite_sum',maximum:27,supplemental:true,help:'按网站约定累加0、4、6、8、9，没有这类数字时为0。947为13；与数学质合定义分开。'},
  pairDiffMin: {name:'最小两码差',type:'values',field:'pair_diff_min',maximum:9,supplemental:true,help:'百十、百个、十个三个绝对差取最小值。947的差5、2、3，最小2；007为0。'},
  pairDiffMedian: {name:'中间两码差',type:'values',field:'pair_diff_median',maximum:9,supplemental:true,help:'三个位置对绝对差排序取中间值，保留重复。947为3；007的差0、7、7，中间为7。'},
  pairDiffMax: {name:'最大两码差',type:'values',field:'pair_diff_max',maximum:9,supplemental:true,help:'三个位置对绝对差取最大值，等于最大数字减最小数字。947为5，000为0。'},
  weightedSum: {name:'位积和',type:'values',field:'weighted_sum',maximum:54,supplemental:true,help:'百位×1＋十位×2＋个位×3，按原位置计算。527为5＋4＋21=30；725为26。'},
  weightedTail: {name:'位积合',type:'values',field:'weighted_tail',maximum:9,supplemental:true,help:'位积和取个位。527位积和30，位积合0；不是三个数字相乘，也不是普通和值尾。'},
  dan: {name:'胆码', type:'dan', help:'选择一组胆码及恰好出现个数，可添加最多12组。算一次按不同数字计数；算几次按三个位置计数。002含胆码02：算一次为2，算几次为3。'},
  size: {name:'大小形态', type:'partition', scheme:'size', symbols:{S:'小',B:'大'}, help:'小号0–4，大号5–9；按百十个位顺序选择形态。527为大小大。'},
  parity: {name:'单双形态', type:'partition', scheme:'parity', symbols:{E:'双',O:'单'}, help:'双号02468，单号13579；0是双号。527为单双单。'},
  prime: {name:'质合形态（网站口径）', type:'partition', scheme:'site_prime', symbols:{P:'质',C:'合'}, help:'网站习惯：12357为质、04689为合，不是数学素数，也不替换M2质数口径。123为质质质。'},
  sorted: {name:'最数', type:'sorted', help:'将三个数字从小到大排列，保留重复数字。007的最小数0、中间数0、最大数7。'},
  bigmiddle: {name:'大中小形态', type:'partition', scheme:'threeway', symbols:{S:'小',M:'中',B:'大'}, help:'小012，中3456，大789；按百十个位排列。527为中小大。'},
  mod: {name:'012路形态', type:'partition', scheme:'mod', symbols:{0:'0路',1:'1路',2:'2路'}, help:'数字除3的余数：0路0369、1路147、2路258。527为221路。'},
  sum: {name:'和值多选', type:'values', field:'sum', maximum:27, help:'三个数字相加，0–27；选择多个值为满足其中任意一个。007和值为7。'},
  tail: {name:'和值尾多选', type:'values', field:'tail', maximum:9, help:'和值的个位，0–9。527和值14，和值尾4。'},
  span: {name:'跨度多选', type:'values', field:'span', maximum:9, help:'最大数字减最小数字。527跨度为5；可选择非连续多个值。'},
  bigSum: {name:'大数和', type:'values', field:'big_sum', maximum:27, extended:true, help:'只累加5–9的大数字，重复按位置计；没有大数字时为0。527大数和为12。'},
  smallSum: {name:'小数和', type:'values', field:'small_sum', maximum:12, extended:true, help:'只累加0–4的小数字，重复按位置计；没有小数字时为0。527小数和为2。'},
  oddSum: {name:'奇数和', type:'values', field:'odd_sum', maximum:27, extended:true, help:'只累加1、3、5、7、9；没有奇数时为0。527奇数和为12。'},
  evenSum: {name:'偶数和', type:'values', field:'even_sum', maximum:24, extended:true, help:'只累加0、2、4、6、8；没有偶数时为0。527偶数和为2，000也为0。'},
  pairSumMin: {name:'最小两码和', type:'values', field:'pair_sum_min', maximum:18, extended:true, help:'取百十、百个、十个三个和值的最小值；重复数字仍参与。947三对和值13、16、11，最小为11。'},
  pairSumMedian: {name:'中间两码和', type:'values', field:'pair_sum_median', maximum:18, extended:true, help:'将三个位置对的和值排序，取中间值，保留重复。947为13；007三对和值0、7、7，中间为7。'},
  pairSumMax: {name:'最大两码和', type:'values', field:'pair_sum_max', maximum:18, extended:true, help:'取三个位置对和值的最大值。947为16；999为18。'},
  groupGap: {name:'组选间距', type:'values', field:'group_gap', maximum:9, extended:true, help:'三位先排序a≤b≤c，取a+(9−c)、b−a、c−b三项的最大值。527排序257，三项4、3、2，组选间距4；这是0–9边界口径，不是模10环形间距。'},
  groupHeadGap: {name:'组选首间距', type:'values', field:'group_head_gap', maximum:9, extended:true, help:'三位排序后的最小数字与0的距离。527排序257，首间距2。重复数字不删除。'},
  groupTailGap: {name:'组选尾间距', type:'values', field:'group_tail_gap', maximum:9, extended:true, help:'9减去三位排序后的最大数字。527排序257，尾间距2。'},
  groupGapFirst: {name:'组选第一间距', type:'values', field:'group_gap_first', maximum:9, extended:true, help:'首间距加尾间距，即最小数字+(9−最大数字)。527为4；000为9。'},
  groupGapSecond: {name:'组选第二间距', type:'values', field:'group_gap_second', maximum:9, extended:true, help:'排序后中间数字减最小数字。527排序257，第二间距3；007为0。'},
  groupGapThird: {name:'组选第三间距', type:'values', field:'group_gap_third', maximum:9, extended:true, help:'排序后最大数字减中间数字。527排序257，第三间距2；007为7。'},
  cyclic: {name:'环形连号', type:'cyclic', help:'0表示无连、2表示二连、3表示三连；09首尾相连，019及890为三连。重复数字不算两种数字。与原有连号条件独立。'},
  pairSum: {name:'两码和', type:'pair_sum', maximum:18, help:'所选两个位置相加，0–18。527百十和7、百个和12、十个和9。任意位置为三对中至少一对符合。'},
  pairTail: {name:'两码和尾', type:'pair_tail', maximum:9, help:'所选两码和值的个位，0–9。527百个和尾2。'},
  pairDiff: {name:'两码差', type:'pair_diff', maximum:9, help:'所选两码的绝对差，0–9。527百个差2；不区分相减顺序。'},
  pairCombined: {name:'两码合差（或）', type:'pair_combined', maximum:9, help:'桌面明确口径：同一所选位置对，两码和尾或绝对差任一个落在选值内即可。不是同时满足，未声称与外部工具内部算法完全一致。'},
  unordered: {name:'不定位两码', type:'unordered', help:'不考虑位置，仍保留重复次数；22需要两个2。多对可选任一或全部包含。527包含25、27、57。'},
  direction: {name:'走势（手动参考）', type:'direction', symbols:{U:'升',D:'降',P:'平'}, help:'逐位置对比明确填写的三位参考号码。参考527，候选637为升升平。不自动取最新开奖，不支持历史回测；参考号码与彩种一起保存。'},
  concave: {name:'凹凸形态（严格口径）', type:'shape', help:'凹：十位严格小于两侧；凸：十位严格大于两侧；上升/下降为三位严格递增/递减；平行为三位相同。其余含相等边界归“边界”。527为凹、007为边界。'},
};
let advancedEditIndex = null;
let advancedInitialized = false;
const advancedRange = n => Array.from({length:n+1}, (_,i)=>i);
const advancedSelect = (key, title, values) => `<label>${title}<select id="adv-${key}">${values.map(([v,t])=>`<option value="${v}">${t}</option>`).join('')}</select></label>`;
const advancedChoices = (key, title, values) => `<fieldset><legend>${title}（可多选）</legend><div class="advanced-choices">${values.map(([v,t],i)=>`<label for="adv-${key}-${i}"><input type="checkbox" id="adv-${key}-${i}" data-adv="${key}" value="${v}">${t}</label>`).join('')}</div></fieldset>`;

function advancedPatterns(symbols) {
  const keys=Object.keys(symbols);
  return keys.flatMap(a=>keys.flatMap(b=>keys.map(c=>[a+b+c, `${symbols[a]}${symbols[b]}${symbols[c]}`])));
}

function openAdvancedCategory(key, scroll=true) {
  if (!Object.hasOwn(advancedCatalog,key)) return false;
  const c=advancedCatalog[key];
  $('#advanced-kind').value=key;
  advancedEditIndex=null;
  $('#advanced-add').textContent='添加条件';
  $('#advanced-cancel').hidden=true;
  let fields='';
  const numberChoices=(key,title,max)=>advancedChoices(key,title,advancedRange(max).map(n=>[n,n]));
  if(c.type==='dan') fields=numberChoices('digits','胆码数字',9)+advancedSelect('count_mode','计数方式',[['distinct','算一次（不同数字）'],['occurrences','算几次（按位置）']])+numberChoices('counts','恰好出现个数',3);
  else if(c.type==='partition' || c.type==='direction') {
    if(c.type==='direction') fields='<label>手动参考号码 <input id="adv-reference" maxlength="3" inputmode="numeric" placeholder="例如007"></label>';
    fields+=advancedChoices('patterns','位置形态',advancedPatterns(c.symbols));
  } else if(c.type==='sorted') fields=advancedSelect('rank','取哪个数字',[['min','最小数'],['median','中间数'],['max','最大数']])+numberChoices('values','保留数字',9);
  else if(c.type.startsWith('pair_')) fields=advancedSelect('pair','位置对',[['ht','百十'],['hu','百个'],['tu','十个'],['any','任意位置对（至少一对）']])+numberChoices('values','保留值',c.maximum);
  else if(c.type==='unordered') fields=advancedSelect('mode','多对组合',[['any','包含任意一对'],['all','包含全部所选对']])+advancedChoices('pairs','两码',advancedRange(9).flatMap(a=>advancedRange(9).filter(b=>b>=a).map(b=>[`${a}${b}`,`${a}${b}`])));
  else if(c.type==='cyclic') fields=advancedChoices('values','连号类别',[[0,'无连'],[2,'二连'],[3,'三连']]);
  else if(c.type==='shape') fields=advancedChoices('values','形态',[['concave','凹'],['convex','凸'],['ascending','上升'],['descending','下降'],['parallel','平行'],['boundary','相等边界']]);
  else fields=numberChoices('values','保留值',c.maximum);
  $('#advanced-fields').innerHTML=fields;
  $('#advanced-help').innerHTML=`<strong>说明与例子 · ${escapeHtml(c.name)}</strong><p>${escapeHtml(c.help)}</p>`;
  if(scroll) $('#advanced-editor').scrollIntoView?.({behavior:'smooth',block:'center'});
  return true;
}

function advancedFormRule() {
  const c=advancedCatalog[$('#advanced-kind').value];
  if(!c) throw new Error('请选择条件分类。');
  const choices=(key, numeric=false)=>{
    const values=$$(`[data-adv="${key}"]:checked`).map(e=>numeric?Number(e.value):e.value);
    if(!values.length) throw new Error('请至少选择一个取值后再添加条件。');
    return values;
  };
  let p;
  if(c.type==='dan') p={digits:choices('digits',true),counts:choices('counts',true),count_mode:$('#adv-count_mode').value};
  else if(c.type==='partition') p={scheme:c.scheme,patterns:choices('patterns')};
  else if(c.type==='sorted') p={rank:$('#adv-rank').value,values:choices('values',true)};
  else if(c.type==='values') p={field:c.field,values:choices('values',true)};
  else if(c.type==='cyclic') p={values:choices('values',true)};
  else if(c.type.startsWith('pair_')) p={pair:$('#adv-pair').value,values:choices('values',true)};
  else if(c.type==='unordered') p={mode:$('#adv-mode').value,pairs:choices('pairs')};
  else if(c.type==='direction') {
    if(!/^[0-9]{3}$/.test($('#adv-reference').value)) throw new Error('参考号码必须为三位，例如007。');
    p={reference:$('#adv-reference').value,lottery_type:state.lotteryType,patterns:choices('patterns')};
  } else p={values:choices('values')};
  return {type:c.type,params:p};
}

function advancedRuleName(rule) {
  if(rule.type==='forecast')return `AI${rule.params.snapshot.forecast_sections.sections.find(r=>r.key===rule.params.section).label}固定快照`;
  const c=Object.values(advancedCatalog).find(c=>c.type===rule.type && (rule.type!=='partition'||c.scheme===rule.params.scheme) && (rule.type!=='values'||c.field===rule.params.field));
  return c?.name || '未知条件';
}

function advancedRuleText(rule) {
  const p=rule.params;
  if(rule.type==='forecast'){
    const s=p.snapshot,row=s.forecast_sections.sections.find(r=>r.key===p.section);
    return `${row.items.map(item=>item.number).join(' ')} · 截点${s.data_cutoff_issue} / ${s.data_cutoff_date} · ${row.basis} · 固定条件回放不能当成AI预测成绩。`;
  }
  const c=Object.values(advancedCatalog).find(c=>c.name===advancedRuleName(rule));
  const translate=v=>c?.symbols ? [...v].map(s=>c.symbols[s]).join('') : ({concave:'凹',convex:'凸',ascending:'上升',descending:'下降',parallel:'平行',boundary:'相等边界'}[v] || v);
  if(rule.type==='dan') return `数字${p.digits.join('、')} · ${p.count_mode==='distinct'?'算一次':'算几次'} · 恰好${p.counts.join('或')}个`;
  if(rule.type==='direction') return `手动参考${p.reference}（${p.lottery_type}） · ${p.patterns.map(translate).join(' / ')} · 不可回测`;
  if(rule.type==='partition') return p.patterns.map(translate).join(' / ');
  if(rule.type==='unordered') return `${p.mode==='all'?'全部':'任一'}包含${p.pairs.join('、')}`;
  return `${p.rank?{min:'最小',median:'中间',max:'最大'}[p.rank]+'数 · ':''}${p.pair?{ht:'百十',hu:'百个',tu:'十个',any:'任意位置对'}[p.pair]+' · ':''}${p.values.map(translate).join('、')}`;
}

function renderAdvancedRules() {
  if(!$('#advanced-rules')) return;
  advancedEditIndex=null;
  if($('#advanced-cancel')) $('#advanced-cancel').hidden=true;
  if($('#advanced-add')) $('#advanced-add').textContent='添加条件';
  $('#advanced-rules').innerHTML=state.advancedRules.length ? state.advancedRules.map((r,i)=>`<article class="advanced-rule"><div><strong>${i+1}. ${escapeHtml(advancedRuleName(r))}</strong><p>${escapeHtml(advancedRuleText(r))}</p></div>${r.type==='forecast'?'':`<button data-advanced-edit="${i}" aria-label="编辑条件${i+1}">编辑</button>`}<button data-advanced-remove="${i}" aria-label="移除条件${i+1}">移除</button></article>`).join('') : '<p class="muted">尚未添加分类条件；上方原有条件仍可使用。</p>';
  if(typeof renderForecastConditions==='function')renderForecastConditions();
  if (typeof syncConditionRows === 'function') syncConditionRows();
}

function addAdvancedRule(rule=advancedFormRule()) {
  const replacing=advancedEditIndex!==null;
  if(!replacing && state.advancedRules.length>=32) throw new Error('最多添加32项分类条件。');
  const next=JSON.parse(JSON.stringify(state.advancedRules));
  if(replacing) next[advancedEditIndex]=rule; else next.push(rule);
  if(next.filter(r=>r.type==='dan'||r.type==='forecast'&&r.params.section==='dan').length>12) throw new Error('胆码最多12组。');
  state.advancedRules=next;
  renderAdvancedRules(); updateConditionSummary();
  $('#advanced-status').textContent=`已添加${next.length}项。请“立即筛选”或等待自动预览；每项旁边可编辑或移除。`;
}

function editAdvancedRule(index) {
  const r=state.advancedRules[index]; if(!r) return;
  const entry=Object.entries(advancedCatalog).find(([,c])=>c.name===advancedRuleName(r));
  if(!entry) return;
  openAdvancedCategory(entry[0]);
  for(const [key,value] of Object.entries(r.params)) {
    if(Array.isArray(value)) $$(`[data-adv="${key}"]`).forEach(e=>{e.checked=value.map(String).includes(e.value);});
    else if($(`#adv-${key}`)) $(`#adv-${key}`).value=value;
  }
  advancedEditIndex=index; $('#advanced-add').textContent='确认修改'; $('#advanced-cancel').hidden=false;
}

async function saveHomeCandidates() {
  if (busy.pending.has($('#home-save'))) return;
  const lottery=state.lotteryType, prediction=state.predictions[lottery];
  if(!state.predictionReady[lottery] || prediction?.lottery_type!==lottery || !validNumbers(prediction.numbers) || !prediction.numbers.length) { toast('请先生成当前彩种有效候选。'); return; }
  if(state.planMutation) { toast('方案操作进行中，请稍后再保存候选。'); return; }
  if((conditionCount() || state.loadedPlan) && !window.confirm('将建立这组候选的新方案，替换工作台未保存的编辑。已保存方案不受影响。是否继续？')) return;
  await busy($('#home-save'), async()=>{
    state.loadedPlan=null; resetWorkbench();
    $('#sum-enabled').checked=true; $('#sum-min').value=0; $('#sum-max').value=27;
    selectSource('prediction'); updateConditionSummary(); selectPage('workbench');
    const pending=evaluate();
    const revision=state.revision, identity=conditionId(), nameRevision=state.planNameRevision;
    await pending;
    if(state.lotteryType!==lottery || state.predictions[lottery]!==prediction || state.revision!==revision
      || conditionId()!==identity || state.planNameRevision!==nameRevision || !hasValidResult()) return;
    if(state.numbers.length!==prediction.numbers.length || [...state.numbers].sort().join(',')!==[...prediction.numbers].sort().join(',')) throw new Error('候选保存结果不一致，已停止。');
    $('#plan-name').value=`${state.lotteryLabel}_${prediction.data_cutoff_issue}_候选${prediction.numbers.length}`;
    openPlanSave();
  });
}

function initializeAdvancedUI() {
  if(advancedInitialized || !$('#advanced-kind')) return;
  advancedInitialized=true;
  if($('#supplemental-condition-tools')) {
    $('#supplemental-condition-tools').innerHTML=Object.entries(advancedCatalog).filter(([,c])=>c.supplemental).map(([key,c])=>`<button type="button" data-supplemental-category="${key}">${escapeHtml(c.name)}</button>`).join('');
    $('#supplemental-condition-tools').addEventListener('click',e=>{
      const button=e.target.closest('[data-supplemental-category]');
      if(!button || !advancedCatalog[button.dataset.supplementalCategory]?.supplemental)return;
      if(typeof openConditionRow==='function')openConditionRow(button.dataset.supplementalCategory);
      else openAdvancedCategory(button.dataset.supplementalCategory);
    });
  }
  if($('#extended-condition-tools')) {
    $('#extended-condition-tools').innerHTML=Object.entries(advancedCatalog).filter(([,c])=>c.extended).map(([key,c])=>`<button type="button" data-extended-category="${key}">${escapeHtml(c.name)}</button>`).join('');
    $('#extended-condition-tools').addEventListener('click',e=>{
      const button=e.target.closest('[data-extended-category]');
      if(button && Object.hasOwn(advancedCatalog,button.dataset.extendedCategory)) {
        if(typeof openConditionRow !== 'function' || !openConditionRow(button.dataset.extendedCategory)) openAdvancedCategory(button.dataset.extendedCategory);
      }
    });
  }
  $('#advanced-kind').innerHTML=Object.entries(advancedCatalog).map(([key,c])=>`<option value="${key}">${c.name}</option>`).join('');
  $('#advanced-kind').addEventListener('change',()=>openAdvancedCategory($('#advanced-kind').value));
  $('#advanced-add').addEventListener('click',()=>{try{addAdvancedRule();}catch(e){toast(errorMessage(e));}});
  $('#advanced-cancel').addEventListener('click',()=>openAdvancedCategory($('#advanced-kind').value));
  $('#advanced-rules').addEventListener('click',e=>{
    const edit=e.target.closest('[data-advanced-edit]'), remove=e.target.closest('[data-advanced-remove]');
    if(edit) editAdvancedRule(Number(edit.dataset.advancedEdit));
    if(remove) {state.advancedRules.splice(Number(remove.dataset.advancedRemove),1); renderAdvancedRules();updateConditionSummary();}
  });
  const aliases={big:'size',odd:'parity',consecutive:'cyclic'};
  $$('.toolbox [data-category]').forEach(button=>{
    const key=aliases[button.dataset.category] || button.dataset.category;
    if(!advancedCatalog[key]) return;
    button.textContent=advancedCatalog[key].name;button.classList.remove('pending-tool');
    button.addEventListener('click',e=>{e.stopImmediatePropagation();if(typeof openConditionRow !== 'function' || !openConditionRow(key)) openAdvancedCategory(key);},true);
  });
  $('.pending-conditions').hidden=true;
  $('.toolbox > p').textContent='点击分类，选择取值并添加；原有条件与分类条件共同参与AND / OR / 至少满足组合。';
  $('#home-save')?.addEventListener('click',saveHomeCandidates);
  openAdvancedCategory('dan', false); renderAdvancedRules();
  if (typeof initializeConditionRows === 'function') initializeConditionRows();
}
