const state = {
  lotteryType: 'FC3D',
  lotteryLabel: '福彩3D',
  source: 'all',
  digits: {hundreds: new Set(), tens: new Set(), units: new Set()},
  digitModes: {hundreds: 'keep', tens: 'keep', units: 'keep'},
  numbers: [],
  advancedRules: [],
  resultContext: null,
  revision: 0,
  requests: {},
  loadedPlan: null,
  planNameRevision: 0,
  predictions: {},
  predictionReady: {FC3D: false, PL3: false},
  drawsPage: 1,
  drawsPages: 1,
  drawsFilters: {issue: "", dateFrom: "", dateTo: ""},
  backtestRun: null,
  backtestPage: 1,
  backtestPages: 1,
  backtestLoading: false,
  backtestTotal: 0,
  syncEnabled: false,
  syncRevision: null,
  syncRequest: 0,
};

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

function toast(message) {
  const element = $('#toast');
  element.textContent = message;
  element.classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => element.classList.remove('show'), 2200);
}

async function api(name, ...args) {
  if (!window.pywebview?.api) throw new Error('本地服务尚未就绪，请稍后重试。');
  const result = await window.pywebview.api[name](...args);
  if (!result?.ok) throw new Error(result?.error || '操作失败');
  return result.data;
}

async function busy(button, work) {
  const text = button?.textContent;
  const previous = button && busy.operations.get(button);
  const operation = {text: previous ? previous.text : text, disabled: previous ? previous.disabled : button?.disabled};
  if (button) busy.operations.set(button, operation);
  if (button) { busy.pending.add(button); button.setAttribute?.('aria-busy', 'true'); }
  if (button) { button.disabled = true; button.textContent = '处理中…'; }
  try { return await work(); }
  catch (error) { toast(errorMessage(error)); }
  finally {
    if (button && busy.operations.get(button) === operation) {
      busy.pending.delete(button);
      busy.operations.delete(button);
      button.disabled = operation.disabled;
      button.textContent = operation.text;
      button.removeAttribute?.('aria-busy');
      updateResultActions();
      if(typeof updateForwardSeal==='function')updateForwardSeal();
      if(typeof updateForecastExport==='function')updateForecastExport();
    }
  }
}
busy.pending = new Set();
busy.operations = new Map();

function errorMessage(error) {
  const message = error?.message || String(error);
  if (/connect|connection|OperationalError|psycopg|拒绝|数据库/i.test(message)) {
    return '本机数据库暂时不可连接，请检查 PostgreSQL 服务和现有连接配置后重试。';
  }
  return /[\u4e00-\u9fff]/.test(message) ? message : '本地操作失败，请重试；若仍失败，请联系维护人员检查日志。';
}

function beginRequest(name) {
  const request = {lottery: state.lotteryType, id: (state.requests[name] || 0) + 1};
  state.requests[name] = request.id;
  return request;
}

function currentRequest(name, request) {
  return request.lottery === state.lotteryType && request.id === state.requests[name];
}

function emptyView(selector, message) {
  $(selector).innerHTML = `<div class="empty-state">${escapeHtml(message)}</div>`;
}

// UI identity only: this identifier is NOT the frozen M2 result hash.
function conditionId() { return JSON.stringify(buildPayload()); }

function sourceVersion() {
  return state.source === 'all' ? 'static-universe-000-999' : state.predictions[state.lotteryType]?.result_hash;
}

function hasValidResult() {
  const context = state.resultContext;
  try {
    return context?.validity === 'valid' && context.lottery_type === state.lotteryType
      && context.source === state.source && context.condition_id === conditionId()
      && context.data_version === sourceVersion();
  } catch (_) { return false; }
}

function updateResultActions() {
  const enabled = hasValidResult() && state.numbers.length > 0;
  $('#copy-button').disabled = !enabled || busy.pending.has($('#copy-button'));
  $('#save-button').disabled = !enabled || busy.pending.has($('#save-button'));
  const planButton = $('#result-plan-save');
  if (planButton) planButton.disabled = !enabled;
}

function openPlanSave() {
  if (!hasValidResult() || !state.numbers.length) { toast('结果已过期或为空，请重新筛选后保存。'); return; }
  const drawer = $('.plan-drawer');
  drawer.open = true;
  drawer.scrollIntoView?.({behavior:'smooth',block:'start'});
  $('#plan-name').focus?.();
  $('#plan-status').textContent = '填写方案名称后点“保存新方案”；已有方案可覆盖保存为新版本。';
}

function invalidateResult(message = '条件已改变，请重新筛选。') {
  stopPreview();
  state.revision += 1;
  if (state.resultContext) state.resultContext = {...state.resultContext, validity: 'expired'};
  state.numbers = [];
  state.resultDetails = [];
  state.playBetCounts = null;
  if (typeof updateCostEstimate === 'function') updateCostEstimate();
  $('#result-count').textContent = '—';
  const betCounts = $('#play-bet-counts');
  if (betCounts) betCounts.textContent = '实际玩法注数：等待重新筛选';
  $('#result-subtitle').textContent = message;
  $('#result-status').textContent = '结果无效 · 请重新筛选';
  $('#result-hash').textContent = '尚无当前有效结果 Hash';
  $('#summary-retained').textContent = '—';
  $('#summary-source').textContent = state.source === 'all' ? '1000' : state.predictions[state.lotteryType]?.candidate_count ?? '—';
  $('#summary-reduction').textContent = '—';
  $('#result-progress').style.width = '0';
  emptyView('#number-grid', message);
  updateResultActions();
}

function validNumbers(numbers) {
  return Array.isArray(numbers) && numbers.every(number => typeof number === 'string' && /^\d{3}$/.test(number))
    && new Set(numbers).size === numbers.length;
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>'"]/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[char]));
}

function ratio(value, digits = 2) {
  return value == null || !Number.isFinite(Number(value)) ? '—' : `${(Number(value) * 100).toFixed(digits)}%`;
}

function numberValue(value, digits = 3) {
  return value == null || !Number.isFinite(Number(value)) ? '—' : Number(value).toFixed(digits);
}

function makeDigitButtons() {
  $$('.digit-row').forEach(row => {
    const position = row.dataset.position;
    for (let digit = 0; digit <= 9; digit += 1) {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'digit-button';
      button.textContent = digit;
      button.addEventListener('click', () => {
        togglePositionDigit(position, digit);
      });
      row.append(button);
    }
  });
  $$('[data-digit-mode]').forEach(select => select.addEventListener('change', () => {
    if (!['keep', 'exclude'].includes(select.value)) return;
    state.digitModes[select.dataset.digitMode] = select.value;
    renderPositionButtons();
    updateConditionSummary();
  }));
  $$('[data-digit-clear]').forEach(button => button.addEventListener('click', () => {
    state.digits[button.dataset.digitClear].clear();
    renderPositionButtons(); updateConditionSummary();
  }));
  renderPositionButtons();
}

function togglePositionDigit(position, digit) {
  if (!Object.hasOwn(state.digits, position) || !Number.isInteger(digit) || digit < 0 || digit > 9) return;
  const selected = state.digits[position];
  if (state.digitModes[position] === 'exclude') {
    // UI-only complement. The saved form and existing M2 AST keep actual allowed digits.
    const allowed = selected.size ? new Set(selected) : new Set(Array.from({length: 10}, (_, i) => i));
    if (allowed.has(digit)) {
      if (allowed.size === 1) { toast('这个位置至少需要保留1个数字，不能全部排除。'); return; }
      allowed.delete(digit);
    } else allowed.add(digit);
    state.digits[position] = allowed;
  } else if (selected.has(digit)) selected.delete(digit);
  else selected.add(digit);
  renderPositionButtons(); updateConditionSummary();
}

function renderPositionButtons() {
  $$('.digit-row').forEach(row => {
    const position = row.dataset.position;
    const exclude = state.digitModes[position] === 'exclude';
    const allowed = state.digits[position];
    [...row.children].forEach(button => {
      const marked = exclude ? allowed.size > 0 && !allowed.has(Number(button.textContent)) : allowed.has(Number(button.textContent));
      button.classList.toggle('selected', marked);
      button.classList.toggle('excluded', exclude && marked);
      button.setAttribute?.('aria-pressed', String(marked));
      button.title = `${exclude ? '排除' : '保留'}数字${button.textContent}${marked ? '（已选）' : ''}`;
    });
  });
  $$('[data-digit-mode]').forEach(select => { select.value = state.digitModes[select.dataset.digitMode]; });
  renderConditionDescription();
}

function renderConditionDescription() {
  const output = $('#condition-description');
  if (!output) return;
  const names = {hundreds: '百位', tens: '十位', units: '个位'};
  const descriptions = [];
  for (const [position, values] of Object.entries(state.digits)) {
    if (!values.size) continue;
    const exclude = state.digitModes[position] === 'exclude';
    const digits = exclude ? Array.from({length: 10}, (_, i) => i).filter(i => !values.has(i)) : [...values].sort((a,b) => a-b);
    descriptions.push(digits.length ? `${names[position]}${exclude ? '排除' : '保留'} ${digits.join('、')}` : `${names[position]}保留全部数字`);
  }
  const patterns = $$('input[name=pattern]:checked').map(input => ({baozi:'豹子',group3:'组三',group6:'组六'})[input.value]);
  if (patterns.length) descriptions.push(`保留${patterns.join('、')}`);
  if ($('#sum-enabled').checked) descriptions.push(`和值 ${$('#sum-min').value}–${$('#sum-max').value}`);
  if ($('#span-enabled').checked) descriptions.push(`跨度 ${$('#span-min').value}–${$('#span-max').value}`);
  const advanced = Object.keys(featureFilters).filter(key => $(`#feature-${key}-enabled`).checked).length;
  if (advanced) descriptions.push(`另有${advanced}项高级条件`);
  if (state.advancedRules.length) descriptions.push(`新增${state.advancedRules.length}项分类条件（见下方已添加列表）`);
  output.textContent = descriptions.length ? descriptions.join('；') : '尚未设置条件。先点选数字或启用范围；未设置的位置不限制。';
}

// Serialized raw form snapshots are immutable and also retain invalid/blank edits.
// AST remains derived by the existing buildPayload / M2 adapter on evaluation.
const featureFilters = {odd_count: 3, even_count: 3, big_count: 3, small_count: 3,
  mod0_count: 3, mod1_count: 3, mod2_count: 3, sum_tail: 9, repeat_count: 2, has_consecutive: null};
function featurePayload() {
  const features = {};
  for (const [key, maximum] of Object.entries(featureFilters)) {
    if (!$(`#feature-${key}-enabled`).checked) continue;
    const raw = $(`#feature-${key}`).value;
    if (maximum === null) {
      if (!['true', 'false'].includes(raw)) throw new Error('连号必须选择有或无。');
      features[key] = raw === 'true';
    } else {
      if (!raw.trim() || !Number.isInteger(Number(raw)) || Number(raw) < 0 || Number(raw) > maximum) throw new Error('特征条件数值无效。');
      features[key] = Number(raw);
    }
  }
  return features;
}
const workbenchHistory = {entries: [], cursor: -1, restoring: false};
function workbenchSnapshot() {
  return JSON.stringify({source: state.source,
    ...(typeof conditionRowsSnapshot === 'function' && conditionRowsSnapshot() ? {conditionRows: conditionRowsSnapshot()} : {}),
    ...(state.advancedRules.length ? {advancedRules: state.advancedRules} : {}),
    digitModes: {...state.digitModes},
    digits: Object.fromEntries(Object.entries(state.digits).map(([key, values]) => [key, [...values].sort((a,b) => a-b)])),
    patterns: $$('input[name=pattern]:checked').map(input => input.value),
    fields: Object.fromEntries(['sum-enabled', 'span-enabled', 'sum-min', 'sum-max',
      'span-min', 'span-max', 'logic-select', 'min-matches', ...Object.keys(featureFilters).flatMap(key => [`feature-${key}-enabled`, `feature-${key}`])].map(id =>
        [id, id.endsWith('-enabled') ? $(`#${id}`).checked : String($(`#${id}`).value)]))});
}
function updateHistoryActions() {
  const undo = $('#undo-button'), redo = $('#redo-button');
  if (undo) undo.disabled = workbenchHistory.cursor <= 0;
  if (redo) redo.disabled = workbenchHistory.cursor >= workbenchHistory.entries.length - 1;
}
function resetWorkbenchHistory() {
  workbenchHistory.entries = [workbenchSnapshot()];
  workbenchHistory.cursor = 0;
  updateHistoryActions();
}
function recordWorkbenchHistory() {
  if (workbenchHistory.restoring) return;
  const snapshot = workbenchSnapshot();
  if (snapshot !== workbenchHistory.entries[workbenchHistory.cursor]) {
    workbenchHistory.entries.splice(workbenchHistory.cursor + 1);
    workbenchHistory.entries.push(snapshot);
    // 21 states provide 20 reversible edits, including the baseline.
    if (workbenchHistory.entries.length > 21) workbenchHistory.entries.shift();
    workbenchHistory.cursor = workbenchHistory.entries.length - 1;
  }
  updateHistoryActions();
}
function moveWorkbenchHistory(direction) {
  const next = workbenchHistory.cursor + direction;
  if (![-1, 1].includes(direction) || next < 0 || next >= workbenchHistory.entries.length) return;
  const snapshot = JSON.parse(workbenchHistory.entries[next]);
  workbenchHistory.restoring = true;
  try {
    state.source = snapshot.source;
    state.advancedRules = snapshot.advancedRules || [];
    if (typeof renderAdvancedRules === 'function') renderAdvancedRules();
    state.digits = Object.fromEntries(Object.entries(snapshot.digits).map(([key, values]) => [key, new Set(values)]));
    state.digitModes = snapshot.digitModes || {hundreds:'keep',tens:'keep',units:'keep'};
    renderPositionButtons();
    $$('input[name=pattern]').forEach(input => { input.checked = snapshot.patterns.includes(input.value); });
    for (const [id, value] of Object.entries(snapshot.fields)) {
      if (id.endsWith('-enabled')) $(`#${id}`).checked = value;
      else $(`#${id}`).value = value;
    }
    $$('.source-option').forEach(button => button.classList.toggle('selected', button.dataset.source === state.source));
    workbenchHistory.cursor = next;
    if (typeof restoreConditionRows === 'function') restoreConditionRows(snapshot.conditionRows);
    // Never restore results or candidate readiness: edits require fresh evaluation.
    updateConditionSummary();
  } finally {
    workbenchHistory.restoring = false;
    updateHistoryActions();
  }
}

function conditionCount() {
  let count = Object.values(state.digits).filter(values => values.size).length;
  if ($$('input[name=pattern]:checked').length) count += 1;
  if ($('#sum-enabled').checked) count += 1;
  if ($('#span-enabled').checked) count += 1;
  count += Object.keys(featureFilters).filter(key => $(`#feature-${key}-enabled`).checked).length;
  count += state.advancedRules.length;
  return count;
}

function updateConditionSummary() {
  if(typeof renderForecastConditions==='function')renderForecastConditions();
  recordWorkbenchHistory();
  invalidateResult();
  if (state.loadedPlan) $('#plan-status').textContent = `已存方案：${state.loadedPlan.name} · 当前编辑未保存`;
  const count = conditionCount();
  const logicText = $('#logic-select').selectedOptions[0].textContent;
  $('#condition-count').textContent = `${count}项`;
  $('#summary-conditions').textContent = `${count}项`;
  $('#logic-pill').textContent = logicText;
  $('#min-matches').disabled = $('#logic-select').value !== 'MIN';
  $('#min-matches').max = String(Math.max(1, count));
  renderConditionDescription();
  if (typeof updateConditionRowBadges === 'function') updateConditionRowBadges();
  schedulePreview();
}

function buildPayload({savedPlan = null} = {}) {
  if (typeof conditionRowsError === 'function' && conditionRowsError()) throw new Error(conditionRowsError());
  // Only versioned saves may reuse a loaded snapshot. Evaluation and new
  // plans still require a ready current prediction; the bridge reloads and
  // validates the saved revision before selecting its original snapshot.
  const savedSnapshot = savedPlan && savedPlan === state.loadedPlan
    && savedPlan.lottery_type === state.lotteryType && savedPlan.source.kind === 'prediction';
  if (state.source === 'prediction' && !state.predictionReady[state.lotteryType] && !savedSnapshot) throw new Error('当前彩种候选号码不可用，请重新生成。');
  const range = (prefix, high) => {
    if (!$(`#${prefix}-enabled`).checked) return null;
    if (!$(`#${prefix}-min`).value.trim() || !$(`#${prefix}-max`).value.trim()) throw new Error('范围上下限不能为空。');
    const lowValue = Number($(`#${prefix}-min`).value);
    const highValue = Number($(`#${prefix}-max`).value);
    if (!Number.isInteger(lowValue) || !Number.isInteger(highValue) || lowValue < 0 || highValue > high || lowValue > highValue) {
      throw new Error(`${prefix === 'sum' ? '和值' : '跨度'}范围不正确。`);
    }
    return [lowValue, highValue];
  };
  const logic = $('#logic-select').value;
  const minMatches = Number($('#min-matches').value);
  if (!['AND', 'OR', 'MIN'].includes(logic)) throw new Error('请选择有效的组合逻辑。');
  if (logic === 'MIN' && (!Number.isInteger(minMatches) || minMatches < 1 || minMatches > conditionCount())) {
    throw new Error('至少满足项数必须为1至当前条件数量之间的整数。');
  }
  return {
    lottery_type: state.lotteryType,
    source: state.source,
    ...(state.advancedRules.length ? {advanced_rules: JSON.parse(JSON.stringify(state.advancedRules))} : {}),
    digits: Object.fromEntries(Object.entries(state.digits).map(([key, values]) => [key, [...values].sort((a,b) => a-b)])),
    patterns: $$('input[name=pattern]:checked').map(input => input.value),
    features: featurePayload(),
    ranges: {sum: range('sum', 27), span: range('span', 9)},
    logic,
    min_matches: minMatches,
  };
}

function renderResult(result, context) {
  if (!validNumbers(result.numbers) || result.matched_count !== result.numbers.length || !result.result_hash) {
    throw new Error('筛选结果格式或数量不一致，已停止使用。');
  }
  state.numbers = Object.freeze([...result.numbers]);
  state.resultDetails = result.details || [];
  state.resultContext = Object.freeze({...context, generated_at: new Date().toISOString(), validity: 'valid', result_hash: result.result_hash});
  $('#result-status').textContent = `有效 · ${state.lotteryLabel} · ${state.source === 'all' ? '000–999母表' : `候选截点${context.data_cutoff_issue}`}`;
  $('#result-count').textContent = result.matched_count;
  const betCounts = $('#play-bet-counts');
  if (betCounts) {
    const counts = result.play_bet_counts;
    betCounts.textContent = counts && ['direct', 'group3', 'group6'].every(key => Number.isInteger(counts[key]) && counts[key] >= 0)
      ? `实际玩法注数：直选 ${counts.direct} 注 · 组选3 ${counts.group3} 注 · 组选6 ${counts.group6} 注`
      : '实际玩法注数：暂不可用';
  }
  $('#result-subtitle').textContent = `从 ${result.source_count} 个起始号码中筛选`;
  $('#summary-source').textContent = result.source_count;
  $('#summary-retained').textContent = result.matched_count;
  const reduction = result.source_count ? 1 - result.matched_count / result.source_count : 0;
  $('#summary-reduction').textContent = ratio(reduction, 1);
  $('#result-progress').style.width = `${Math.min(100, result.matched_count / Math.max(1, result.source_count) * 100)}%`;
  $('#result-hash').textContent = `筛选结果：${result.result_hash}${result.result_hash !== result.m2_result_hash ? `\nM2完整母表：${result.m2_result_hash}` : ''}`;
  drawNumberView();
  state.playBetCounts = result.play_bet_counts;
  if (typeof updateCostEstimate === 'function') updateCostEstimate();
  updateResultActions();
}

function groupResultNumbers(numbers, position) {
  const index = {hundreds: 0, tens: 1, units: 2}[position];
  if (index === undefined || !validNumbers(numbers)) throw new Error('号码或分组位置无效。');
  const groups = Array.from({length: 10}, () => []);
  [...numbers].sort().forEach(number => groups[Number(number[index])].push(number));
  return groups;
}

function renderNumberView() {
  // A view change must never revive results invalidated by edits or lottery changes.
  if (!hasValidResult()) return;
  drawNumberView();
}

function drawNumberView() {
  const grid = $('#number-grid');
  if (!state.numbers.length) {
    grid.innerHTML = '<div class="empty-state">没有号码满足当前条件</div>';
    return;
  }
  const position = $('#result-grouping')?.value || 'flat';
  if (position === 'details') {
    drawResultDetails(grid);
    return;
  }
  if (position === 'flat') {
    grid.innerHTML = state.numbers.map(number => `<div class="number-chip">${number}</div>`).join('');
    return;
  }
  const label = {hundreds: '百位', tens: '十位', units: '个位'}[position];
  const groups = groupResultNumbers(state.numbers, position);
  grid.innerHTML = groups.map((numbers, digit) => `<section class="number-group"><h3>${label} ${digit} · ${numbers.length} 个号码</h3><div class="group-number-grid">${numbers.length
    ? numbers.map(number => `<div class="number-chip">${number}</div>`).join('')
    : '<span class="muted">无号码</span>'}</div></section>`).join('');
}

function drawResultDetails(grid) {
  const rows = state.resultDetails;
  if (!Array.isArray(rows) || rows.length !== state.numbers.length
      || rows.some((row, index) => row.number !== state.numbers[index] || row.trace?.matched !== true)) {
    grid.innerHTML = '<div class="empty-state">明细依据缺失或不一致，请重新筛选。</div>';
    return;
  }
  const safeValue = value => escapeHtml(JSON.stringify(value));
  const conditions = trace => (trace.children || []).map(child => child.kind === 'group'
    ? `<li>${escapeHtml(child.label)}：${child.matched ? '通过' : '未通过'}<ul>${conditions(child)}</ul></li>`
    : `<li>${escapeHtml(child.label || child.field_name)}：${child.matched ? '✓ 通过' : '✕ 未通过'}；实际 ${safeValue(child.actual)}；要求 ${escapeHtml(child.comparator === 'between' ? '范围内' : child.comparator === 'not_in' ? '不属于' : '属于')} ${safeValue(child.expected)}</li>`).join('');
  grid.innerHTML = `<section class="number-group result-details"><p>以下号码整体组合均通过；满足任一或至少满足几项时，部分子条件可以未通过。形态：baozi＝豹子，group3＝组三，group6＝组六。</p><div class="table-wrap"><table><thead><tr><th>号码</th><th>和值</th><th>跨度</th><th>形态</th><th>命中条件</th></tr></thead><tbody>${rows.map(row => `<tr><td>${escapeHtml(row.number)}</td><td>${escapeHtml(row.sum_value)}</td><td>${escapeHtml(row.span)}</td><td>${escapeHtml(({baozi: '豹子', group3: '组三', group6: '组六'})[row.pattern] || row.pattern)}</td><td><details><summary>${escapeHtml(row.trace.label)} · ${escapeHtml(row.trace.matched_children)} / ${escapeHtml(row.trace.children.length)} 项通过（要求 ${escapeHtml(row.trace.required_matches)} 项）</summary><ul>${conditions(row.trace)}</ul></details></td></tr>`).join('')}</tbody></table></div></section>`;
}

// Automatic previews serialize bridge calls; rapid edits retain only the latest pending preview.
const preview = {timer: null, active: 0, pending: false};
function previewControls(message) {
  const cancel = $('#cancel-preview');
  if (cancel) cancel.disabled = !(preview.pending || preview.active);
  if (message) $('#result-status').textContent = message;
}
function stopPreview() {
  if (preview.timer !== null) clearTimeout(preview.timer);
  preview.timer = null;
  preview.pending = false;
  state.requests ??= {};
  state.requests.evaluate = (state.requests.evaluate || 0) + 1;
  previewControls();
}
function cancelPreview() {
  invalidateResult('预览已取消，未完成的计算结果不会使用。');
  previewControls('已取消 · 可重新筛选');
  if ($('#cancel-preview')) $('#cancel-preview').disabled = true;
}
function schedulePreview() {
  clearTimeout(preview.timer);
  preview.pending = true;
  previewControls('等待自动预览…');
  preview.timer = setTimeout(() => {
    preview.timer = null;
    if (!preview.active && preview.pending) evaluate(true);
  }, 300);
}
async function evaluate() {
  const automatic = arguments[0] === true;
  if (automatic === true && preview.active) { schedulePreview(); return; }
  stopPreview();
  if (!conditionCount()) { previewControls('请选择至少一个筛选条件'); return; }
  let payload;
  try { payload = buildPayload(); }
  catch (error) { invalidateResult(errorMessage(error)); return; }
  invalidateResult('正在异步预览，请稍候…');
  const revision = state.revision;
  const request = beginRequest('evaluate');
  const context = {lottery_type: state.lotteryType, source: state.source, condition_id: conditionId(),
    data_version: sourceVersion(), data_cutoff_issue: state.source === 'prediction' ? state.predictions[state.lotteryType]?.data_cutoff_issue : null};
  preview.active += 1;
  previewControls('正在异步预览…');
  try {
    if (state.source === 'prediction') {
      if (!context.data_version) throw new Error('候选来源快照不可用，请重新核对来源后筛选。');
      payload.snapshot_source_hash = context.data_version;
    }
    const result = await api('evaluate', payload);
    if (!currentRequest('evaluate', request) || revision !== state.revision
        || context.condition_id !== conditionId() || context.data_version !== sourceVersion()) return;
    renderResult(result, context);
  } catch (error) {
    if (currentRequest('evaluate', request) && revision === state.revision) invalidateResult(errorMessage(error));
  } finally {
    preview.active -= 1;
    previewControls();
    if (preview.pending && preview.timer === null) schedulePreview();
  }
}

function resetWorkbench() {
  state.advancedRules = [];
  if (typeof renderAdvancedRules === 'function') renderAdvancedRules();
  Object.values(state.digits).forEach(values => values.clear());
  state.digitModes = {hundreds:'keep',tens:'keep',units:'keep'};
  renderPositionButtons();
  $$('.digit-button.selected').forEach(button => button.classList.remove('selected'));
  $$('input[name=pattern]').forEach(input => { input.checked = false; });
  $('#sum-enabled').checked = false;
  $('#span-enabled').checked = false;
  Object.keys(featureFilters).forEach(key => { $(`#feature-${key}-enabled`).checked = false; });
  $('#logic-select').value = 'AND';
  $('#min-matches').value = 1;
  state.numbers = [];
  $('#result-count').textContent = '—';
  $('#result-subtitle').textContent = '等待执行筛选';
  $('#number-grid').innerHTML = '<div class="empty-state">选择条件后点击“立即筛选”</div>';
  $('#result-hash').textContent = '尚未生成结果 Hash';
  $('#summary-retained').textContent = '—';
  $('#summary-reduction').textContent = '—';
  $('#result-progress').style.width = '0';
  updateConditionSummary();
}

function formatNumbers() {
  if (!hasValidResult() || !state.numbers.length) throw new Error('结果已过期或为空，请重新筛选后再复制或保存。');
  const format = $('#copy-format').value;
  if (format === 'line') return state.numbers.join('\n');
  if (format === 'ten') return state.numbers.reduce((lines, number, index) => {
    const row = Math.floor(index / 10);
    lines[row] = [...(lines[row] || []), number];
    return lines;
  }, []).map(line => line.join(' ')).join('\n');
  return state.numbers.join(' ');
}

async function copyNumbers() {
  if (!hasValidResult() || !state.numbers.length) { toast('结果已过期或为空，请重新筛选。'); return; }
  try { await api('copy_text', formatNumbers()); toast(`已复制 ${state.numbers.length} 个号码`); }
  catch (error) { toast(errorMessage(error)); }
}

async function exportSavedPlan() {
  await busy($('#plan-export'), async () => {
    if (state.planMutation) throw new Error('方案操作进行中，请稍后重试。');
    const plan = state.loadedPlan;
    if (!plan || plan.lottery_type !== state.lotteryType) throw new Error('请先保存或读取当前彩种方案。');
    const result = await api('export_plan', plan.plan_id, plan.revision, $('#plan-export-format').value);
    if (state.loadedPlan !== plan || state.lotteryType !== plan.lottery_type) return;
    $('#plan-export-status').textContent = result
      ? `已导出“${plan.name}”第 ${result.revision} 版 · ${result.count} 个号码 · ${result.path} · Hash：${result.result_hash}`
      : '已取消导出。';
  });
}

async function saveNumbers() {
  if (!hasValidResult() || !state.numbers.length) { toast('结果已过期或为空，请重新筛选。'); return; }
  try {
    const saved = await api('save_text', formatNumbers(), `${state.lotteryLabel}_筛选号码.txt`);
    if (saved) toast('号码文件已保存');
  } catch (error) { toast(errorMessage(error)); }
}

function selectPage(name) {
  state.requests.workbenchVerify=(state.requests.workbenchVerify||0)+1;
  $$('.main-nav button').forEach(button => button.classList.toggle('selected', button.dataset.page === name));
  $$('.page').forEach(page => page.classList.toggle('active', page.id === `page-${name}`));
  // A control on the page being hidden can retain focus. Keep focus on the
  // visible navigation without letting WebView scroll the whole document.
  $('.main-nav button.selected')?.focus?.({preventScroll:true});
  const rootScroller = document.scrollingElement;
  if (rootScroller) { rootScroller.scrollTop = 0; rootScroller.scrollLeft = 0; }
  window.scrollTo?.(0, 0);
  if (name === 'home') loadHome();
  if (name === 'draws') loadDraws();
  if (name === 'position') loadIssues();
  if (name === 'backtests') return loadBacktests();
  if (name === 'reviews') loadReviews();
}

function setLottery(type) {
  if (!['FC3D', 'PL3'].includes(type) || type === state.lotteryType) return;
  state.lotteryType = type;
  state.advancedRules = [];
  if (typeof renderAdvancedRules === 'function') renderAdvancedRules();
  if ($('#update-preview-result')) $('#update-preview-result').textContent = '彩种已改变，请重新预览。';
  if ($('#update-records')) $('#update-records').textContent = '彩种已改变，请刷新本彩种记录。';
  Object.keys(state.requests).forEach(name => { state.requests[name] += 1; });
  invalidateResult('彩种已切换，请重新筛选。');
  state.lotteryLabel = type === 'FC3D' ? '福彩3D' : '排列3';
  $$('.lottery-button').forEach(button => button.classList.toggle('selected', button.dataset.lottery === type));
  $('#current-lottery-label').textContent = state.lotteryLabel;
  $('#plan-lottery').textContent = state.lotteryLabel;
  $('#prediction-source-count').textContent = state.predictionReady[type] ? '已生成' : '未生成';
  if (state.source === 'prediction' && !state.predictionReady[type]) selectSource('all');
  clearPredictionView();
  resetBacktest();
  resetForecastHistory('彩种已切换，请选择本彩种八栏检验。', true);
  resetForwardForecasts('彩种已切换，正在读取本彩种留档。');
  $('#backtest-run').innerHTML = '';
  $('#review-id').innerHTML = '';
  emptyView('#review-content', '彩种已切换，请选择本彩种复盘记录。');
  state.positionResult = null;
  emptyView('#position-charts', '彩种已切换，请重新查询。');
  emptyView('#position-table', '彩种已切换，请重新查询。');
  $('#position-issue').innerHTML = '';
  emptyView('#draws-table', '彩种已切换，请重新查询。');
  state.drawsPage = 1;
  state.drawsPages = 1;
  $('#draws-page').textContent = '尚未加载开奖记录';
  $('#draws-prev').disabled = true;
  $('#draws-next').disabled = true;
  const activePage = $('.page.active')?.id;
  if (activePage === 'page-home') loadHome();
  if (activePage === 'page-draws') loadDraws();
  if (activePage === 'page-position') loadIssues();
  if (activePage === 'page-backtests') loadBacktests();
  if (activePage === 'page-reviews') loadReviews();
  resetWorkbenchHistory();
  if (state.syncEnabled) refreshOfficialStatus();
}

function selectSource(source) {
  if (!['all', 'prediction'].includes(source)) { toast('请选择有效的号码来源。'); return; }
  if (source === 'prediction' && !state.predictionReady[state.lotteryType]) {
    toast(`请先为${state.lotteryLabel}生成智能预测号码。`);
    selectPage('prediction');
    return;
  }
  state.source = source;
  invalidateResult('号码来源已切换，请重新筛选。');
  $$('.source-option').forEach(button => button.classList.toggle('selected', button.dataset.source === source));
  recordWorkbenchHistory();
}

function clearPredictionView(message = '请为当前彩种重新生成候选号码。') {
  $('#prediction-metrics').innerHTML = '';
  $('#prediction-basis').innerHTML = '';
  $('#prediction-to-workbench').disabled = true;
  emptyView('#prediction-table', message);
  clearHomePrediction(message);
}

function clearHomePrediction(message = '尚未生成当前彩种候选。') {
  state.requests.forecastExport=(state.requests.forecastExport||0)+1;
  if($('#home-forecast-export-status'))$('#home-forecast-export-status').textContent='TXT用于查看八栏号码与依据；预测留档和保存方案仍使用各自入口。';
  if($('#forecast-transfer-status'))$('#forecast-transfer-status').textContent='请生成当前彩种预测后选栏新建草稿；工作台已引用的固定快照不会自动替换。';
  if($('#forward-seal'))$('#forward-seal').disabled=true;
  if (!$('#home-numbers')) return;
  emptyView('#home-numbers', message);
  $('#home-candidate-context').textContent = message;
  $('#home-copy').disabled = true;
  $('#home-to-workbench').disabled = true;
  if ($('#home-save')) $('#home-save').disabled = true;
  if ($('#home-basis-summary')) $('#home-basis-summary').textContent = '尚无当前彩种有效候选；数据不足或更新后请重新生成。';
  if ($('#home-validation-summary')) $('#home-validation-summary').textContent = '没有当前候选的历史检验统计。';
  if($('#home-calculation-basis')){ $('#home-calculation-basis').hidden=true;$('#home-calculation-basis').textContent=''; }
  $('#home-numbers').classList.remove('forecast-sections');
  if($('#home-copy-forecast')){$('#home-copy-forecast').hidden=true;$('#home-copy-forecast').disabled=true;}
  updateForecastExport();
}

function renderHomePrediction() {
  const result = state.predictions[state.lotteryType];
  if (!state.predictionReady[state.lotteryType] || result?.lottery_type !== state.lotteryType
      || !validNumbers(result?.numbers) || !result.numbers.length) return clearHomePrediction();
  if ([10,20,50,100].includes(result.candidate_count)) syncPredictionCount(String(result.candidate_count), false);
  const sections=result.forecast_sections;
  $('#home-numbers').classList.toggle('forecast-sections',Boolean(sections));
  $('#home-numbers').innerHTML = sections?sections.sections.map(row=>
    `<article class="forecast-row"><strong>${escapeHtml(row.label)}</strong><div><div class="forecast-values">${row.items.map(item=>`<span class="number-chip ai-number"><span>${escapeHtml(item.number)}</span><small>AI评分 ${escapeHtml(item.score_text)}</small></span>`).join('')}</div><p class="forecast-basis">依据：${escapeHtml(row.basis)}</p>${typeof window.pywebview?.api?.forecast_condition==='function'?`<button type="button" data-forecast-transfer="${row.key}">用${escapeHtml(row.label)}新建缩水</button>`:''}</div></article>`).join(''):
    result.numbers.map((number,index) => result.model_evidence?
    `<span class="number-chip ai-number"><span>${number}</span><small>AI评分 ${escapeHtml(result.candidates[index].score_text)}</small></span>`:
    `<span class="number-chip">${number}</span>`).join('');
  if($('#home-copy-forecast')){$('#home-copy-forecast').hidden=!sections;$('#home-copy-forecast').disabled=!sections;}
  updateForecastExport();
  $('#home-copy').textContent=sections?'复制直选号码':'复制全部号码';
  if($('#home-save'))$('#home-save').textContent=sections?'保存直选方案':'保存到我的方案';
  $('#home-to-workbench').textContent=sections?'继续筛选直选':'继续筛选';
  if($('#home-calculation-basis')) {
    const evidence=result.model_evidence;
    $('#home-calculation-basis').hidden=!evidence;
    $('#home-calculation-basis').textContent=evidence?
      `计算依据：朴素贝叶斯 · ${evidence.training_samples}组训练样本（${evidence.training_start_issue}–${evidence.training_end_issue}期） · 输入前${evidence.feature_lags}期定位数字：${evidence.context_draws.map(draw=>`${draw.issue}期 ${draw.number}`).join('、')}。${evidence.probability_notice}`:'';
  }
  $('#home-candidate-context').textContent = `${state.lotteryLabel} · ${result.numbers.length}个研究候选 · 数据截止 ${result.data_cutoff_issue ?? '未知'}期 / ${result.data_cutoff_date ?? '未知日期'}`;
  $('#home-copy').disabled = false;
  $('#home-to-workbench').disabled = false;
  if ($('#home-save')) $('#home-save').disabled = false;
  if ($('#home-basis-summary')) $('#home-basis-summary').textContent = result.method_config?
    `研究方法：${result.method_name} · 数据截止：${result.data_cutoff_issue} / ${result.data_cutoff_date}。${result.basis} 历史检验只说明过往覆盖，尚未证明稳定预测优势。详情见“完整分析依据”。`:
    `方法版本：${result.method_version ?? '未提供'} · 数据截止：${result.data_cutoff_issue ?? '未知'} / ${result.data_cutoff_date ?? '未知'}。${result.formula ?? ''} 历史检验只说明过往覆盖，不代表未来中奖概率；尚未证明稳定预测优势。详情见“完整分析依据”。`;
  const selected = result.selected_validation || {};
  if ($('#home-validation-summary')) $('#home-validation-summary').textContent = `历史检验：覆盖 ${selected.coverage_count ?? '—'} / 可评价 ${selected.evaluable_periods ?? '—'}期；覆盖率 ${ratio(selected.coverage_rate)}，随机基准 ${ratio(selected.baseline_rate)}。${selected.complete_window === false ? '样本不足或有跳过期。' : ''}不等同前瞻样本外验证。`;
}

async function loadHome() {
  loadForwardForecasts();
  const request = beginRequest('home');
  // Switching lottery never shows another lottery's cached candidate result.
  clearHomePrediction();
  renderHomePrediction();
  emptyView('#home-latest', '正在读取本机最近开奖…');
  if ($('#home-cutoff')) $('#home-cutoff').textContent = `${state.lotteryLabel} · 正在读取本机截止期；不代表官方最新期。`;
  $('#home-data-status').textContent = '正在检查本地记录；不是联网更新。';
  try {
    const result = await api('list_draws', request.lottery, 1);
    if (!currentRequest('home', request)) return;
    const draw = result.items?.[0];
    if (!draw) {
      emptyView('#home-latest', '该彩种尚无本地开奖记录。');
      $('#home-data-status').textContent = '本机查询成功，但没有该彩种记录；不能认定官方没有开奖。';
      if ($('#home-cutoff')) $('#home-cutoff').textContent = `${state.lotteryLabel} · 本机尚无开奖记录。`;
      return;
    }
    if (!/^\d{3}$/.test(draw.number)) throw new Error('最近开奖号码格式异常，已停止展示。');
    const statuses = {pending:'待核验（单来源）', verified:'已核验', conflict:'来源冲突', manual_verified:'人工核验'};
    $('#home-latest').innerHTML = `<p>${escapeHtml(state.lotteryLabel)} · ${escapeHtml(draw.issue)}期</p><div class="draw-balls">${[...draw.number].map(digit => `<span>${digit}</span>`).join('')}</div><p>${escapeHtml(draw.draw_date)} · ${escapeHtml(statuses[draw.verify_status] || draw.verify_status)}</p>`;
    $('#home-data-status').textContent = `本机共 ${result.total}期 · 截止 ${draw.issue}期 / ${draw.draw_date}。未检查官方最新公告。`;
    if ($('#home-cutoff')) $('#home-cutoff').textContent = `${state.lotteryLabel} · 本机开奖截止 ${draw.issue}期 / ${draw.draw_date}；候选所用截点见推荐依据。`;
  } catch (error) {
    if (!currentRequest('home', request)) return;
    emptyView('#home-latest', errorMessage(error));
    $('#home-data-status').textContent = '历史数据暂不可读取；全部000–999静态选号和个人方案仍可在独立本地版使用。';
    if ($('#home-cutoff')) $('#home-cutoff').textContent = `${state.lotteryLabel} · 截止期暂不可读取，请检查数据状态。`;
  }
}

async function generateHomePrediction() {
  await busy($('#home-generate'), async () => {
    const count = $('#home-count').value;
    if (!['10','20','50','100'].includes(count)) throw new Error('候选数量只允许10、20、50、100。');
    syncPredictionCount(count, false);
    await generatePrediction();
    renderHomePrediction();
  });
}

async function copyHomePrediction() {
  const lottery = state.lotteryType;
  const result = state.predictions[lottery];
  if (!state.predictionReady[lottery] || result?.lottery_type !== lottery || !validNumbers(result?.numbers) || !result.numbers.length) {
    toast('没有当前彩种的有效候选，请重新生成。'); return;
  }
  await busy($('#home-copy'), async () => { await api('copy_text', result.numbers.join(' ')); });
  renderHomePrediction();
}

function checkedForecastSections(result) {
  const value=result.forecast_sections;
  if(!value)return;
  const keys=['dan','pairs','selected','four','five','six','direct','group3'];
  const labels=['独胆','双码','精选','四码','五码','六码','直选','组三'];
  const counts=[2,3,4,1,1,1,result.candidate_count,12];
  if(!result.model_evidence||value.schema_version!==1||value.method_version!==result.method_version||
    value.lottery_type!==result.lottery_type||value.data_cutoff_issue!==result.data_cutoff_issue||
    value.snapshot_source_hash!==result.result_hash||value.candidate_count!==result.candidate_count||
    !Array.isArray(value.sections)||value.sections.length!==8)throw new Error('预测分类与当前AI来源不一致。');
  value.sections.forEach((row,index)=>{
    if(row.key!==keys[index]||row.label!==labels[index]||typeof row.basis!=='string'||!row.basis||
      !Array.isArray(row.items)||row.items.length!==counts[index])throw new Error('预测分类的栏目或数量异常。');
    const length=index===0?1:index===1?2:index>=3&&index<=5?index+1:3;
    const numbers=row.items.map(item=>item.number);
    if(new Set(numbers).size!==numbers.length||row.items.some(item=>typeof item.number!=='string'||
      !new RegExp(`^[0-9]{${length}}$`).test(item.number)||typeof item.score_text!=='string'||
      !/^\d+\.\d{12}$/.test(item.score_text)||Number(item.score_text)>1))throw new Error('预测分类号码或评分异常。');
    if(index===1||index>=3&&index<=5) {
      if(numbers.some(n=>new Set(n).size!==n.length||[...n].sort().join('')!==n))throw new Error('双码或数字池必须是不重复的升序数字。');
    }
    if(index===7&&numbers.some(n=>new Set(n).size!==2||[...n].sort().join('')!==n))throw new Error('组三必须是含一对重号的不定位组合。');
  });
  const numbers=index=>value.sections[index].items.map(item=>item.number);
  if(JSON.stringify(numbers(6))!==JSON.stringify(result.numbers)||
    JSON.stringify(numbers(2))!==JSON.stringify(result.numbers.slice(0,4))||
    ![...numbers(3)[0]].every(d=>numbers(4)[0].includes(d))||![...numbers(4)[0]].every(d=>numbers(5)[0].includes(d)))
    throw new Error('预测分类的直选、精选或数字池不一致。');
}

function homeForecastText(result) {
  checkedForecastSections(result);
  const e=result.model_evidence;
  return [`${result.lottery_type==='FC3D'?'福彩3D':'排列3'} · AI研究预测 · 数据截止${result.data_cutoff_issue}期 / ${result.data_cutoff_date}`,
    ...result.forecast_sections.sections.map(row=>`${row.label}：${row.items.map(item=>item.number).join(' ')}\n依据：${row.basis}`),
    `计算依据：朴素贝叶斯 · ${e.training_samples}组训练样本（${e.training_start_issue}–${e.training_end_issue}期） · 输入前${e.feature_lags}期定位数字：${e.context_draws.map(draw=>`${draw.issue}期 ${draw.number}`).join('、')}。${e.probability_notice}`,
    `模型版本：${result.method_version}\n依据Hash：${result.result_hash}\n直选数量：${result.candidate_count}注`,
    result.forecast_sections.score_notice,'研究参考，不保证中奖。TXT用于查看，不替代首次预测留档或完整方案。'].join('\n\n');
}
async function copyHomeForecast() {
  const result=state.predictions[state.lotteryType];
  if(!state.predictionReady[state.lotteryType]||result?.lottery_type!==state.lotteryType||!result.forecast_sections)return toast('请先生成当前彩种预测。');
  const text=homeForecastText(result);
  await busy($('#home-copy-forecast'),async()=>{await api('copy_text',text);});
}
function updateForecastExport() {
  const button=$('#home-export-forecast');if(!button)return;
  const result=state.predictions[state.lotteryType];
  const available=state.predictionReady[state.lotteryType]&&result?.lottery_type===state.lotteryType
    &&Boolean(result.forecast_sections)&&$('#home-numbers').classList.contains('forecast-sections')
    &&typeof window.pywebview?.api?.save_text==='function';
  button.hidden=!available;button.disabled=!available||busy.pending.has(button);
}
async function exportHomeForecast() {
  const button=$('#home-export-forecast');if(busy.pending.has(button))return;
  await busy(button,async()=>{
    const result=state.predictions[state.lotteryType];
    if(!state.predictionReady[state.lotteryType]||result?.lottery_type!==state.lotteryType||!result.forecast_sections
      ||!$('#home-numbers').classList.contains('forecast-sections'))throw new Error('请先生成当前彩种预测。');
    if(typeof window.pywebview?.api?.save_text!=='function')throw new Error('当前版本不能导出预测，请使用新版。');
    const request=beginRequest('forecastExport'),text=homeForecastText(result);
    const current=()=>currentRequest('forecastExport',request)&&state.predictionReady[request.lottery]
      &&state.predictions[request.lottery]===result;
    $('#home-forecast-export-status').textContent='请选择TXT保存位置；保存的是本次点击时的八栏预测与依据。';
    try {
      const saved=await api('save_text',text,`${request.lottery==='FC3D'?'福彩3D':'排列3'}_AI八栏预测_截止${result.data_cutoff_issue}期_直选${result.candidate_count}注.txt`);
      if(!current())return;
      $('#home-forecast-export-status').textContent=saved?`已导出预测TXT：${saved.path}。TXT用于查看，不替代预测留档或完整方案。`:'已取消导出，当前预测保留。';
    }catch(error){if(current())$('#home-forecast-export-status').textContent=errorMessage(error);}
  });
}

function bindHome() {
  $('#home-numbers')?.addEventListener('click',event=>{
    const button=event.target.closest('[data-forecast-transfer]');
    if(button)return transferForecast(button.dataset.forecastTransfer,button);
  });
  $('#workbench-forecast')?.addEventListener('click',event=>{
    const button=event.target.closest('[data-remove-forecast]');
    if(!button)return;
    state.advancedRules.splice(Number(button.dataset.removeForecast),1);
    renderAdvancedRules();updateConditionSummary();
  });
  bindForwardForecasts();
  if(typeof window.pywebview?.api?.generate_research_candidates==='function'&&$('#home-method'))$('#home-method').value='multiwindow';
  updateResearchControls();
  for(const id of ['home-method','home-window-weights','home-decay-window','home-half-life','home-smoothing']) {
    $(`#${id}`)?.addEventListener('change',()=>{updateResearchControls();invalidateResearchChoice();});
  }
  $('#home-refresh')?.addEventListener('click', () => busy($('#home-refresh'), async () => { await refreshConnection(); await loadHome(); }));
  $('#home-generate')?.addEventListener('click', generateHomePrediction);
  $('#home-copy')?.addEventListener('click', copyHomePrediction);
  $('#home-copy-forecast')?.addEventListener('click', copyHomeForecast);
  $('#home-export-forecast')?.addEventListener('click', exportHomeForecast);
  $('#home-static')?.addEventListener('click', () => { selectSource('all'); selectPage('workbench'); });
  $('#home-to-workbench')?.addEventListener('click', () => {
    const result = state.predictions[state.lotteryType];
    if (!state.predictionReady[state.lotteryType] || result?.lottery_type !== state.lotteryType) return clearHomePrediction();
    selectSource('prediction'); selectPage('workbench');
  });
  $('#home-count')?.addEventListener('change', () => syncPredictionCount($('#home-count').value));
  for (const [id, page] of [['home-basis','prediction'], ['home-draws','draws'], ['home-health','health'],
      ['home-plans','workbench'], ['home-backtests','backtests'], ['home-reviews','reviews']]) {
    $(`#${id}`)?.addEventListener('click', () => {
      selectPage(page);
      if (id === 'home-plans') $('.plan-drawer').open = true;
    });
  }
}

function researchConfiguration() {
  if(typeof window.pywebview?.api?.generate_ai_candidates==='function')return {method:'naive_bayes',params:{}};
  if(typeof window.pywebview?.api?.generate_research_candidates!=='function')return {method:'z30',params:{}};
  const method=$('#home-method').value;
  if(method==='z30')return {method,params:{}};
  const alpha=Number($('#home-smoothing').value);
  if(![10,30,100].includes(alpha))throw new Error('请选择有效的平滑强度。');
  if(method==='multiwindow') {
    const weights={balanced:[1,1,1],recent:[3,2,1],long:[1,2,3]}[$('#home-window-weights').value];
    if(!weights)throw new Error('请选择有效的窗口权重。');
    return {method,params:{alpha,weights}};
  }
  if(method==='decay') {
    const windowSize=Number($('#home-decay-window').value),halfLife=Number($('#home-half-life').value);
    if(![30,100,300].includes(windowSize)||![5,10,30,60].includes(halfLife))throw new Error('请选择有效的衰减窗口和半衰期。');
    return {method,params:{alpha,window:windowSize,half_life:halfLife}};
  }
  throw new Error('请选择支持的研究方法。');
}

function updateResearchControls() {
  const ai=typeof window.pywebview?.api?.generate_ai_candidates==='function';
  if($('#home-ai-method'))$('#home-ai-method').hidden=!ai;
  if($('#home-legacy-research'))$('#home-legacy-research').hidden=ai;
  if($('#home-recommendation-note'))$('#home-recommendation-note').textContent=ai?
    '使用一个固定AI模型，计算依据随结果显示；相同历史和数量的结果可复现。':
    '当前连接使用统计兼容入口；方法与参数随结果保留，不代表未来中奖概率。';
  const supported=typeof window.pywebview?.api?.generate_research_candidates==='function';
  const method=supported?$('#home-method').value:'z30';
  if($('#home-method'))$('#home-method').disabled=!supported;
  for(const [id,visible] of [['home-multi-options',method==='multiwindow'],['home-decay-options',method==='decay'],['home-alpha-options',method!=='z30']]) {
    if($(`#${id}`))$(`#${id}`).hidden=!visible;
  }
  if($('#home-method-note'))$('#home-method-note').textContent=method==='multiwindow'?
    '综合30/100/300期的平滑位置频率，需要完整300期。参数由你选定，历史对比不代表预测优势。':method==='decay'?
    '近期权重更高，需要完整所选历史窗口。半衰期越小，越关注近期；没有“冷号必出”假设。':'Z30对照使用最近30期，不修改原评分与排序。';
}

function invalidateResearchChoice() {
  state.requests.prediction=(state.requests.prediction||0)+1;
  for(const lottery of ['FC3D','PL3']){state.predictionReady[lottery]=false;delete state.predictions[lottery];}
  $('#prediction-source-count').textContent='未生成';
  clearPredictionView('研究方法或参数已改变，请重新生成候选。');
  if(state.source==='prediction')invalidateResult('研究方法或参数已改变，请重新生成并筛选。');
}

function syncPredictionCount(value, invalidate = true) {
  const count = String(value);
  if (!['10','20','50','100'].includes(count)) throw new Error('候选数量只允许10、20、50、100。');
  $('#home-count').value = count;
  $('#prediction-count').value = count;
  if (!invalidate) return;
  state.requests.prediction = (state.requests.prediction || 0) + 1;
  state.predictionReady[state.lotteryType] = false;
  delete state.predictions[state.lotteryType];
  $('#prediction-source-count').textContent = '未生成';
  clearPredictionView('候选数量已改变，请重新生成。');
  updateForwardSeal();
  if (state.source === 'prediction') invalidateResult('候选数量已改变，请重新生成和筛选。');
}

function resetBacktest(message = '请选择本彩种记录，然后点击“查看结果”。') {
  if($('#saved-check-note'))$('#saved-check-note').textContent='';
  if($('#backtest-replay-summary')) $('#backtest-replay-summary').innerHTML='';
  state.requests.backtest = (state.requests.backtest || 0) + 1;
  state.requests.planReplay = (state.requests.planReplay || 0) + 1;
  $('#backtest-replay-results').innerHTML = '';
  $('#backtest-replay-status').textContent = '本地研究回放范围已重置，请重新执行。';
  state.backtestRun = null;
  state.backtestPage = 1;
  state.backtestPages = 1;
  state.backtestLoading = false;
  state.backtestTotal = 0;
  $('#backtest-conclusion').className = 'conclusion-card empty-conclusion';
  $('#backtest-conclusion').textContent = message;
  $('#backtest-metrics').innerHTML = '';
  $('#backtest-selection').textContent = '';
  emptyView('#backtest-table', message);
  updateBacktestPager();
}

function updateBacktestPager() {
  $('#backtest-prev').disabled = !state.backtestRun || state.backtestLoading || state.backtestPage <= 1;
  $('#backtest-next').disabled = !state.backtestRun || state.backtestLoading || state.backtestPage >= state.backtestPages;
  $('#backtest-page').textContent = state.backtestLoading ? '正在加载…' : state.backtestRun
    ? `第 ${state.backtestPage} / ${state.backtestPages} 页 · 共 ${state.backtestTotal} 期` : '尚未加载期级结果';
}

async function generatePrediction() {
  await busy($('#prediction-button'), async () => {
    syncPredictionCount($('#prediction-count').value, false);
    const configuration=researchConfiguration(),configurationKey=JSON.stringify(configuration);
    const request = beginRequest('prediction');
    state.predictionReady[request.lottery] = false;
    delete state.predictions[request.lottery];
    if (state.source === 'prediction') invalidateResult('候选来源正在更新，请稍候重新筛选。');
    clearPredictionView('正在生成当前彩种的候选号码…');
    $('#prediction-source-count').textContent = '未生成';
    try {
    const result = configuration.method==='naive_bayes'?
      await api('generate_ai_candidates',request.lottery,Number($('#prediction-count').value)):configuration.method==='z30'?
      await api('generate_prediction', request.lottery, Number($('#prediction-count').value)):
      await api('generate_research_candidates', request.lottery, Number($('#prediction-count').value),configuration.method,configuration.params);
    if (!currentRequest('prediction', request)) return;
    if(JSON.stringify(researchConfiguration())!==configurationKey)return;
    if (result.lottery_type !== request.lottery) throw new Error('候选结果与当前彩种不匹配，已停止使用。');
    if(configuration.method!=='z30'&&(!result.method_config||result.method_config.method!==configuration.method||
        Object.entries(configuration.params).some(([name,value])=>JSON.stringify(result.method_config[name])!==JSON.stringify(value))))
      throw new Error('候选结果与所选研究方法或参数不一致，已停止使用。');
    if(configuration.method==='naive_bayes'&&(!result.model_evidence||result.model_evidence.model!=='categorical_naive_bayes'||
      result.model_evidence.training_samples!==500||result.model_evidence.feature_lags!==3||
      !Array.isArray(result.model_evidence.context_draws)||result.model_evidence.context_draws.length!==3))
      throw new Error('AI训练依据缺失或不匹配，已停止使用。');
    if (!validNumbers(result.numbers) || !result.numbers.length || !Array.isArray(result.candidates) || !result.candidates.length) {
      throw new Error('候选结果为空或格式异常，请检查数据后重新生成。');
    }
    if (result.candidate_count !== result.numbers.length || result.candidates.length !== result.numbers.length
      || result.candidates.some((row, index) => row.number !== result.numbers[index])) throw new Error('候选号码、数量及明细不一致，已停止使用。');
    checkedForecastSections(result);
    state.predictionReady[request.lottery] = true;
    state.predictions[request.lottery] = result;
    $('#prediction-source-count').textContent = `${result.candidate_count}个`;
    $('#prediction-to-workbench').disabled = false;
    const validation = result.selected_validation || {};
    $('#prediction-metrics').innerHTML = [
      ['候选数量', result.candidate_count], ['历史覆盖率', ratio(validation.coverage_rate)],
      ['随机基准', ratio(validation.baseline_rate)], ['Z-score', numberValue(validation.z_score)]
    ].map(([label, value]) => `<div class="metric"><span>${label}</span><strong>${value}</strong></div>`).join('');
    const research=result.method_config;
    $('#prediction-table').innerHTML = `<table><thead><tr><th>排名</th><th>号码</th><th>${research?'研究评分':'总分'}</th><th>百位${research?'估计值':'Z30'}</th><th>十位${research?'估计值':'Z30'}</th><th>个位${research?'估计值':'Z30'}</th></tr></thead><tbody>${result.candidates.map(row => `<tr><td>${row.rank}</td><td>${row.number}</td><td>${escapeHtml(row.score_text)}</td><td>${escapeHtml(research?row.hundreds_probability_text:row.hundreds_z30_text)}</td><td>${escapeHtml(research?row.tens_probability_text:row.tens_z30_text)}</td><td>${escapeHtml(research?row.units_probability_text:row.units_z30_text)}</td></tr>`).join('')}</tbody></table>`;
    renderPredictionBasis(result);
    renderHomePrediction();
    toast(`已生成 ${result.candidate_count} 个实验性候选号码`);
    updateForwardSeal();
    if($('#forward-auto')?.checked)await sealCurrentForward(result);
    } catch (error) {
      if (!currentRequest('prediction', request)) return;
      clearPredictionView(errorMessage(error));
      toast(errorMessage(error));
    }
  });
}

function renderPredictionBasis(result) {
  const validation = result.validation || {};
  const selected = result.selected_validation || validation.summaries?.[result.candidate_count] || {};
  const fields = [
    ['数据截止期', result.data_cutoff_issue], ['数据截止日期', result.data_cutoff_date],
    ['目标期（推算，非官方确认）', result.target_issue], ['生成时间', result.generated_at],
    ['分析方法', result.method_name], ['方法版本', result.method_version],
    ['评分公式', result.formula], ['统计依据', result.basis],
    ['历史检验性质', validation.sample_label],
    ['历史区间', `${validation.window_start_issue ?? '—'} 至 ${validation.window_end_issue ?? '—'}`],
    ['请求 / 实际 / 可评价 / 跳过期数', `${selected.requested_periods ?? validation.requested_periods ?? '—'} / ${selected.actual_periods ?? '—'} / ${selected.evaluable_periods ?? '—'} / ${selected.skipped_periods ?? '—'}`],
    ['窗口是否足量', selected.complete_window === true ? '是' : selected.complete_window === false ? '否，历史样本不足或有跳过期' : '没有有效依据'],
  ];
  const summaries = Object.values(validation.summaries || {});
  $('#prediction-basis').innerHTML = `<h2>候选分析依据与历史检验</h2><dl class="basis-fields">${fields.map(([label,value]) => `<dt>${escapeHtml(label)}</dt><dd>${escapeHtml(value ?? '—')}</dd>`).join('')}</dl>
    <p class="notice">${escapeHtml(result.warning || '实验性统计候选，不保证中奖。')} 历史覆盖率不是中奖概率或预测准确率；历史检验不等同于前瞻样本外验证，样本有限，不能据此宣称稳定优势。</p>
    <div class="table-wrap"><table><thead><tr><th>候选数量</th><th>覆盖次数 / 可评价</th><th>覆盖率</th><th>随机基准</th><th>Expected Hits</th><th>Excess Hits</th><th>Lift</th><th>Z-score</th><th>最长未覆盖</th></tr></thead><tbody>${summaries.map(row => `<tr><td>${escapeHtml(row.candidate_count)}</td><td>${escapeHtml(row.coverage_count ?? '—')} / ${escapeHtml(row.evaluable_periods ?? '—')}</td><td>${ratio(row.coverage_rate)}</td><td>${ratio(row.baseline_rate)}</td><td>${numberValue(row.expected_hits)}</td><td>${numberValue(row.excess_hits)}</td><td>${numberValue(row.lift)}</td><td>${numberValue(row.z_score)}</td><td>${escapeHtml(row.longest_miss_streak ?? '—')}</td></tr>`).join('')}</tbody></table>${summaries.length ? '' : '<p>暂无有效历史检验统计。</p>'}</div>
    <details class="technical"><summary>查看候选结果Hash与跳过记录</summary><pre>${escapeHtml(JSON.stringify({result_hash:result.result_hash, method_version:result.method_version, skipped:validation.skipped || []}, null, 2))}</pre></details>`;
  if(result.comparison) {
    const compare=result.comparison;
    const rows=[compare.current_method,compare.z30];
    $('#prediction-basis').innerHTML+=`<h2>同数量历史对照</h2><p>候选${escapeHtml(compare.candidate_count)}个，共同可评价${escapeHtml(compare.common_evaluable_periods)}期。${escapeHtml(compare.note)}</p><table><thead><tr><th>方法</th><th>覆盖期数</th><th>覆盖率</th></tr></thead><tbody>${rows.map(row=>`<tr><td>${escapeHtml(row.name)}</td><td>${escapeHtml(row.covered_periods)}</td><td>${ratio(row.coverage)}</td></tr>`).join('')}</tbody></table><p>均匀随机理论基准：${ratio(compare.uniform_baseline)}，不是一次机选的实测结果。软件不会自动按这段历史挑选最佳方法或参数。</p>`;
  }
}

async function exportDraws() {
  const lottery = state.lotteryType;
  const filters = {...state.drawsFilters};
  await busy($('#draws-export'), async () => {
    const result = await api('export_draws_csv', lottery, filters.issue, filters.dateFrom, filters.dateTo);
    toast(result ? `已导出 ${result.count} 期开奖记录（${lottery === 'FC3D' ? '福彩3D' : '排列3'}）。` : '已取消导出。');
  });
}

async function loadDraws() {
  const request = beginRequest('draws');
  $('#draws-prev').disabled = true;
  $('#draws-next').disabled = true;
  emptyView('#draws-table', '正在读取开奖记录…');
  try {
    const result = await api('list_draws', request.lottery, state.drawsPage, state.drawsFilters.issue, state.drawsFilters.dateFrom, state.drawsFilters.dateTo);
    if (!currentRequest('draws', request)) return;
    state.drawsPages = result.pages;
    $('#draws-page').textContent = `第 ${result.page} / ${result.pages} 页 · 共 ${result.total} 期`;
    $('#draws-prev').disabled = result.page <= 1;
    $('#draws-next').disabled = result.page >= result.pages;
    const status = {pending:'单一来源，待核验', verified:'双来源一致', conflict:'来源冲突', manual_verified:'人工核验'};
    if (!result.items?.length) { emptyView('#draws-table', '当前筛选条件下没有开奖记录。'); return; }
    $('#draws-table').innerHTML = `<table><thead><tr><th>期号</th><th>开奖日期</th><th>开奖号码</th><th>核验状态</th></tr></thead><tbody>${result.items.map(row => `<tr><td>${escapeHtml(row.issue)}</td><td>${escapeHtml(row.draw_date)}</td><td><strong>${escapeHtml(row.number)}</strong></td><td>${escapeHtml(status[row.verify_status] || row.verify_status)}</td></tr>`).join('')}</tbody></table>`;
  } catch (error) { if (currentRequest('draws', request)) { emptyView('#draws-table', errorMessage(error)); toast(errorMessage(error)); } }
}

async function loadIssues({preserveSelection=false}={}) {
  const request = beginRequest('issues');
  const selected=preserveSelection?$('#position-issue').value:'';
  state.requests.position = (state.requests.position || 0) + 1;
  state.positionResult = null;
  emptyView('#position-charts', '请选择目标期和位置后查询。');
  emptyView('#position-table', '正在刷新统计范围…');
  $('#position-issue').innerHTML = '';
  try {
    const issues = await api('recent_issues', request.lottery, 200);
    if (!currentRequest('issues', request)) return;
    const latest=typeof window.pywebview?.api?.latest_position_states==='function'&&issues.length>0;
    $('#position-issue').innerHTML = (latest?'<option value="__latest__">最新统计（含最近已开奖）</option>':'')+
      issues.map(issue => `<option value="${escapeHtml(issue)}">${escapeHtml(issue)}（开奖前）</option>`).join('');
    $('#position-issue').value=selected&&(selected==='__latest__'&&latest||issues.includes(selected))?selected:latest?'__latest__':issues[0]||'';
    if (!issues.length) emptyView('#position-table', '当前彩种没有可查询的历史期号。');
    if(latest)await queryPosition();
  } catch (error) { if (currentRequest('issues', request)) { emptyView('#position-charts', errorMessage(error)); emptyView('#position-table', errorMessage(error)); toast(errorMessage(error)); } }
}

function findWindow(row, size) { return (row.windows || []).find(item => item.size === size) || {}; }


function renderPositionCharts() {
  const result = state.positionResult;
  if (!result) return;
  const selected = $('#position-digit').value;
  const rows = result.states.filter(row => selected === '' || String(row.digit) === selected);
  const maximum = Math.max(1, ...rows.map(row => Number.isFinite(row.current_gap) ? row.current_gap : 0));
  const bars = rows.map(row => {
    const value = Number.isFinite(row.current_gap) ? row.current_gap : null;
    const label = value === null ? (row.never_seen ? '历史中从未出现（遗漏无定义）' : '无样本') : `${value}期${row.never_seen ? '（历史中从未出现）' : ''}`;
    return `<div class="gap-row"><strong>${escapeHtml(row.digit)}</strong><div class="gap-track"><div class="gap-fill" style="width:${value === null ? 0 : 100 * value / maximum}%"></div></div><span>${escapeHtml(label)}</span></div>`;
  }).join('');
  const history = result.history || [];
  const digit = selected === '' ? 0 : Number(selected);
  const colors = ['#2870c8', '#b34e1e', '#527c2d'];
  const sizes = [10, 30, 100];
  const lines = sizes.map((size, index) => {
    // Separate paths preserve missing samples as gaps rather than zeroes.
    let path = '', connected = false;
    const points = history.map((point, i) => {
      const row = point.states?.find(item => item.digit === digit);
      const w = row ? findWindow(row, size) : {};
      if (!Number.isFinite(w.frequency)) { connected = false; return ''; }
      const x = 50 + i * 660 / Math.max(1, history.length - 1), y = 210 - w.frequency * 180;
      path += `${connected ? 'L' : 'M'}${x},${y} `; connected = true;
      const label = `${point.issue}${point.inferred?'（推算最新点）':''} 开奖前：数字${digit}，${size}期频率${ratio(w.frequency)}，实际${w.actual_window}期${w.complete_window === false ? '，窗口不足' : ''}`;
      return `<circle cx="${x}" cy="${y}" r="4" fill="${colors[index]}"><title>${escapeHtml(label)}</title></circle>`;
    }).join('');
    return `<path d="${path}" stroke="${colors[index]}" fill="none" stroke-width="2"/>${points}`;
  }).join('');
  const first = history[0]?.issue || '—', last = history[history.length - 1]?.issue || '—';
  const scope=result.kind==='latest_position_statistics'?
    `最新统计 · 截至 ${escapeHtml(result.data_cutoff_issue)}期 / ${escapeHtml(result.data_cutoff_date)} · 下一目标 ${escapeHtml(result.target_issue)}期（推算，非官方确认）`:
    `目标期 ${escapeHtml(result.target_issue)}（该期开奖前，不含当期结果）`;
  $('#position-charts').innerHTML = `<h2>当前遗漏（开奖前）</h2><p>${scope} · 历史样本 ${escapeHtml(result.history_draw_count)} 期。零遗漏表示上一期出现；从未出现的数字没有已定义的遗漏值，不绘制数值柱。</p>${bars}<h2>数字 ${digit} 的频率趋势</h2><p>最近最多30个开奖前统计点${result.kind==='latest_position_statistics'?'，含最新历史的只读重算点':''}；蓝色10期、橙色30期、绿色100期。选择数字可切换曲线，全部模式默认查看数字0。缺失数据保留断点，悬停圆点查看实际窗口。</p><svg class="position-trend" viewBox="0 0 760 260" role="img" aria-label="数字${digit}的开奖前频率趋势"><path d="M50,30V210H710" fill="none" stroke="#788596"/><text x="5" y="35">100%</text><text x="15" y="215">0%</text>${lines}<text x="50" y="245">${escapeHtml(first)}</text><text x="710" y="245" text-anchor="end">${escapeHtml(last)}</text></svg><details><summary>查看曲线数据（含不足窗口）</summary><div class="table-wrap"><table><thead><tr><th>目标期</th><th>10期频率 / 实际期数</th><th>30期频率 / 实际期数</th><th>100期频率 / 实际期数</th></tr></thead><tbody>${history.map(point => {
    const row = point.states?.find(item => item.digit === digit);
    return `<tr><td>${escapeHtml(point.issue)}${point.inferred?'（推算最新点）':''}</td>${sizes.map(size => { const w = row ? findWindow(row, size) : {}; return `<td>${ratio(w.frequency)} / ${w.actual_window ?? '—'}${w.complete_window === false ? '（不足）' : ''}</td>`; }).join('')}</tr>`;
  }).join('')}</tbody></table></div></details>`;
}

async function queryPosition() {
  await busy($('#position-query'), async () => {
    const request = beginRequest('position');
    state.positionResult = null;
    emptyView('#position-charts', '正在读取开奖前位置统计…');
    emptyView('#position-table', '正在读取开奖前位置统计…');
    try {
    if (!$('#position-issue').value) throw new Error('没有可查询的期号，请先检查当前彩种数据。');
    const issue=$('#position-issue').value,position=$('#position-name').value;
    const result = issue==='__latest__'?await api('latest_position_states',request.lottery,position):
      await api('position_states', request.lottery, issue, position);
    if (!currentRequest('position', request)) return;
    if(result.lottery_type&&result.lottery_type!==request.lottery||result.position&&result.position!==position||
      issue==='__latest__'&&(result.kind!=='latest_position_statistics'||result.target_issue_is_inferred!==true||!result.data_cutoff_issue)||
      issue!=='__latest__'&&result.target_issue&&result.target_issue!==issue)throw new Error('位置统计与当前彩种、位置或范围不一致。');
    if (!result.states?.length) { emptyView('#position-charts', '没有有效样本。'); emptyView('#position-table', '该期开奖前统计尚未构建或没有有效样本。'); return; }
    state.positionResult = result;
    renderPositionCharts();
    $('#position-table').innerHTML = `<table><thead><tr><th>数字</th><th>当前遗漏</th><th>10期次数/频率</th><th>30期次数/频率</th><th>100期次数/频率</th><th>遗漏分位</th><th>趋势</th></tr></thead><tbody>${result.states.map(row => {
      const w10=findWindow(row,10), w30=findWindow(row,30), w100=findWindow(row,100);
      const windowText = w => `${w.occurrence_count ?? '—'} / ${ratio(w.frequency)}${w.complete_window === false ? '（不足）' : ''}`;
      return `<tr><td><strong>${row.digit}</strong></td><td>${row.never_seen ? '从未出现' : row.current_gap}</td><td>${windowText(w10)}</td><td>${windowText(w30)}</td><td>${windowText(w100)}</td><td>${ratio(row.gap_percentile)}</td><td>${escapeHtml(({RISING:'上升', FALLING:'下降', FLAT:'平稳', MIXED:'混合', INSUFFICIENT:'样本不足'})[row.trend_state] || '—')}</td></tr>`;
    }).join('')}</tbody></table>`;
    } catch (error) { if (currentRequest('position', request)) { emptyView('#position-charts', errorMessage(error)); emptyView('#position-table', errorMessage(error)); toast(errorMessage(error)); } }
  });
}

const forecastFixedScope = '固定AI预测快照条件的历史覆盖检查：本条件使用保存的号码，不会逐期更新该快照条件，不能作为AI预测成绩。';
function renderForecastConditions() {
  const panel=$('#workbench-forecast');if(!panel)return;
  const entries=state.advancedRules.map((rule,index)=>({rule,index})).filter(e=>e.rule.type==='forecast');
  panel.hidden=!entries.length;
  panel.innerHTML=entries.map(({rule,index})=>{
    const s=rule.params.snapshot,row=s.forecast_sections.sections.find(r=>r.key===rule.params.section);
    return `<h3>已引用AI${escapeHtml(row.label)}快照</h3><p>${row.items.map(item=>escapeHtml(item.number)).join(' ')} · 开奖截点${escapeHtml(s.data_cutoff_issue)} / ${escapeHtml(s.data_cutoff_date)}</p><p>规则：${escapeHtml(row.basis)}</p><p>${forecastFixedScope} 继续添加条件会按工作台组合方式筛选；默认全部满足。</p><details><summary>查看计算来源</summary><p>${escapeHtml(s.method_version)} · ${s.model_evidence.training_samples}组训练样本 · 原直选${s.candidate_count}注 · 依据Hash ${escapeHtml(s.source_hash)}</p></details><button type="button" data-remove-forecast="${index}">移除此预测条件</button>`;
  }).join('');
}
async function transferForecast(section,button) {
  if(busy.pending.has(button))return;
  await busy(button,async()=>{
    const prediction=state.predictions[state.lotteryType];
    if(!state.predictionReady[state.lotteryType]||!prediction?.forecast_sections)throw new Error('请先生成当前彩种预测。');
    if(state.planMutation)throw new Error('方案正在保存，请完成后再新建草稿。');
    checkedForecastSections(prediction);
    const request=beginRequest('forecastTransfer'),revision=state.revision,plan=state.loadedPlan,
      nameRevision=state.planNameRevision,name=$('#plan-name').value;
    const current=()=>currentRequest('forecastTransfer',request)&&state.predictions[request.lottery]===prediction
      &&state.predictionReady[request.lottery]&&state.revision===revision&&state.loadedPlan===plan&&!state.planMutation
      &&state.planNameRevision===nameRevision&&$('#plan-name').value===name;
    try {
      const result=await api('forecast_condition',request.lottery,prediction.candidate_count,prediction.result_hash,
        {sections:prediction.forecast_sections.sections,model_evidence:prediction.model_evidence},section);
      if(!current())return;
      const rule=result.condition,s=rule?.params?.snapshot;
      if(result.source!=='all'||rule?.type!=='forecast'||rule.params.section!==section||s?.lottery_type!==request.lottery
        ||s.source_hash!==prediction.result_hash||s.candidate_count!==prediction.candidate_count)throw new Error('预测条件与当前彩种、栏目或来源不一致。');
      recordWorkbenchHistory();workbenchHistory.restoring=true;
      try {
        state.requests.planLoad=(state.requests.planLoad||0)+1;state.loadedPlan=null;
        resetWorkbench();selectSource('all');state.advancedRules=[JSON.parse(JSON.stringify(rule))];
        renderAdvancedRules();updateConditionSummary();
        $('#plan-name').value=`${state.lotteryLabel} ${s.forecast_sections.sections.find(r=>r.key===section).label} ${s.data_cutoff_issue}期快照缩水`;
        $('#plan-status').textContent='新的未保存草稿；原已保存方案不改变。继续调整后筛选、保存。';
      }finally{workbenchHistory.restoring=false;}
      recordWorkbenchHistory();selectPage('workbench');
      $('#forecast-transfer-status').textContent=`已建立固定预测快照草稿 · 本栏范围${result.allowed_count}个定位号码。${result.scope_note}`;
      await evaluate();
    }catch(error){if(current())$('#forecast-transfer-status').textContent=errorMessage(error);}
  });
}

function updateForwardSeal() {
  const result=state.predictions[state.lotteryType],button=$('#forward-seal');
  if(button)button.disabled=busy.pending.has(button)||busy.pending.has($('#home-generate'))||busy.pending.has($('#prediction-generate'))||!state.predictionReady[state.lotteryType]||!result?.forecast_sections
    ||result.method_version!=='CNB_V1:n500:l3:a1'||typeof window.pywebview?.api?.seal_forward_forecast!=='function';
}
function resetForwardForecasts(message) {
  for(const name of ['forwardSeal','forwardList','forwardReconcile'])state.requests[name]=(state.requests[name]||0)+1;
  state.forwardPage=1;state.forwardPages=1;
  if(!$('#forward-status'))return;
  $('#forward-status').textContent=message;$('#forward-records').innerHTML='';$('#forward-summary').innerHTML='';
  $('#forward-page').textContent='尚未读取';$('#forward-prev').disabled=true;$('#forward-next').disabled=true;
  $('#forward-seal-status').textContent='请为当前彩种生成预测；已留档记录保持原样。';updateForwardSeal();
}
async function sealCurrentForward(result=state.predictions[state.lotteryType]) {
  if(typeof window.pywebview?.api?.seal_forward_forecast!=='function'||!result?.forecast_sections||!state.predictionReady[state.lotteryType])return;
  const request=beginRequest('forwardSeal');
  const current=()=>currentRequest('forwardSeal',request)&&state.predictionReady[request.lottery]&&state.predictions[request.lottery]===result;
  $('#forward-seal-status').textContent='正在核对最新数据并留档八栏…';
  try {
    const saved=await api('seal_forward_forecast',request.lottery,result.candidate_count,result.result_hash,
      {sections:result.forecast_sections.sections,model_evidence:result.model_evidence});
    if(!current())return;
    const record=saved.record,snapshot=record?.snapshot;
    if(snapshot?.lottery_type!==request.lottery||snapshot.candidate_count!==result.candidate_count||snapshot.source_hash!==result.result_hash
      ||snapshot.target_issue!==result.target_issue)throw new Error('留档与当前预测来源不一致。');
    $('#forward-seal-status').textContent=`${saved.already_saved?'已保留首次留档，未覆盖':'八栏已留档'} · 目标${snapshot.target_issue}期（推算） · 首次时间${record.created_at} · ${record.notice}`;
    await loadForwardForecasts();
  }catch(error){if(current())$('#forward-seal-status').textContent=`留档未完成：${errorMessage(error)} 当前候选仍可查看。`;}
}
async function loadForwardForecasts(page=1) {
  if(!$('#forward-status'))return;
  if(typeof window.pywebview?.api?.forward_forecasts!=='function'){
    $('#forward-status').textContent='此版本连接尚未支持预测留档，请使用新候选版。';updateForwardSeal();return;
  }
  const request=beginRequest('forwardList');
  $('#forward-prev').disabled=true;$('#forward-next').disabled=true;
  $('#forward-status').textContent='正在读取留档并对照已有开奖…';
  try {
    const result=await api('forward_forecasts',request.lottery,page);
    if(!currentRequest('forwardList',request))return;
    if(result.lottery_type!==request.lottery||result.page!==page||!Number.isInteger(result.pages)||result.pages<page
      ||!Array.isArray(result.rows)||result.rows.length>50||!Array.isArray(result.statistics)||result.statistics.length!==32
      ||result.rows.some(row=>row.record?.snapshot?.lottery_type!==request.lottery))throw new Error('预测留档返回彩种或页码不一致。');
    state.forwardPage=result.page;state.forwardPages=result.pages;
    $('#forward-status').textContent=`本彩种共${result.total}条留档${result.unreadable_count?`；${result.unreadable_count}个留档文件不可读取`:''}${result.truncated?'；仅扫描最近200个文件':''}。${result.notice}`;
    $('#forward-strict-note').textContent=result.strict_note;
    const stats=result.statistics.filter(row=>row.evaluable_periods>0);
    $('#forward-summary').innerHTML=stats.length?`<table><thead><tr><th>直选数量</th><th>预测栏</th><th>严格可评价</th><th>覆盖</th><th>覆盖率</th><th>随机基准</th></tr></thead><tbody>${stats.map(r=>`<tr><td>${r.candidate_count}</td><td>${escapeHtml(r.label)}</td><td>${r.evaluable_periods}</td><td>${r.covered_periods}</td><td>${ratio(r.coverage)}</td><td>${ratio(r.uniform_baseline)}</td></tr>`).join('')}</tbody></table>`:'<p>尚无符合时间与开奖核验要求的前瞻样本，不能给出有效覆盖率。</p>';
    const statuses={waiting:'待目标期开奖',compared:'已对照',draw_changed:'当前开奖不同或缺失，保留原对照待复核',source_conflict:'开奖来源冲突，未计统计',unreadable:'对照未通过核验'};
    const times={prior_day:'早于开奖日期留档',same_day_unconfirmed:'同日留档，开奖前时间未确认',late:'留档晚于开奖日期，未计统计'};
    $('#forward-records').innerHTML=result.rows.length?result.rows.map(row=>{
      const record=row.record,s=record.snapshot,o=row.comparison?.observation;
      return `<details class="data-card"><summary>${escapeHtml(s.target_issue)}期（推算） · 直选${s.candidate_count}注 · ${statuses[row.status]||'状态不可用'}</summary><p>首次留档：${escapeHtml(record.created_at)} · 数据截点：${escapeHtml(s.data_cutoff_issue)} / ${escapeHtml(s.data_cutoff_date)}</p><p>${o?`开奖号 ${escapeHtml(o.draw.number)} · ${escapeHtml(o.draw.draw_date)} · ${times[o.time_status]} · ${row.strict_evaluable?'已计严格统计':'仅展示对照，未计严格统计'} · 开奖状态 ${escapeHtml(row.current_verify_status??'当前缺失')}`:'留档后尚未读取该期开奖。'}${row.error?escapeHtml(row.error):''}</p><table><thead><tr><th>预测栏</th><th>首次预测</th><th>对照结果</th><th>计算依据</th></tr></thead><tbody>${s.forecast_sections.sections.map((section,i)=>`<tr><td>${escapeHtml(section.label)}</td><td>${section.items.map(item=>escapeHtml(item.number)).join(' ')}</td><td>${o?(o.covered[i]?'已覆盖':'未覆盖'):'待开奖'}</td><td>${escapeHtml(section.basis)}</td></tr>`).join('')}</tbody></table><p>同一AI模型 ${escapeHtml(s.method_version)} · 500组训练样本 · 依据Hash ${escapeHtml(s.source_hash)}</p></details>`;
    }).join(''):'<p>尚无留档；点击“生成研究候选”后可自动保存八栏预测。</p>';
    $('#forward-page').textContent=`第${result.page}/${result.pages}页 · 共${result.total}条`;
    $('#forward-prev').disabled=page<=1;$('#forward-next').disabled=page>=result.pages;
  }catch(error){if(currentRequest('forwardList',request)){ $('#forward-status').textContent=errorMessage(error);$('#forward-records').innerHTML='';$('#forward-summary').innerHTML=''; }}
}
async function reconcileForwardAfterUpdate() {
  if(typeof window.pywebview?.api?.forward_forecasts!=='function')return;
  const request=beginRequest('forwardReconcile');
  for(const lottery of ['FC3D','PL3']){
    if(!currentRequest('forwardReconcile',request))return;
    if(lottery===state.lotteryType){
      const work=loadForwardForecasts(),visibleRequest=state.requests.forwardList;
      await work;
      if(!currentRequest('forwardReconcile',request)||state.requests.forwardList!==visibleRequest)return;
    }
    else {
      const visibleRequest=state.requests.forwardList;
      try{await api('forward_forecasts',lottery,1);}catch(error){
        if(currentRequest('forwardReconcile',request)&&state.requests.forwardList===visibleRequest&&$('#forward-status'))
          $('#forward-status').textContent=`另一个彩种的留档对照未完成：${errorMessage(error)}`;
      }
      if(!currentRequest('forwardReconcile',request)||state.requests.forwardList!==visibleRequest)return;
    }
  }
}
function bindForwardForecasts() {
  $('#forward-seal')?.addEventListener('click',()=>busy($('#forward-seal'),()=>sealCurrentForward()));
  $('#forward-refresh')?.addEventListener('click',reconcileForwardAfterUpdate);
  $('#forward-prev')?.addEventListener('click',()=>loadForwardForecasts(state.forwardPage-1));
  $('#forward-next')?.addEventListener('click',()=>loadForwardForecasts(state.forwardPage+1));
  updateForwardSeal();
}

const forecastKeys = ['dan','pairs','selected','four','five','six','direct','group3'];
function resetForecastHistory(message='请选择一条已存检验或重新执行。', clearList=false) {
  for(const lane of ['forecastReplay','forecastDetails','forecastList'])state.requests[lane]=(state.requests[lane]||0)+1;
  state.forecastStudy=null;state.forecastPage=1;state.forecastPages=1;
  if(!$('#forecast-history-status'))return;
  $('#forecast-history-status').textContent=message;
  $('#forecast-history-summary').innerHTML='';$('#forecast-history-periods').innerHTML='';
  $('#forecast-history-page').textContent='尚未读取八栏明细';
  $('#forecast-history-prev').disabled=true;$('#forecast-history-next').disabled=true;
  if(clearList){$('#forecast-history-record').innerHTML='';$('#forecast-history-list-status').textContent='';}
}
function forecastControls() {
  const mode=$('#forecast-history-window').value;
  return [Number($('#forecast-history-count').value),mode==='custom'?null:Number(mode),
    mode==='custom'?$('#forecast-history-start').value.trim():'',mode==='custom'?$('#forecast-history-end').value.trim():''];
}
function forecastOption(row) {
  const s=row.selection;
  return `<option value="${escapeHtml(row.research_id)}">${escapeHtml(s.sample_start_issue)}–${escapeHtml(s.sample_end_issue)} · ${s.actual_periods}期 · 直选${row.candidate_count}注 · ${escapeHtml(row.created_at)}</option>`;
}
async function loadForecastChecks() {
  if(!$('#forecast-history-record'))return;
  const supported=typeof window.pywebview?.api?.list_forecast_checks==='function';
  $('#forecast-history-run').disabled=!supported||busy.pending.has($('#forecast-history-run'));
  $('#forecast-history-view').disabled=!supported;$('#forecast-history-refresh').disabled=!supported;
  if(!supported){$('#forecast-history-list-status').textContent='此版本连接尚未支持八栏历史检验，请使用新候选版本。';return;}
  resetForecastHistory('正在读取本彩种已存八栏检验…');
  const request=beginRequest('forecastList');
  const selected=$('#forecast-history-record').value;
  try {
    const result=await api('list_forecast_checks',request.lottery);
    if(!currentRequest('forecastList',request))return;
    if(!Array.isArray(result.records)||result.records.some(r=>r.lottery_type!==request.lottery))throw new Error('八栏检验列表彩种无效。');
    $('#forecast-history-record').innerHTML=result.records.map(forecastOption).join('');
    if(result.records.some(r=>r.research_id===selected))$('#forecast-history-record').value=selected;
    $('#forecast-history-list-status').textContent=`已保存${result.records.length}条本彩种检验${result.unreadable_count?`；${result.unreadable_count}个文件损坏或不可读取，未展示`:''}${result.truncated?'；仅扫描最近200个文件':''}。`;
    $('#forecast-history-status').textContent=result.records.length?'选择记录后点“查看已存检验”，只读取该记录的范围与数量。':'尚无八栏检验，选择范围后点“检验八栏预测”。';
  }catch(error){if(currentRequest('forecastList',request))$('#forecast-history-list-status').textContent=errorMessage(error);}
}
function renderForecastHistory(result,lottery) {
  const study=result?.study, rows=result?.periods, stats=study?.statistics;
  if(study?.lottery_type!==lottery||study.method_version!=='CNB_V1:n500:l3:a1'||![10,20,50,100].includes(study.candidate_count)
    ||!Array.isArray(stats)||stats.length!==8||stats.some((r,i)=>r.key!==forecastKeys[i])
    ||!Array.isArray(rows)||rows.length>50||!Number.isInteger(result.page)||!Number.isInteger(result.pages)
    ||result.page<1||result.page>result.pages||result.total!==study.selection.actual_periods
    ||rows.some(r=>r.covered!==null&&(!Array.isArray(r.covered)||r.covered.length!==8||r.covered.some(x=>typeof x!=='boolean')
       ||!Array.isArray(r.sections)||r.sections.length!==8||r.sections.some(v=>!Array.isArray(v)||v.some(n=>typeof n!=='string'||!/^\d{1,6}$/.test(n))))))
    throw new Error('八栏检验返回内容、彩种或版本不一致。');
  const selection=study.selection;
  state.forecastStudy=study.research_id;state.forecastPage=result.page;state.forecastPages=result.pages;
  $('#forecast-history-status').textContent=`${lottery==='FC3D'?'福彩3D':'排列3'} · ${selection.sample_start_issue}–${selection.sample_end_issue} · 实际${selection.actual_periods}期${selection.complete_window?'':'（所选窗口样本不足）'} · 直选${study.candidate_count}注 · 每期503期历史、500组训练样本 · ${result.notice} · 记录 ${study.research_id}`;
  $('#forecast-history-summary').innerHTML=`<table><thead><tr><th>预测栏</th><th>命中次数/可检查期数</th><th>命中率</th><th>随机基准</th><th>差值</th><th>平均符合条件的号码数</th><th>最长连续未命中</th><th>跳过</th></tr></thead><tbody>${stats.map(r=>`<tr><td>${escapeHtml(r.label)}<br><small>${escapeHtml(r.rule)}</small></td><td>${r.covered_periods}/${r.evaluable_periods}</td><td>${ratio(r.coverage)}</td><td>${ratio(r.uniform_baseline)}</td><td>${r.difference==null?'—':`${(r.difference*100).toFixed(2)}个百分点`}</td><td>${numberValue(r.mean_population,1)} / 1000</td><td>${r.longest_miss_run}期</td><td>${r.skipped_periods}期</td></tr>`).join('')}</tbody></table>`;
  $('#forecast-history-periods').innerHTML=`<table><thead><tr><th>目标期</th><th>开奖号</th><th>开奖前截点</th>${stats.map(r=>`<th>${escapeHtml(r.label)}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr><td>${escapeHtml(r.issue)}<br>${escapeHtml(r.draw_date)}</td><td>${escapeHtml(r.draw_number)}</td><td>${escapeHtml(r.as_of_issue??'无前期')}<br><small>${r.training_start_issue?`训练起点${escapeHtml(r.training_start_issue)}`:''}</small></td>${r.covered===null?`<td colspan="8">未评价：${escapeHtml(r.skip_reason)}</td>`:r.covered.map((hit,i)=>`<td><details><summary>${hit?'命中':'未命中'}</summary><p>${r.sections[i].map(escapeHtml).join(' ')}</p><small>依据Hash ${escapeHtml(r.source_hash)}</small></details></td>`).join('')}</tr>`).join('')}</tbody></table>`;
  $('#forecast-history-page').textContent=`第${result.page}/${result.pages}页 · 共${result.total}期`;
  $('#forecast-history-prev').disabled=result.page<=1;$('#forecast-history-next').disabled=result.page>=result.pages;
}
async function runForecastHistory() {
  if(busy.pending.has($('#forecast-history-run')))return;
  await busy($('#forecast-history-run'),async()=>{
    resetForecastHistory('正在逐期开奖前训练并检验八栏，请稍候…');
    const request=beginRequest('forecastReplay'),controls=forecastControls();
    try {
      const result=await api('replay_forecast_sections',request.lottery,...controls);
      if(!currentRequest('forecastReplay',request)||JSON.stringify(controls)!==JSON.stringify(forecastControls()))return;
      renderForecastHistory(result,request.lottery);
      const option=document.createElement('option');option.value=result.study.research_id;
      option.textContent=`${result.study.selection.sample_start_issue}–${result.study.selection.sample_end_issue} · 直选${result.study.candidate_count}注 · ${result.study.created_at}`;
      $('#forecast-history-record').append(option);$('#forecast-history-record').value=result.study.research_id;
      $('#forecast-history-list-status').textContent='新检验已独立保存，重启后可读取；读取不会重算当前预测。';
    }catch(error){if(currentRequest('forecastReplay',request))$('#forecast-history-status').textContent=errorMessage(error);}
  });
}
async function viewForecastHistory(page=1) {
  const identifier=$('#forecast-history-record').value;
  if(!identifier){toast('请先选择已存八栏检验。');return;}
  resetForecastHistory('正在读取并核验已存八栏检验…');
  const request=beginRequest('forecastDetails');
  $('#forecast-history-prev').disabled=true;$('#forecast-history-next').disabled=true;
  $('#forecast-history-status').textContent='正在读取并核验已存八栏检验…';
  try {
    const result=await api('forecast_check_details',identifier,request.lottery,page);
    if(!currentRequest('forecastDetails',request)||$('#forecast-history-record').value!==identifier)return;
    if(result.study?.research_id!==identifier||result.page!==page)throw new Error('八栏检验记录或页码不一致。');
    renderForecastHistory(result,request.lottery);
  }catch(error){if(currentRequest('forecastDetails',request))resetForecastHistory(errorMessage(error));}
}
function bindForecastHistory() {
  $('#forecast-history-run')?.addEventListener('click',runForecastHistory);
  $('#forecast-history-view')?.addEventListener('click',()=>viewForecastHistory(1));
  $('#forecast-history-refresh')?.addEventListener('click',loadForecastChecks);
  $('#forecast-history-record')?.addEventListener('change',()=>resetForecastHistory());
  for(const selector of ['#forecast-history-count','#forecast-history-window','#forecast-history-start','#forecast-history-end'])
    $(selector)?.addEventListener('change',()=>{
      const custom=$('#forecast-history-window').value==='custom';
      $('#forecast-history-start').disabled=!custom;$('#forecast-history-end').disabled=!custom;
      resetForecastHistory('检验范围或数量已改变，请重新执行；已存检验可独立查看。');
    });
  $('#forecast-history-prev')?.addEventListener('click',()=>viewForecastHistory(state.forecastPage-1));
  $('#forecast-history-next')?.addEventListener('click',()=>viewForecastHistory(state.forecastPage+1));
}

async function loadBacktests() {
  loadForecastChecks();
  const request = beginRequest('backtestList');
  resetBacktest('正在读取当前彩种的历史回测记录…');
  $('#backtest-run').innerHTML = '';
  let allRuns=[],checks={records:[]},warnings=[];
  const localSupported=typeof window.pywebview?.api?.list_plan_checks==='function';
  try {allRuns=await api('list_backtests');} catch(error){warnings.push(`原回测记录暂不可读取：${errorMessage(error)}`);}
  if(!currentRequest('backtestList',request))return;
  if(localSupported) {
    try {checks=await api('list_plan_checks',request.lottery);}
    catch(error){warnings.push(`本机检查记录暂不可读取：${errorMessage(error)}`);}
  }
  if(!currentRequest('backtestList',request))return;
  if(typeof window.pywebview?.api?.list_prediction_checks==='function') {
    try {
      const predicted=await api('list_prediction_checks',request.lottery);
      checks={records:[...(checks.records||[]),...(predicted.records||[]).map(row=>({...row,prediction:true}))],
        unreadable_count:(checks.unreadable_count||0)+(predicted.unreadable_count||0),
        truncated:checks.truncated||predicted.truncated};
    } catch(error){warnings.push(`推荐缩水检查暂不可读取：${errorMessage(error)}`);}
  }
  if(!currentRequest('backtestList',request))return;
  const runs=allRuns.filter(run=>run.lottery_type===request.lottery);
  const locals=(checks.records||[]).filter(record=>record.lottery_type===request.lottery)
    .sort((a,b)=>String(b.created_at).localeCompare(String(a.created_at))||String(b.research_id).localeCompare(String(a.research_id)));
  const names={FC3D:'福彩3D',PL3:'排列3'};
  $('#backtest-run').innerHTML=(locals.length?`<optgroup label="本机方案检查" data-local-checks>${locals.map(localCheckOption).join('')}</optgroup>`:'')+
    (runs.length?`<optgroup label="原数据库回测（高级）">${runs.map(run=>`<option value="${run.id}">${names[run.lottery_type]} · 第${escapeHtml(run.start_issue)}期至第${escapeHtml(run.end_issue)}期（记录${run.id}）</option>`).join('')}</optgroup>`:'');
  resetBacktest(runs.length||locals.length?'请选择一条记录，然后点击“查看结果”。':localSupported?
    '还没有本机历史检查。先筛选、保存方案并回放一次，检查结果会保存在这里。':'当前彩种没有已有回测记录。');
  $('#backtest-query').disabled=!(runs.length||locals.length);
  if(checks.unreadable_count)warnings.push(`${checks.unreadable_count}个检查文件无法通过校验，原文件已保留。`);
  if(checks.truncated)warnings.push('仅列出最近200个检查文件，较早文件仍保存在本机。');
  if($('#check-list-status'))$('#check-list-status').textContent=warnings.join(' ');
}

function localCheckOption(record) {
  const stamp=new Date(record.created_at);
  const time=Number.isNaN(stamp.getTime())?'时间未记录':stamp.toLocaleString('zh-CN',{hour12:false});
  return `<option value="${record.prediction?'prediction':'local'}:${escapeHtml(record.research_id)}">${record.prediction?'推荐缩水 · ':''}${escapeHtml(record.plan_name)} · 版本${escapeHtml(record.plan_revision)} · ${escapeHtml(record.start_issue)}–${escapeHtml(record.end_issue)} · ${escapeHtml(time)}</option>`;
}

function registerLocalCheck(result) {
  const predicted=result.kind==='local_prediction_replay';
  if(typeof window.pywebview?.api?.[predicted?'prediction_check_details':'plan_check_details']!=='function'||!result.input?.plan)return;
  state.requests.backtestList=(state.requests.backtestList||0)+1;
  const plan=result.input.plan;
  const selector=$('#backtest-run');
  const value=`${predicted?'prediction':'local'}:${result.research_id}`;
  if(![...selector.querySelectorAll('option')].some(option=>option.value===value)) {
    let group=selector.querySelector('optgroup[data-local-checks]');
    if(!group){group=document.createElement('optgroup');group.setAttribute('label','本机方案检查');group.setAttribute('data-local-checks','');selector.append(group);}
    const record={prediction:predicted,research_id:result.research_id,plan_name:plan.name,plan_revision:plan.revision,created_at:result.created_at,
      start_issue:result.selection.sample_start_issue,end_issue:result.selection.sample_end_issue};
    const option=document.createElement('option');option.value=value;
    const temp=document.createElement('select');temp.innerHTML=localCheckOption(record);option.textContent=temp.querySelector('option').textContent;
    group.append(option);
  }
  selector.value=value;$('#backtest-query').disabled=false;
  state.requests.backtest=(state.requests.backtest||0)+1;
  state.backtestRun=null;state.backtestPage=1;state.backtestPages=1;state.backtestTotal=0;state.backtestLoading=false;
  $('#backtest-conclusion').className='conclusion-card empty-conclusion';
  $('#backtest-conclusion').textContent='本次检查已保存。即时结果在下方；也可点击“查看结果”读取保存记录。';
  $('#backtest-metrics').innerHTML='';emptyView('#backtest-table','点击“查看结果”读取所选检查。');
  if($('#saved-check-note'))$('#saved-check-note').textContent='';
  updateBacktestPager();
  if($('#check-list-status'))$('#check-list-status').textContent='本次检查已保存并加入列表；下次打开软件也可读取。';
}

async function verifyWorkbenchPlan() {
  const button=$('#result-plan-verify');
  if(busy.pending.has(button)||busy.pending.has($('#backtest-replay')))return;
  await busy(button,async()=>{
    const plan=state.loadedPlan;
    if(state.planMutation)throw new Error('方案正在保存，请稍后验证。');
    if(!plan || plan.lottery_type!==state.lotteryType) {
      $('.plan-drawer').open=true; $('.plan-drawer').scrollIntoView?.({behavior:'smooth',block:'start'});
      throw new Error('请先筛选并保存当前彩种方案，或读取已保存的方案。');
    }
    if(plan.source?.kind!=='all'&&typeof window.pywebview?.api?.replay_prediction_plan!=='function')throw new Error('此版本没有推荐候选历史验证入口，请使用支持该功能的新候选版。');
    if(plan.form?.advanced_rules?.some(rule=>rule.type==='direction'))throw new Error('手动走势没有逐期参考，暂不能验证历史；请使用其他静态缩水条件。');
    const navigation=selectPage('backtests');
    const request=beginRequest('workbenchVerify');
    await navigation;
    if(!currentRequest('workbenchVerify',request)||state.loadedPlan!==plan||$('.page.active')?.id!=='page-backtests')return;
    $('#backtest-window').value='50';
    for(const id of ['#backtest-start','#backtest-end']) {$(id).value='';$(id).disabled=true;}
    await replaySavedPlan();
  });
}

function renderReplaySummary(stats) {
  const target=$('#backtest-replay-summary');if(!target)return;
  const cards=[['留下开奖号',`${stats.covered_periods ?? '—'} / ${stats.evaluable_periods ?? '—'}期`],
    ['历史覆盖率',ratio(stats.coverage)],['平均保留注数',numberValue(stats.retained_count_distribution?.mean,1)],
    ['随机基准覆盖率',ratio(stats.random_baseline_coverage)],
    ['最长连续未覆盖',`${stats.uncovered_streaks?.longest ?? '—'}期`]];
  target.innerHTML=cards.map(([label,value])=>`<div class="metric"><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></div>`).join('');
}

async function replaySavedPlan() {
  await busy($('#backtest-replay'), async () => {
    const plan = state.loadedPlan;
    if (!plan || plan.lottery_type !== state.lotteryType) throw new Error('请先读取当前彩种已保存的完整方案版本。');
    const mode = $('#backtest-window').value;
    if (!mode) throw new Error('本地回放请选择近期窗口或自定义区间。');
    state.requests.backtestList=(state.requests.backtestList||0)+1;
    const request = beginRequest('planReplay');
    const start = mode === 'custom' ? $('#backtest-start').value : '';
    const end = mode === 'custom' ? $('#backtest-end').value : '';
    $('#backtest-replay-results').innerHTML = '';
    if($('#backtest-replay-summary'))$('#backtest-replay-summary').innerHTML='';
    $('#backtest-replay-status').textContent = '正在逐期回放已保存版本…';
    try {
      const predicted=plan.source?.kind==='prediction';
      const result = await api(predicted?'replay_prediction_plan':'replay_saved_plan', plan.plan_id, plan.revision, state.lotteryType,
        mode === 'custom' ? null : Number(mode), start, end);
      if (!currentRequest('planReplay', request) || state.loadedPlan !== plan || state.lotteryType !== plan.lottery_type) return;
      const stats = result.statistics;
      const selection = result.selection;
      registerLocalCheck(result);
      renderReplaySummary(stats);
      $('#backtest-replay-status').textContent = `${predicted?`推荐缩水历史验证（每期开奖前${result.input.history_window||30}期重建候选）`:'本地研究回放'}：${plan.name} 第 ${plan.revision} 版 · ${selection.sample_start_issue} 至 ${selection.sample_end_issue} · 实际 ${selection.actual_periods} 期${selection.complete_window ? '' : '（窗口样本不足）'} · 可评价 ${stats.evaluable_periods} 期，跳过 ${stats.skipped_periods} 期 · ${result.input.method_name||''} · 覆盖率 ${ratio(stats.coverage)} · 研究标识 ${result.research_id} · 策略 Hash ${result.input.strategy_hash}`;
      $('#backtest-replay-results').innerHTML = `<table><thead><tr><th>目标期号</th><th>开奖前截点</th><th>开奖号</th><th>保留数量</th><th>结果</th><th>跳过原因</th></tr></thead><tbody>${result.periods.map(row => `<tr><td>${escapeHtml(row.target_issue)}</td><td>${escapeHtml(row.as_of_issue ?? '无前期')}</td><td>${escapeHtml(row.draw_number ?? '')}</td><td>${row.retained_count ?? '—'}</td><td>${row.covered == null ? '未评价' : row.covered ? '已覆盖' : '未覆盖'}</td><td>${escapeHtml(row.error_detail || row.skip_reason || '')}</td></tr>`).join('')}</tbody></table>`;
      if(plan.form?.advanced_rules?.some(rule=>rule.type==='forecast'))
        $('#backtest-replay-status').textContent=forecastFixedScope+' '+$('#backtest-replay-status').textContent;
    } catch (error) {
      if (currentRequest('planReplay', request) && state.loadedPlan === plan) {
        $('#backtest-replay-status').textContent = errorMessage(error);
        throw error;
      }
    }
  });
}

async function queryBacktest(page = 1) {
  if(/^(local|prediction):/.test($('#backtest-run').value))return queryLocalCheck(page);
  const runId = Number($('#backtest-run').value);
  if (!Number.isInteger(page) || page < 1) return;
  if (state.backtestRun !== runId) page = 1;
  else if (page > state.backtestPages || state.backtestLoading) return;
  await busy($('#backtest-query'), async () => {
    if (state.backtestRun !== runId) resetBacktest('正在读取历史检查结果…');
    state.backtestRun = runId;
    state.backtestLoading = true;
    updateBacktestPager();
    emptyView('#backtest-table', '正在读取期级结果…');
    const request = beginRequest('backtest');
    try {
    if (!Number.isInteger(runId) || runId <= 0) throw new Error('没有可查询的回测记录。');
    const mode = $('#backtest-window').value;
    const result = await api('backtest_details', runId, page, mode && mode !== 'custom' ? Number(mode) : null, mode === 'custom' ? $('#backtest-start').value : '', mode === 'custom' ? $('#backtest-end').value : '');
    if (!currentRequest('backtest', request) || Number($('#backtest-run').value) !== runId) return;
    if (result.run?.lottery_type !== request.lottery || result.run?.id !== runId) throw new Error('回测结果与当前彩种或记录不匹配，已停止显示。');
    renderBacktest(result);
    } catch (error) { if (currentRequest('backtest', request)) { resetBacktest(errorMessage(error)); toast(errorMessage(error)); } }
    finally { if (currentRequest('backtest', request)) { state.backtestLoading = false; updateBacktestPager(); } }
  });
}

async function queryLocalCheck(page=1) {
  const selected=$('#backtest-run').value;
  if(!Number.isInteger(page)||page<1)return;
  if(state.backtestRun!==selected)page=1;
  else if(page>state.backtestPages||state.backtestLoading)return;
  await busy($('#backtest-query'),async()=>{
    if(state.backtestRun!==selected)resetBacktest('正在读取本机已保存检查…');
    state.backtestRun=selected;state.backtestLoading=true;updateBacktestPager();
    const request=beginRequest('backtest');const mode=$('#backtest-window').value;
    try {
      const predicted=selected.startsWith('prediction:');
      const result=await api(predicted?'prediction_check_details':'plan_check_details',selected.slice(predicted?11:6),request.lottery,page,
        mode&&mode!=='custom'?Number(mode):null,mode==='custom'?$('#backtest-start').value:'',mode==='custom'?$('#backtest-end').value:'');
      if(!currentRequest('backtest',request)||$('#backtest-run').value!==selected)return;
      if(result.kind!=='saved_local_check'||result.run?.id!==selected||result.run?.lottery_type!==request.lottery)throw new Error('本机历史检查与所选记录或彩种不一致。');
      renderBacktest(result);
      const record=result.saved_check;
      if($('#saved-check-note'))$('#saved-check-note').textContent=predicted?
        `推荐缩水检查（原候选${record.candidate_count}个，每期开奖前${record.history_window||30}期重建）：${record.plan_name} · 版本${record.plan_revision}；${record.method_name||'Z30对照'}；保存时截止${record.data_cutoff_issue}期（${record.data_cutoff_date}）。查看当时保存的结果并校验保存的开奖前依据，不会读取新开奖；当前未保存编辑不参与。原检查含${record.actual_periods}期，选择更大窗口不会补算新开奖。`:
        `本机保存检查：${record.plan_name} · 版本${record.plan_revision}；保存时截止${record.data_cutoff_issue}期（${record.data_cutoff_date}）。只查看当时保存的结果，不会重新逐期回放或读取新开奖；当前未保存编辑不参与。原检查含${record.actual_periods}期，选择更大窗口不会补算新开奖。`;
    } catch(error){if(currentRequest('backtest',request)){resetBacktest(errorMessage(error));toast(errorMessage(error));}}
    finally {if(currentRequest('backtest',request)){state.backtestLoading=false;updateBacktestPager();}}
  });
}

function renderBacktest(result) {
    const selection = result.selection;
    if (selection) $('#backtest-selection').textContent = `已有记录统计：${selection.sample_start_issue ?? '—'} 至 ${selection.sample_end_issue ?? '—'}，实际 ${selection.actual_periods} 期${selection.complete_window ? '' : '（窗口样本不足）'}`;
    state.backtestRun = result.run.id;
    state.backtestPage = result.page ?? 1;
    state.backtestPages = result.pages ?? 1;
    state.backtestTotal = result.total ?? 0;
    const summary = result.summary || {};
    const hasSample = summary.evaluable > 0 && summary.coverage != null && summary.baseline != null
      && Number.isFinite(Number(summary.coverage)) && Number.isFinite(Number(summary.baseline));
    const coveredCount = hasSample ? Math.round(summary.coverage * summary.evaluable) : '—';
    const excess = hasSample ? summary.coverage - summary.baseline : null;
    const significant = hasSample && summary.z_score != null && Math.abs(summary.z_score) >= 1.96;
    let title;
    let detail;
    let tone;
    if (!hasSample || summary.z_score == null) {
      title = '统计依据不足，不能判断是否超过随机基准';
      detail = !hasSample ? '没有可评价期数或统计字段缺失；未评价不等于未覆盖。' : 'Z-score尚无有效统计依据，不作显著性判断。';
      tone = 'caution';
    } else if (!significant) {
      title = '这段历史中，没有看到明显超过随机筛选的证据';
      detail = `实际覆盖率比随机基准${excess >= 0 ? '高' : '低'} ${ratio(Math.abs(excess))}，但差异不足以判定为稳定优势。`;
      tone = 'caution';
    } else if (summary.z_score > 0) {
      title = '这段历史中，表现高于随机基准';
      detail = `实际覆盖率比随机基准高 ${ratio(excess)}。这只说明所选历史区间，不代表未来仍会保持。`;
      tone = 'good';
    } else {
      title = '这段历史中，表现低于随机基准';
      detail = `实际覆盖率比随机基准低 ${ratio(Math.abs(excess))}。`;
      tone = 'bad';
    }
    if(result.saved_check?.forecast_snapshot){
      title='固定预测快照条件的历史覆盖检查';
      detail=result.saved_check.scope_note||forecastFixedScope;
      tone='caution';
    }
    const retentionWarning = summary.mean_retained >= 500
      ? `注意：平均每期保留 ${numberValue(summary.mean_retained, 0)} 个号码，号码较多，本来就更容易覆盖。`
      : `平均每期保留 ${numberValue(summary.mean_retained, 0)} 个号码。`;
    $('#backtest-conclusion').className = `conclusion-card ${tone}`;
    $('#backtest-conclusion').innerHTML = `<h2>${title}</h2><p>${coveredCount} / ${summary.evaluable ?? '—'} 期的开奖号仍在筛选结果中。</p><p>${detail}</p><p><strong>${retentionWarning}</strong></p><p>最长连续 ${summary.longest_miss ?? '—'} 期没有覆盖。</p>`;
    const cards = [
      ['历史覆盖情况', `${coveredCount}/${summary.evaluable ?? '—'}期`, '实际开奖号落在当期保留号码中'],
      ['平均每期保留', `${numberValue(summary.mean_retained, 0)}个`, `最少${summary.min_retained ?? '—'}个，最多${summary.max_retained ?? '—'}个`],
      ['随机筛选参考', ratio(summary.baseline), '按照相同保留数量随机选择的理论参考'],
      ['最长连续未覆盖', `${summary.longest_miss ?? '—'}期`, '连续多少期没有留下实际开奖号'],
    ];
    $('#backtest-metrics').innerHTML = cards.map(([label,value,help]) => `<div class="metric"><span>${label}</span><strong>${value}</strong><small>${help}</small></div>`).join('');
    $('#backtest-table').innerHTML = `<table><thead><tr><th>期号</th><th>开奖日期</th><th>实际开奖号</th><th>当期保留号码</th><th>结果</th></tr></thead><tbody>${(result.periods || []).map(row => `<tr><td>${escapeHtml(row.issue)}</td><td>${escapeHtml(row.draw_date)}</td><td><strong>${escapeHtml(row.draw_number)}</strong></td><td>${row.retained_count ?? '—'}个</td><td class="${row.covered ? 'status-pass':'status-fail'}">${row.covered == null ? '未评价' : row.covered ? '✓ 已留下开奖号' : '✕ 没有留下开奖号'}</td></tr>`).join('')}</tbody></table>${!result.periods?.length ? '<div class="empty-state">该页没有期级结果。</div>' : ''}<details class="technical"><summary>查看专业统计（Lift、Z-score、样本量）</summary><pre>Coverage: ${ratio(summary.coverage)}\nBaseline: ${ratio(summary.baseline)}\nLift: ${numberValue(summary.lift)}\nZ-score: ${numberValue(summary.z_score)}\n可评价期数: ${summary.evaluable ?? '—'}\n跳过期数: ${summary.skipped ?? '—'}\n回测记录ID: ${result.run.id}</pre></details>`;
}

async function loadReviews() {
  state.reviewPlan = null;
  $('#review-plan-status').textContent = '全部历史复盘；不表示属于当前方案。';
  const request = beginRequest('reviewList');
  state.requests.review = (state.requests.review || 0) + 1;
  $('#review-id').innerHTML = '';
  emptyView('#review-content', '正在读取当前彩种的复盘记录…');
  try {
    const allRows = await api('list_reviews');
    if (!currentRequest('reviewList', request)) return;
    const rows = allRows.filter(row => row.lottery_type === request.lottery);
    const names = {FC3D: '福彩3D', PL3: '排列3'};
    $('#review-id').innerHTML = rows.map(row => `<option value="${row.id}">${names[row.lottery_type] || row.lottery_type} 第${escapeHtml(row.issue)}期 · 开奖${row.draw_number} · ${row.covered ? '已覆盖':'未覆盖'}</option>`).join('');
    emptyView('#review-content', rows.length ? '请选择一条复盘记录后查看。' : '当前彩种没有已有复盘记录。');
    $('#review-query').disabled = !rows.length;
  } catch (error) { if (currentRequest('reviewList', request)) { emptyView('#review-content', errorMessage(error)); $('#review-query').disabled = true; toast(errorMessage(error)); } }
}

const fieldNames = {
  sum_tail: '和值尾', mod0_count: '0路个数', mod1_count: '1路个数', mod2_count: '2路个数',
  repeat_count: '重号个数', has_consecutive: '连号',
  sum_value: '和值', odd_count: '奇数个数', even_count: '偶数个数', big_count: '大号个数',
  small_count: '小号个数', span: '跨度', pattern: '号码类型', hundreds: '百位数字', tens: '十位数字', units: '个位数字',
};
const nodeNames = {root: '整体筛选条件', balance_tolerance: '号码平衡条件', exclude_baozi: '排除豹子', is_baozi: '豹子判断', sum_range: '和值范围'};

function describeRule(node) {
  const name = node.label || fieldNames[node.field] || nodeNames[node.node_id] || node.node_id || '规则';
  const actual = Array.isArray(node.actual) ? node.actual.join('、') : node.actual;
  const expected = Array.isArray(node.expected) ? node.expected.join('至') : node.expected;
  const descriptions = {
    between: `实际是 ${actual}，要求在 ${expected} 之间`,
    lte: `实际是 ${actual}，要求不大于 ${expected}`,
    gte: `实际是 ${actual}，要求不小于 ${expected}`,
    in: `实际是 ${actual}，允许值为 ${Array.isArray(node.expected) ? node.expected.join('、') : expected}`,
    eq: `实际是 ${actual}，要求等于 ${expected}`,
  };
  return {name, detail: descriptions[node.comparator] || `实际 ${actual ?? '—'}，要求 ${expected ?? '—'}`};
}

function visibleFailedRules(tree, result = []) {
  // A passing group (including OR/min_matches and NOT) cannot be the cause
  // of overall exclusion even if some descendants have stored FAIL traces.
  if (!tree || tree.status !== 'FAIL') return result;
  result.push(tree);
  if (tree.group_operator !== 'NOT') (tree.children || []).forEach(child => visibleFailedRules(child, result));
  return result;
}

function ruleNodes(tree) { return tree ? [tree, ...(tree.children || []).flatMap(ruleNodes)] : []; }

function describeFailure(node) {
  if (node.kind !== 'group') return describeRule(node);
  const name = node.label || `${node.group_operator || '条件'}条件组`;
  if (node.group_operator === 'NOT') return {name, detail: 'NOT组整体未通过：内部条件已通过，取反后为FAIL；不是内部条件失败。'};
  return {name, detail: `${node.group_operator || '条件'}组整体未通过：实际满足 ${node.matched_children ?? '—'} 项，要求至少 ${node.required_matches ?? '—'} 项。`};
}

function reviewReasons(result, review) {
  if (result.covered) return '<div class="reason-item"><span class="reason-icon status-pass">✓</span><div><strong>最终方案已覆盖开奖号</strong><p>整体组合条件通过；OR或容错组允许部分子条件未通过，并不代表所有单条规则都通过。</p></div></div>';
  const failed = visibleFailedRules(review.rule_tree);
  return failed.length ? failed.map(node => {
    const description = describeFailure(node);
    return `<div class="reason-item"><span class="reason-icon">×</span><div><strong>${escapeHtml(description.name)}没有通过</strong><p>${escapeHtml(description.detail)}</p><p>规则路径：${escapeHtml(node.rule_path)}</p></div></div>`;
  }).join('') : '<div class="reason-item"><div><strong>原记录为未覆盖</strong><p>没有可展示的失败节点，不能推断所有条件通过；请检查原始记录。</p></div></div>';
}

function counterfactualText(item, ruleTree) {
  const target = ruleNodes(ruleTree).find(node => node.rule_path === item.target_rule_path);
  const name = describeRule(target || {node_id:item.target_node_id}).name;
  if (item.operation === 'REMOVE_RULE') return `如果暂时取消“${name}”`;
  if (item.operation === 'EXPAND_NUMERIC_RANGE') {
    const before = item.change?.original_value?.join('–') || '原范围';
    const after = item.change?.new_value?.join('–') || '新范围';
    return `如果把“${name}”从 ${before} 放宽到 ${after}`;
  }
  if (item.operation === 'RELAX_MIN_MATCHES') return `如果把“${name}”要求减少1项`;
  return `如果调整“${name}”`;
}

async function queryReview() {
  await busy($('#review-query'), async () => {
    const request = beginRequest('review');
    const reviewId = Number($('#review-id').value);
    emptyView('#review-content', '正在读取已有复盘…');
    try {
    if (!Number.isInteger(reviewId) || reviewId <= 0) throw new Error('没有可查询的复盘记录。');
    const plan = state.reviewPlan;
    if (plan && (state.loadedPlan !== plan || plan.lottery_type !== state.lotteryType)) throw new Error('方案版本已切换，请重新读取匹配复盘。');
    const result = plan ? await api('plan_reviews', plan.plan_id, plan.revision, reviewId) : await api('review_details', reviewId);
    if (plan && (state.loadedPlan !== plan || state.reviewPlan !== plan)) return;
    if (!currentRequest('review', request) || Number($('#review-id').value) !== reviewId) return;
    if (result.lottery_type !== request.lottery || result.id !== reviewId) throw new Error('复盘结果与当前彩种或记录不匹配，已停止显示。');
    const payload = result.payload || {};
    const review = payload.rule_review || {};
    const counterfactual = payload.counterfactual_review || {};
    if ((review.overall_covered != null && review.overall_covered !== result.covered)
      || (review.rule_tree && (review.rule_tree.status === 'PASS') !== result.covered)) throw new Error('复盘整体状态与原记录不一致，已停止解释。');
    const reasonHtml = reviewReasons(result, review);
    const whatIfs = counterfactual.counterfactuals || [];
    const whatIfHtml = whatIfs.length
      ? whatIfs.map(item => `<div class="what-if ${item.covered ? 'covered':''}"><strong>${escapeHtml(counterfactualText(item, review.rule_tree))}</strong><p>${item.covered ? '✓ 调整后会覆盖实际开奖号' : '✕ 调整后仍不会覆盖实际开奖号'}；保留号码从 ${item.original_retained_count} 个变为 ${item.new_retained_count} 个（${item.delta_count >= 0 ? '+':''}${item.delta_count}）。</p></div>`).join('')
      : `<div class="what-if"><strong>没有假设调整记录</strong><p>${result.covered ? '已覆盖的期次不需要进行失败条件反事实检查。' : '该未覆盖记录没有已存储的反事实结果；本界面不会自动生成。'}</p></div>`;
    const traceHtml = ruleNodes(review.rule_tree).map(node => `<tr><td>${escapeHtml(node.rule_path)}</td><td>${escapeHtml(node.label || node.node_id)}</td><td>${escapeHtml(node.group_operator || '单条规则')}</td><td class="${node.status === 'PASS' ? 'status-pass' : 'status-fail'}">${escapeHtml(node.status)}</td></tr>`).join('');
    $('#review-content').innerHTML = `<div class="result-banner ${result.covered ? '' : 'missed'}"><div class="draw-ball">${escapeHtml(result.draw_number)}</div><div><h2>${result.covered ? '✓ 这一期被方案留下了' : '✕ 这一期没有被方案留下'}</h2><p>${result.lottery_type === 'FC3D' ? '福彩3D' : '排列3'} 第${escapeHtml(result.issue)}期 · ${escapeHtml(result.draw_date)}</p><p>${result.covered ? '实际开奖号位于当期保留号码集合中。' : '下面展示未通过组合及其失败分支，不表示每条单独移除都足以覆盖。'}</p></div></div><h3>为什么会这样？</h3><div class="reason-list">${reasonHtml}</div><h3>如果放宽条件，会发生什么？</h3><div class="what-if-grid">${whatIfHtml}</div><details class="technical"><summary>查看专业详情（规则路径、PASS/FAIL、Hash、原始记录）</summary><table><thead><tr><th>路径</th><th>规则</th><th>组合</th><th>原记录状态</th></tr></thead><tbody>${traceHtml}</tbody></table><pre>${escapeHtml(JSON.stringify({strategy:payload.input, source:payload.source, failed_rules:review.failed_rules, counterfactual_review:payload.counterfactual_review, report_hash:result.report_hash}, null, 2))}</pre></details>`;
    } catch (error) { if (currentRequest('review', request)) { emptyView('#review-content', errorMessage(error)); toast(errorMessage(error)); } }
  });
}

async function planBackupFile(restore) {
  $('#plan-backup-status').textContent = '备份文件等待校验；恢复禁止覆盖已有方案。';
  await busy($(restore ? '#plan-backup-restore' : '#plan-backup-verify'), async () => {
    if (state.planMutation) throw new Error('方案操作进行中，请稍后重试。');
    const file = $('#plan-backup-file').files[0];
    if (!file) throw new Error('请选择方案备份文件。');
    if (file.size > 6 * 1048576 + 1024) throw new Error('方案备份文件超出大小限制。');
    state.planMutation = true;
    try {
      const content = await file.text();
      const result = await api(restore ? 'restore_plan_backup' : 'verify_plan_backup', content);
      $('#plan-backup-status').textContent = `${restore ? '已恢复，请重新读取方案' : '备份校验通过'}：${result.name} · ${result.revision}个版本${result.deleted ? ' · 已删除状态' : ''} · 文件 SHA-256：${result.file_sha256}`;
      if (restore) await refreshPlans();
    } finally { state.planMutation = false; }
  });
}

async function backupSelectedPlan() {
  await busy($('#plan-backup'), async () => {
    const identifier = $('#plan-list').value || $('#plan-deleted').value;
    if (!identifier) throw new Error('请选择已存或已删除方案。');
    const result = await api('backup_plan', identifier);
    if (result) $('#plan-backup-status').textContent = `备份已保存：${result.path} · 文件 SHA-256：${result.file_sha256}`;
  });
}

function newPlan() {
  state.requests.planLoad = (state.requests.planLoad || 0) + 1;
  state.loadedPlan = null;
  $('#plan-name').value = '';
  $('#plan-status').textContent = '未保存草稿';
  resetWorkbench();
  selectSource('all');
  resetWorkbenchHistory();
}

async function refreshPlans() {
  await busy($('#plan-refresh'), async () => {
    const request = beginRequest('planList');
    const plans = await api('list_plans');
    const deleted = await api('list_plans', true);
    if (!currentRequest('planList', request)) return;
    state.deletedPlans = deleted;
    $('#plan-deleted').innerHTML = '<option value="">请选择已删除方案</option>' + deleted.map(plan =>
      `<option value="${escapeHtml(plan.plan_id)}">${escapeHtml(plan.name)} · 版本${plan.revision}</option>`).join('');
    $('#plan-list').innerHTML = '<option value="">请选择方案</option>' + plans.map(plan =>
      `<option value="${escapeHtml(plan.plan_id)}">${escapeHtml(plan.name)} · ${plan.lottery_type === 'FC3D' ? '福彩3D' : '排列3'}</option>`).join('');
  });
}

async function createPlan() {
  await busy($('#plan-create'), async () => {
    if (state.planMutation) throw new Error('方案操作进行中，请稍后重试。');
    if (state.loadedPlan) throw new Error('当前方案已保存，请点击“新建方案”后编辑新方案；可使用“覆盖保存”或“另存为新方案”。');
    const name = $('#plan-name').value.trim();
    if (!name) throw new Error('请输入方案名称。');
    const payload = buildPayload();
    if (payload.source === 'prediction' && state.predictionReady[state.lotteryType]) {
      payload.snapshot_source_hash = sourceVersion();
    }
    const revision = state.revision;
    const nameRevision = state.planNameRevision;
    const plan = await api('create_plan', name, payload, hasValidResult());
    if (revision === state.revision && nameRevision === state.planNameRevision && name === $('#plan-name').value.trim()) {
      state.loadedPlan = plan;
      $('#plan-status').textContent = `已保存：${plan.name} · 版本${plan.revision}`;
    }
    toast('新方案已保存到本机');
    await refreshPlans();
  });
}

async function changePlan(action) {
  await busy($(`#plan-${action}`), async () => {
    if (state.planMutation) throw new Error('方案操作进行中，请稍后重试。');
    const loaded = state.loadedPlan;
    const saved = action === 'restore'
      ? (state.deletedPlans || []).find(plan => plan.plan_id === $('#plan-deleted').value)
      : loaded;
    if (!saved) throw new Error(action === 'restore' ? '请选择已删除方案。' : '请先读取方案。');
    const name = $('#plan-name').value.trim();
    const saving = action === 'overwrite' || action === 'save-as';
    if (saving && !name) throw new Error('请输入方案名称。');
    const payload = saving ? buildPayload({savedPlan: saved}) : null;
    if (saving && payload.source === 'prediction' && state.predictionReady[state.lotteryType]) {
      payload.snapshot_source_hash = sourceVersion();
    }
    if (action === 'delete' && !window.confirm('删除当前方案？全部版本仍保留，可从已删除方案中恢复。')) return;
    const revision = state.revision;
    const nameRevision = state.planNameRevision;
    const loadRequest = beginRequest('planLoad');
    state.planMutation = true;
    try {
      const method = {overwrite:'overwrite_plan', 'save-as':'save_plan_as', delete:'delete_plan', restore:'restore_plan'}[action];
      const args = [saved.plan_id, saved.revision];
      if (saving) args.push(name, payload, hasValidResult());
      const plan = await api(method, ...args);
      const unchanged = loaded === state.loadedPlan && loadRequest.id === state.requests.planLoad;
      if (action === 'delete' && unchanged) {
        state.loadedPlan = null;
        invalidateResult('方案已删除；当前编辑保留为未保存草稿。');
        $('#plan-status').textContent = '方案已删除，可恢复；当前编辑为未保存草稿';
      } else if (saving && unchanged) {
        // Track the committed revision even if controls changed during the write.
        // The current controls remain a draft of that revision.
        state.loadedPlan = plan;
        $('#plan-status').textContent = `已保存：${plan.name} · 版本${plan.revision}` +
          (revision !== state.revision || nameRevision !== state.planNameRevision || name !== $('#plan-name').value.trim() ? ' · 当前编辑未保存' : '');
      }
      toast(action === 'restore' ? '方案已恢复，请重新读取' : action === 'delete' ? '方案已删除，可恢复' : '方案已保存到本机');
      await refreshPlans();
    } finally {
      state.planMutation = false;
    }
  });
}

async function loadPlan() {
  await busy($('#plan-load'), async () => {
    if (state.planMutation) throw new Error('方案操作进行中，请稍后读取。');
    const identifier = $('#plan-list').value;
    if (!identifier) throw new Error('请先选择已存方案。');
    const request = beginRequest('planLoad');
    invalidateResult('正在读取并重算方案，结果暂不可用。');
    const revision = state.revision;
    const nameRevision = state.planNameRevision;
    const draftName = $('#plan-name').value;
    const plan = await api('load_plan', identifier, true);
    if (!currentRequest('planLoad', request) || revision !== state.revision
      || nameRevision !== state.planNameRevision || draftName !== $('#plan-name').value
      || $('#plan-list').value !== identifier) return;
    setLottery(plan.lottery_type);
    state.loadedPlan = plan;
    $('#plan-name').value = plan.name;
    const form = plan.form;
    state.advancedRules = JSON.parse(JSON.stringify(form.advanced_rules || []));
    if (typeof renderAdvancedRules === 'function') renderAdvancedRules();
    // Saved schemas stay unchanged: reopen the actual allowed digits as 保留.
    state.digitModes = {hundreds:'keep',tens:'keep',units:'keep'};
    for (const position of ['hundreds', 'tens', 'units']) {
      state.digits[position] = new Set(form[position].split(/[ ,，]+/).filter(Boolean).map(Number));
    }
    renderPositionButtons();
    $$('input[name=pattern]').forEach(input => { input.checked = form.patterns.includes(input.value); });
    for (const prefix of ['sum', 'span']) {
      const range = form[`${prefix}_range`];
      $(`#${prefix}-enabled`).checked = range !== null;
      if (range) { $(`#${prefix}-min`).value = range[0]; $(`#${prefix}-max`).value = range[1]; }
    }
    Object.keys(featureFilters).forEach(key => {
      const value = (form.features || {})[key];
      $(`#feature-${key}-enabled`).checked = value !== undefined;
      if (value !== undefined) $(`#feature-${key}`).value = String(value);
    });
    $('#logic-select').value = form.logic;
    $('#min-matches').value = form.min_matches ?? 1;
    state.source = plan.source.kind;
    // Saved candidate snapshots are retained as evidence, never substituted
    // with today's prediction or activated before the later load audit.
    if (state.source === 'prediction') {
      state.predictionReady[state.lotteryType] = false;
      delete state.predictions[state.lotteryType];
      clearPredictionView('已读取候选来源快照，等待方案重算校验。');
      $('#prediction-source-count').textContent = '快照待校验';
    }
    $$('.source-option').forEach(button => button.classList.toggle('selected', button.dataset.source === state.source));
    updateConditionSummary();
    resetWorkbenchHistory();
    invalidateResult('已读取方案；保存的结果尚未重算校验。');
    const check = plan.load_check;
    if (check?.verified === true) {
      if (plan.source.kind === 'prediction') {
        state.predictionReady[state.lotteryType] = true;
        state.predictions[state.lotteryType] = {result_hash: plan.source.provenance_hash,
          candidate_count: plan.source.numbers.length, data_cutoff_issue: plan.source.cutoff_issue};
        $('#prediction-source-count').textContent = `${plan.source.numbers.length}个 · 已存快照`;
        clearPredictionView(`使用已存候选快照：截点${plan.source.cutoff_issue}，并非当前预测。`);
      }
      renderResult(check, {lottery_type: state.lotteryType, source: state.source,
        condition_id: conditionId(), data_version: sourceVersion(),
        data_cutoff_issue: plan.source.cutoff_issue, plan_id: plan.plan_id, plan_revision: plan.revision});
    }
    $('#plan-status').textContent = `已读取：${plan.name} · 版本${plan.revision} · ${check?.message || '缺少重算校验，结果不可用'}`;
  });
}

function calculateCostEstimate(counts, play, multiplier, budget) {
  if (!['direct', 'group3', 'group6'].includes(play)) throw new Error('请选择有效玩法。');
  if (!/^[0-9]{1,4}$/.test(multiplier) || Number(multiplier) < 1) throw new Error('倍数必须为1至9999的整数。');
  let budgetCents = null;
  if (budget !== '') {
    if (!/^[0-9]{1,9}(?:\.[0-9]{1,2})?$/.test(budget)) throw new Error('预算必须为0至999999999.99元，最多两位小数；留空表示不设置。');
    const [whole, fraction = ''] = budget.split('.');
    budgetCents = Number(whole) * 100 + Number(fraction.padEnd(2, '0'));
  }
  const count = counts?.[play];
  if (!Number.isInteger(count) || count < 0 || count > 1000) throw new Error('玩法注数不可用，请重新筛选。');
  const amountCents = count * 200 * Number(multiplier);
  return {count, amountCents, budgetCents, overBudget: budgetCents !== null && amountCents > budgetCents};
}

function updateCostEstimate() {
  const output = $('#cost-status');
  if (!output) return;
  output.style.color = '';
  if (!hasValidResult() || !state.playBetCounts) {
    output.textContent = '等待有效筛选结果';
    return;
  }
  try {
    const result = calculateCostEstimate(state.playBetCounts, $('#cost-play').value,
      $('#cost-multiplier').value, $('#cost-budget').value);
    const money = cents => `${Math.floor(cents / 100)}.${String(cents % 100).padStart(2, '0')}`;
    const budgetText = result.budgetCents === null ? '未设置预算'
      : result.overBudget ? `超出预算 ${money(result.amountCents - result.budgetCents)} 元，请调整倍数或号码`
      : `预算内，剩余 ${money(result.budgetCents - result.amountCents)} 元`;
    const exceedsSingleTicket = Number($('#cost-multiplier').value) > 99 || result.amountCents > 2000000;
    const ticketText = exceedsSingleTicket
      ? '；超过福彩3D单票倍数或金额上限，须分票研究；排列3销售限制需另行核实'
      : '';
    output.textContent = `${result.count} 注 × 2 元 × ${$('#cost-multiplier').value} 倍 = ${money(result.amountCents)} 元；${budgetText}${ticketText}；研究估算可跨多张彩票，预算内不代表符合实际出票规则`;
    if (result.overBudget || exceedsSingleTicket) output.style.color = 'var(--danger)';
  } catch (error) {
    output.textContent = error.message;
    output.style.color = 'var(--danger)';
  }
}

// Presentation catalogue only. These entries never generate AST or plan fields.
const pendingConditionHelp = [
  ['dan', '胆码', '不限定位置，统计一组数字出现几个。胆组0、2：002去重算2，按位计数算3；出现2是恰好2，不是至少2。', '任意胆组、计数模式和最多12组操作尚未接入。'],
  ['prime', '质合 · 网站约定', '网站把1、2、3、5、7归质，把0、4、6、8、9归合；107按此口径为质合质。', '与冻结M2质数2、3、5、7，合数4、6、8、9，0、1特殊不同；不能混用。'],
  ['sorted', '最数', '三个数字从小到大排序，重复保留，再取最小、中间、最大。770排序077，最小0、中间7、最大7。', '最数字段和完整桌面控件尚未接入。'],
  ['bigmiddle', '大中小', '小为0、1、2，中为3、4、5、6，大为7、8、9；527为中小大。', '与大小0–4/5–9不同，完整个数与排列控件尚未接入。'],
  ['pairSum', '两码和', '两个不同位置相加，范围0–18。527百十和7、百个和12、十个和9；227百十和4。', '原引擎有定位两码和字段，桌面选择及不定位组合尚未接入。'],
  ['pairTail', '两码和尾', '两码和取个位。527百十为7、百个为2、十个为9。', '定位与不定位多选及其组合尚未接入。'],
  ['pairDiff', '两码差', '两个位置数字相减取绝对值，范围0–9。527百十差3、百个差2、十个差5。', '原引擎有定位两码差字段，桌面完整控件尚未接入。'],
  ['pairCombined', '两码合差', '组合考察两码和尾与绝对差。527百十和尾7、差3。', '网站组合口径仍需核验，不能用近似规则代替。'],
  ['unordered', '不定位两码', '不看位置的两数字组合。527含25、27、57；22必须有两个2，不能只含一个2。', '完整两码选择、重复计数和组合尚未接入。'],
  ['direction', '走势', '与用户指定参考号码逐位置比较升、平、降。参考527，候选637为升、升、平。', '参考彩种、期号、号码和取得时点绑定尚未接入；历史回放不得引用最新开奖号。'],
  ['concave', '凹凸', '比较十位与两侧数字。527十位2低于两侧，是凹形示例。', '相等、组三与豹子边界仍需核验；暂不启用筛选。'],
];

function renderPendingConditionHelp() {
  const available = $('.more-conditions');
  if (available) available.open = true;
  const target = $('#pending-condition-list');
  if (!target) return;
  target.innerHTML = pendingConditionHelp.map(([key, title, example, limitation]) =>
    `<article class="pending-condition" id="condition-info-${key}" tabindex="-1"><div><h3>${escapeHtml(title)}</h3><span class="pending-badge">待适配 · 不参与筛选</span><p>${escapeHtml(limitation)}</p></div><aside class="condition-help"><strong>说明与例子</strong><p>${escapeHtml(example)}</p></aside></article>`).join('');
}

function selectConditionCategory(key) {
  const targets = {big:'#feature-big_count-enabled', odd:'#feature-odd_count-enabled',
    tail:'#feature-sum_tail-enabled', mod:'#feature-mod0_count-enabled',
    pair:'#shape-card', consecutive:'#feature-has_consecutive-enabled'};
  const pending = pendingConditionHelp.some(entry => entry[0] === key);
  const selector = pending ? `#condition-info-${key}` : targets[key];
  if (!selector) return false;
  const target = $(selector);
  if (!target) return false;
  const drawer = target.closest('details');
  if (drawer) drawer.open = true;
  const row = target.closest('.rule-row') || target;
  row.scrollIntoView({behavior:'smooth', block:'center'});
  // Navigation never silently enables a filter, invalidates results or calls M2.
  if (pending) target.focus({preventScroll:true});
  else if (target.matches('input, select, button')) target.focus({preventScroll:true});
  return true;
}

function filterToolbox() {
  const keyword = $('#tool-search').value.trim().toLocaleLowerCase();
  let matches = 0;
  $$('.toolbox .tool-grid').forEach(grid => {
    const buttons = [...grid.querySelectorAll('[data-tool], [data-category]'), ...grid.querySelectorAll('[data-extended-category]'), ...grid.querySelectorAll('[data-supplemental-category]')];
    buttons.forEach(button => {
      button.hidden = !button.textContent.toLocaleLowerCase().includes(keyword);
      if (!button.hidden) matches += 1;
    });
    grid.hidden = buttons.every(button => button.hidden);
    grid.previousElementSibling.hidden = grid.hidden;
  });
  $('#tool-search-empty').hidden = matches > 0;
}

function bindEvents() {
  $('#result-plan-verify')?.addEventListener('click',verifyWorkbenchPlan);
  renderPendingConditionHelp();
  if (typeof initializeAdvancedUI === 'function') initializeAdvancedUI();
  resetWorkbenchHistory();
  $('#undo-button')?.addEventListener('click', () => moveWorkbenchHistory(-1));
  $('#redo-button')?.addEventListener('click', () => moveWorkbenchHistory(1));
  $('#review-all').addEventListener('click', loadReviews);
  $('#review-plan').addEventListener('click', () => busy($('#review-plan'), async () => {
    const request = beginRequest('reviewList');
    state.requests.review = (state.requests.review || 0) + 1;
    state.reviewPlan = null;
    $('#review-id').innerHTML = '';
    $('#review-query').disabled = true;
    emptyView('#review-content', '正在核验方案关联复盘…');
    try {
      const plan = state.loadedPlan;
      if (!plan || plan.lottery_type !== state.lotteryType) throw new Error('请先保存或载入当前彩种的完整方案版本。');
      const rows = await api('plan_reviews', plan.plan_id, plan.revision);
      if (!currentRequest('reviewList', request) || state.loadedPlan !== plan) return;
      state.reviewPlan = plan;
      $('#review-id').innerHTML = rows.map(row => `<option value="${row.id}">第${escapeHtml(row.issue)}期 · 开奖${escapeHtml(row.draw_number)}</option>`).join('');
      $('#review-query').disabled = !rows.length;
      $('#review-plan-status').textContent = `已核验“${plan.name}”第 ${plan.revision} 版；${rows.length} 条匹配记录；当前未保存编辑不参与关联。`;
      emptyView('#review-content', rows.length ? '请选择匹配复盘后查看。' : '没有匹配记录。');
    } catch (error) {
      if (currentRequest('reviewList', request)) {
        $('#review-plan-status').textContent = errorMessage(error);
        emptyView('#review-content', errorMessage(error));
      }
    }
  }));
  ['#cost-play', '#cost-multiplier', '#cost-budget'].forEach(selector => $(selector).addEventListener('input', updateCostEstimate));
  $('#plan-name').addEventListener('input', () => {
    state.planNameRevision += 1;
    $('#plan-status').textContent = state.loadedPlan
      ? `已存方案：${state.loadedPlan.name} · 当前编辑未保存`
      : '未保存草稿';
  });
  for (const action of ['overwrite', 'save-as', 'delete', 'restore']) {
    $(`#plan-${action}`).addEventListener('click', () => changePlan(action));
  }
  $('#plan-new').addEventListener('click', newPlan);
  $('#plan-create').addEventListener('click', createPlan);
  $('#plan-refresh').addEventListener('click', refreshPlans);
  $('#plan-load').addEventListener('click', loadPlan);
  $('#plan-export').addEventListener('click', exportSavedPlan);
  $('#plan-backup').addEventListener('click', backupSelectedPlan);
  $('#plan-backup-verify').addEventListener('click', () => planBackupFile(false));
  $('#plan-backup-restore').addEventListener('click', () => planBackupFile(true));
  $('#plan-backup-file').addEventListener('change', () => {
    $('#plan-backup-status').textContent = '已选择新文件，等待校验。';
  });
  $$('.main-nav button').forEach(button => button.addEventListener('click', () => selectPage(button.dataset.page)));
  $$('.lottery-button').forEach(button => button.addEventListener('click', () => setLottery(button.dataset.lottery)));
  $$('.source-option').forEach(button => button.addEventListener('click', () => selectSource(button.dataset.source)));
  $$('input[name=pattern], #sum-enabled, #span-enabled').forEach(input => input.addEventListener('change', updateConditionSummary));
  Object.keys(featureFilters).forEach(key => {
    $(`#feature-${key}-enabled`).addEventListener('change', updateConditionSummary);
    $(`#feature-${key}`).addEventListener('change', updateConditionSummary);
  });
  $('#logic-select').addEventListener('change', updateConditionSummary);
  $$('#sum-min, #sum-max, #span-min, #span-max, #min-matches').forEach(input => input.addEventListener('input', updateConditionSummary));
  $('#evaluate-button').addEventListener('click', evaluate);
  $('#cancel-preview')?.addEventListener('click', cancelPreview);
  $('#copy-button').addEventListener('click', copyNumbers);
  $('#result-grouping').addEventListener('change', renderNumberView);
  $('#save-button').addEventListener('click', saveNumbers);
  $('#result-plan-save')?.addEventListener('click', openPlanSave);
  $('#tool-search').addEventListener('input', filterToolbox);
  $$('.toolbox [data-category]').forEach(button => button.addEventListener('click', () => selectConditionCategory(button.dataset.category)));
  $$('.toolbox [data-tool]').forEach(button => button.addEventListener('click', () => {
    const tool = button.dataset.tool;
    if (tool === 'reset') return resetWorkbench();
    if (tool === 'sum') $('#sum-enabled').checked = true;
    if (tool === 'span') $('#span-enabled').checked = true;
    if (tool === 'pattern') { $$('input[name=pattern]').find(input => input.value === 'group3').checked = true; $$('input[name=pattern]').find(input => input.value === 'group6').checked = true; }
    const target = tool === 'position' ? '#position-card' : tool === 'logic' ? '#logic-card' : '#shape-card';
    $(target).scrollIntoView({behavior:'smooth', block:'center'});
    updateConditionSummary();
  }));
  $('#prediction-button').addEventListener('click', generatePrediction);
  $('#prediction-count').addEventListener('change', () => {
    syncPredictionCount($('#prediction-count').value);
  });
  $('#prediction-to-workbench').addEventListener('click', () => { selectSource('prediction'); selectPage('workbench'); });
  $('#draws-filter').addEventListener('submit', event => {
    event.preventDefault();
    state.drawsFilters = {issue: $('#draws-issue').value.trim(), dateFrom: $('#draws-date-from').value, dateTo: $('#draws-date-to').value};
    state.drawsPage = 1;
    loadDraws();
  });
  $('#draws-reset').addEventListener('click', () => {
    for (const id of ['#draws-issue', '#draws-date-from', '#draws-date-to']) $(id).value = '';
    state.drawsFilters = {issue: '', dateFrom: '', dateTo: ''};
    state.drawsPage = 1;
    loadDraws();
  });
  $('#draws-export').addEventListener('click', exportDraws);
  $('#draws-refresh').addEventListener('click', loadDraws);
  $('#draws-prev').addEventListener('click', () => { if (state.drawsPage > 1) { state.drawsPage -= 1; loadDraws(); } });
  $('#draws-next').addEventListener('click', () => { if (state.drawsPage < state.drawsPages) { state.drawsPage += 1; loadDraws(); } });
  $('#position-query').addEventListener('click', queryPosition);
  $('#position-refresh')?.addEventListener('click',()=>busy($('#position-refresh'),()=>loadIssues()));
  $('#position-digit').addEventListener('change', renderPositionCharts);
  ['#position-issue', '#position-name'].forEach(selector => $(selector).addEventListener('change', () => {
    state.requests.position = (state.requests.position || 0) + 1;
    state.positionResult = null;
    emptyView('#position-charts', '目标期或位置已切换，请重新查询。');
    emptyView('#position-table', '目标期或位置已切换，请重新查询。');
  }));
  ['#backtest-save-input', '#backtest-bind-input'].forEach(selector => $(selector).addEventListener('click', () => busy($(selector), async () => {
    const plan = state.loadedPlan;
    if (!plan) throw new Error('请先保存或载入完整方案版本。');
    if(selector==='#backtest-bind-input'&&/^(local|prediction):/.test($('#backtest-run').value))throw new Error('本机方案检查是独立记录，无需关联原回测。');
    const runId = selector === '#backtest-bind-input' ? Number($('#backtest-run').value) : null;
    if (runId !== null && !runId) throw new Error('请选择历史回测记录。');
    const input = await api('save_backtest_input', plan.plan_id, plan.revision, runId);
    if (state.loadedPlan !== plan) return;
    $('#backtest-input-status').textContent = `已封存“${plan.name}”第 ${input.revision} 版 · 策略 Hash：${input.strategy_hash}${input.association ? ` · 核验关联历史记录 ${input.association.run_id}` : ' · 尚未执行回测'} · 输入标识：${input.input_id}`;
  })));
  $('#backtest-replay').addEventListener('click', replaySavedPlan);
  bindForecastHistory();
  $('#check-list-refresh')?.addEventListener('click',loadBacktests);
  $('#backtest-query').addEventListener('click', () => queryBacktest(1));
  $('#backtest-run').addEventListener('change', () => resetBacktest('回测记录已切换，请点击“查看结果”。'));
  ['#backtest-window', '#backtest-start', '#backtest-end'].forEach(selector => $(selector).addEventListener('change', () => {
    const custom = $('#backtest-window').value === 'custom';
    $('#backtest-start').disabled = !custom;
    $('#backtest-end').disabled = !custom;
    resetBacktest('统计范围已变更，请点击“查看结果”。');
  }));
  $('#backtest-prev').addEventListener('click', () => queryBacktest(state.backtestPage - 1));
  $('#backtest-next').addEventListener('click', () => queryBacktest(state.backtestPage + 1));
  $('#review-query').addEventListener('click', queryReview);
  $('#review-id').addEventListener('change', () => {
    state.requests.review = (state.requests.review || 0) + 1;
    emptyView('#review-content', '复盘记录已切换，请重新查看。');
  });
}

async function initialize() {
  makeDigitButtons();
  bindEvents();
  bindHome();
  $('#health-refresh')?.addEventListener('click', async () => {
    await refreshConnection();
    await loadDataHealth();
  });
  $('#update-preview')?.addEventListener('click', previewDataUpdate);
  $('#update-records-refresh')?.addEventListener('click', loadDataUpdateRecords);
  $('#update-candidates')?.addEventListener('input', () => {
    $('#update-preview-result').textContent = '候选已改变，请重新预览。';
  });
  updateConditionSummary();
  await refreshPlans();
  await loadDataHealth();
  await refreshConnection();
  await loadHome();
  await initializeOfficialSync();
  setTimeout(() => {
    $('.builder').scrollTop = 0;
    $('.result-panel').scrollTop = 0;
  }, 80);
}

window.addEventListener('pywebviewready', initialize);

async function refreshConnection() {
  const request = state.requests.connection = (state.requests.connection || 0) + 1;
  $('#connection-text').textContent = '正在连接本机数据…';
  $('.connection-state').style.color = 'var(--muted)';
  try {
    const info = await api('app_info');
    if (state.requests.connection !== request) return false;
    const staticOnly = info.connection.database === '仅离线选号';
    $('#connection-text').textContent = staticOnly ? '离线选号可用 · 历史数据未就绪' : `本机数据已就绪 · ${info.connection.database}`;
    $('.connection-state').style.color = staticOnly ? 'var(--muted)' : 'var(--green)';
    return true;
  } catch (error) {
    if (state.requests.connection !== request) return false;
    $('#connection-text').textContent = '本机数据不可用';
    $('.connection-state').style.color = 'var(--danger)';
    toast(errorMessage(error));
    return false;
  }
}

async function previewDataUpdate() {
  const target = $('#update-preview-result');
  const button = $('#update-preview');
  const lottery = state.lotteryType;
  const content = $('#update-candidates').value;
  button.disabled = true;
  target.textContent = '正在只读预览…';
  try {
    const result = await api('preview_data_update', lottery, content);
    if (state.lotteryType !== lottery || $('#update-candidates').value !== content) {
      target.textContent = '彩种或候选已改变，请重新预览。';
      return;
    }
    const summary = Object.entries(result.summary || {}).map(([label, count]) => `${escapeHtml(label)}：${escapeHtml(count)}`).join(' · ');
    target.innerHTML = `<p>${escapeHtml(result.lottery_type)} · 只读事务已回滚 · 实际更新 0 条</p><p>${summary}</p><p>${escapeHtml(result.notice)}</p>` + result.rows.map(row =>
      `<article class="control-card"><strong>${escapeHtml(row.issue)} · ${escapeHtml(row.action)}</strong><p>${escapeHtml(row.before_number || '无')} → ${escapeHtml(row.number)} · ${escapeHtml(row.draw_date)} · ${escapeHtml(row.status)}</p><p>来源：${escapeHtml(row.sources.join('、'))} · 观测核验：${escapeHtml(row.observation_status)}</p><p>${escapeHtml(row.conflict || '')}</p><p>${(row.review_guidance || []).map(escapeHtml).join('<br>')}</p></article>`).join('');
  } catch (error) {
    if (state.lotteryType !== lottery || $('#update-candidates').value !== content) {
      target.textContent = '彩种或候选已改变，请重新预览。';
      return;
    }
    target.textContent = `预览失败，结果不可用：${errorMessage(error)}`;
  } finally {
    button.disabled = false;
    if ($('#update-records')) await loadDataUpdateRecords();
  }
}

async function loadDataUpdateRecords() {
  const target = $('#update-records');
  if (!target) return;
  const lottery = state.lotteryType;
  target.textContent = '正在读取会话记录…';
  try {
    const result = await api('data_update_records', lottery);
    if (state.lotteryType !== lottery) return;
    target.innerHTML = `<p>${escapeHtml(result.notice)}</p>` + (result.records.length ? result.records.map(record =>
      `<article class="control-card"><strong>${record.status === 'preview_succeeded' ? '预览完成' : '预览失败'} · ${escapeHtml(record.lottery_type)}</strong><p>${escapeHtml(record.finished_at)} · 记录 ${escapeHtml(record.id)}</p><p>实际更新 0 条 · ${record.transaction === 'rolled_back' ? '只读事务已回滚' : record.transaction === 'not_started' ? '校验未通过，未开始事务' : '事务结束状态未确认，请维护人员核查'}</p><p>${escapeHtml(record.guidance || Object.entries(record.summary || {}).map(([label, count]) => `${label}：${count}`).join(' · '))}</p></article>`).join('') : '<p>本彩种暂无会话记录。</p>');
    target.innerHTML += '<p>原导入服务保存的失败记录（最近 50 条；不代表完整更新运行历史）</p>' +
      (result.saved_failure_status === 'unavailable' ? '<p>历史失败记录读取失败，请维护人员检查连接、权限和表结构；不能据此判断没有失败。</p>' :
        (result.saved_failures || []).map(row => `<article class="control-card"><strong>${row.issue_type === 'SOURCE_FETCH_FAILED' ? '来源获取失败' : '来源数据格式无效'} · ${row.resolved ? '已解决' : '待复核'}</strong><p>${escapeHtml(row.created_at)} · 期号 ${escapeHtml(row.issue || '未指定')} · 记录 ${escapeHtml(row.id)}</p><p>${escapeHtml(row.guidance)}</p></article>`).join('') || '<p>未找到已保存的来源失败记录；不代表更新成功。</p>');
  } catch (error) {
    if (state.lotteryType === lottery) target.textContent = '记录读取失败，请重新刷新。';
  }
}

async function loadDataHealth() {
  const target = $('#health-content');
  if (!target) return;
  target.textContent = '正在检查…';
  const button = $('#health-refresh');
  if (button) button.disabled = true;
  try {
    const result = await api('data_health');
    target.innerHTML = `<p>${result.status === 'ok' ? '检查通过' : '需要维护人员检查'}</p>` + result.checks.map(check =>
      `<article class="control-card"><strong>${escapeHtml(check.label)} · ${check.status === 'ok' ? '正常' : '需检查'}</strong><p>${escapeHtml(check.detail)}</p><p>${escapeHtml(check.guidance)}</p></article>`).join('');
  } catch (error) {
    target.textContent = `检查失败，摘要不可用。${errorMessage(error)} 请维护人员核对连接、权限及表结构后重试。`;
  } finally {
    if (button) button.disabled = false;
  }
}

function applyOfficialStatus(value) {
  state.syncEnabled = value?.enabled === true;
  if($('#official-check-interval'))$('#official-check-interval').disabled=!state.syncEnabled;
  for (const suffix of ['home', 'draws', 'health']) {
    const button = $(`#official-update-${suffix}`);
    if (button) button.disabled = !state.syncEnabled || value.running;
    const target = $(`#official-status-${suffix}`);
    if (target) {
      const record = value.lotteries?.[state.lotteryType];
      target.textContent = !state.syncEnabled ? (value.notice || '此入口未启用客户端更新。')
        : `${record?.message || '尚未检查官方公告。'}${record?.checked_at ? ` 最近检查：${record.checked_at}` : ''}${value.warning ? ` ${value.warning}` : ''}`;
    }
  }
  const changed = state.syncRevision !== null && state.syncRevision !== value.revision && state.syncEnabled;
  if (state.syncEnabled) state.syncRevision = value.revision;
  if (changed) {
    resetForwardForecasts('开奖数据已更新，正在对照此前留档。');
    resetForecastHistory('开奖数据已更新；已存八栏检验仍可查看，新检验请重新执行。');
    for (const name of ['prediction', 'home', 'draws', 'position', 'issues', 'planReplay', 'workbenchVerify']) state.requests[name] = (state.requests[name] || 0) + 1;
    if($('#backtest-replay-summary'))$('#backtest-replay-summary').innerHTML='';
    $('#backtest-replay-results').innerHTML='';
    $('#backtest-replay-status').textContent='开奖数据版本已更新，请重新验证已保存方案。';
    state.predictions = {};
    state.predictionReady = {FC3D:false, PL3:false};
    clearPredictionView(); clearHomePrediction();
    invalidateResult('开奖数据已更新，请重新生成候选或筛选；已存方案未被修改。');
    state.positionResult = null;
    emptyView('#position-charts', '开奖数据版本已更新，请重新查询目标期。');
    emptyView('#position-table', '开奖数据版本已更新，请重新查询目标期。');
    state.drawsPage = 1;
    const active = $('.page.active')?.id;
    if (active === 'page-draws') loadDraws();
    if (active === 'page-position') loadIssues({preserveSelection:true});
    if (active === 'page-home') loadHome();
    reconcileForwardAfterUpdate();
    toast('开奖与统计更新完成；旧候选已失效，请重新生成。');
  }
  return changed;
}

async function refreshOfficialStatus() {
  const request = ++state.syncRequest;
  try {
    const value = await api('local_update_status');
    if (request === state.syncRequest) applyOfficialStatus(value);
    return value;
  } catch (_) {
    if (request === state.syncRequest) {
      for (const suffix of ['home','draws','health']) {
        const target = $(`#official-status-${suffix}`);
        if (target) target.textContent = '更新状态暂不可读取，本地旧数据仍可使用。';
      }
    }
    return null;
  }
}

async function startOfficialCheck(lottery = state.lotteryType) {
  if (!state.syncEnabled) return;
  try {
    const result = await api('local_update_start', lottery);
    if (lottery === state.lotteryType && result.message) toast(result.message);
    await refreshOfficialStatus();
  } catch (error) { toast(errorMessage(error)); }
}

let officialCheckMinutes=15;
let officialScheduleTimer=null;
let officialScheduleGeneration=0;
let officialSchedulerReady=false;

function scheduleOfficialChecks() {
  clearTimeout(officialScheduleTimer);
  const generation=++officialScheduleGeneration;
  if(!officialSchedulerReady || !state.syncEnabled)return;
  officialScheduleTimer=setTimeout(async()=>{
    if(generation!==officialScheduleGeneration)return;
    await startOfficialCheck('FC3D');await startOfficialCheck('PL3');
    if(generation===officialScheduleGeneration)scheduleOfficialChecks();
  },officialCheckMinutes*60000);
}

function setOfficialCheckInterval(value) {
  const minutes=Number(value);
  if(![1,5,15].includes(minutes))return false;
  officialCheckMinutes=minutes;
  if($('#official-check-interval'))$('#official-check-interval').value=String(minutes);
  if($('#official-check-frequency'))$('#official-check-frequency').textContent=`运行期间每${minutes}分钟检查官方公告；官方公布与网络校验可能有延迟，关闭软件后停止检查。`;
  scheduleOfficialChecks();
  return true;
}

async function initializeOfficialSync() {
  $('#official-check-interval')?.addEventListener('change',()=>setOfficialCheckInterval($('#official-check-interval').value));
  for (const suffix of ['home','draws','health']) {
    $(`#official-update-${suffix}`)?.addEventListener('click', () => startOfficialCheck());
  }
  const value = await refreshOfficialStatus();
  await reconcileForwardAfterUpdate();
  if (!value?.enabled) return;
  // Network and construction run in the client worker, not the UI/bridge lock.
  await startOfficialCheck('FC3D');
  await startOfficialCheck('PL3');
  async function poll() {
    const status = await refreshOfficialStatus();
    setTimeout(poll, status?.running ? 1000 : 15000);
  }
  setTimeout(poll, 1000);
  officialSchedulerReady=true;
  scheduleOfficialChecks();
}
