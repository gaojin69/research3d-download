// Local, passive diagnostics only: no bridge calls, input values or UI changes.
(() => {
  'use strict';
  const pages = new Set(['home','prediction','workbench','draws','position','backtests','reviews','health']);
  const errors = new Set(['Error','TypeError','SyntaxError','ReferenceError','RangeError','URIError','EvalError','AggregateError']);
  const scripts = new Set(['app.js','advanced.js','condition_rows.js','diagnostics.js']);
  const events = [];
  let sequence = 0;
  const number = value => Number.isFinite(value) ? Math.round(Math.max(-1000000,Math.min(1000000,value))*10)/10 : null;
  const active = () => {
    const id = document.querySelector('.page.active')?.id || '';
    return pages.has(id.replace(/^page-/,'')) ? id.replace(/^page-/,'') : 'unknown';
  };
  function geometry(selector) {
    const el = document.querySelector(selector);
    if (!el) return {exists:false};
    const r = el.getBoundingClientRect(), s = window.getComputedStyle(el);
    const displays = ['none','block','inline','inline-block','flex','grid','contents'];
    return {exists:true,x:number(r.x),y:number(r.y),width:number(r.width),height:number(r.height),
      display:displays.includes(s.display)?s.display:'other',
      visibility:['visible','hidden','collapse'].includes(s.visibility)?s.visibility:'other'};
  }
  function capture(kind, fields={}) {
    try {
      events.push({kind,seq:++sequence,page:active(),...fields});
      if(events.length>8) events.shift();
    } catch (_) { /* Diagnostics must not break the application. */ }
  }
  window.addEventListener('error', event => {
    try {
      const file = String(event.filename || '').split(/[\\/]/).pop();
      capture('js_error',{error_type:errors.has(event.error?.name)?event.error.name:'UnknownError',
        script:scripts.has(file)?file:'unknown',line:number(event.lineno),column:number(event.colno)});
    } catch (_) { capture('js_error',{error_type:'UnknownError'}); }
  });
  window.addEventListener('unhandledrejection', event => {
    try { capture('promise_error',{error_type:errors.has(event.reason?.name)?event.reason.name:'UnknownError'}); }
    catch (_) { capture('promise_error',{error_type:'UnknownError'}); }
  });
  document.addEventListener('click', event => {
    try {
      const page = event.target.closest?.('.main-nav button[data-page]')?.dataset.page;
      if(!pages.has(page)) return;
      capture('nav_before',{target:page,shell:geometry('.app-shell')});
      setTimeout(() => {
        try { capture('nav_after',{target:page,shell:geometry('.app-shell')}); }
        catch (_) { capture('nav_after',{target:page}); }
      },250);
    } catch (_) { /* Never stop a navigation because observation failed. */ }
  },true);
  window.__localUiDiagnostics = Object.freeze({snapshot() {
    try {
      return {schema:1,sequence,page:active(),ready_state:document.readyState,
        viewport:{width:number(window.innerWidth),height:number(window.innerHeight)},
        scroll:{x:number(window.scrollX),y:number(window.scrollY),
          top:number(document.scrollingElement?.scrollTop),left:number(document.scrollingElement?.scrollLeft)},
        layout:Object.fromEntries([['shell','.app-shell'],['header','.titlebar'],['nav','.main-nav'],
          ['context','.context-row'],['main','main'],['page','.page.active']].map(([key,selector])=>[key,geometry(selector)])),
        events:JSON.parse(JSON.stringify(events))};
    } catch (_) { return {schema:1,sequence,page:'unknown',probe_error:true}; }
  }});
  capture('script_ready');
})();
