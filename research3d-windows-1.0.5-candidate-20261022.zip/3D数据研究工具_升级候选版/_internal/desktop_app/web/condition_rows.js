// Presentation adapter for the approved row-by-row layout. Uses the same V2
// clauses, M2 bridge, result context and local plan schema; no scoring here.
const conditionRowOrder = ['dan','size','parity','prime','sorted','sum','tail','span','cyclic',
  'pair','bigmiddle','mod','pairSum','pairTail','pairDiff','pairCombined','unordered','direction','concave'];
const extendedConditionRowKeys = () => Object.entries(advancedCatalog).filter(([,c])=>c.extended||c.supplemental).map(([key])=>key);
const rowLegacyFeatures={size:['big_count','small_count'],parity:['odd_count','even_count'],
  mod:['mod0_count','mod1_count','mod2_count'],tail:['sum_tail'],cyclic:['has_consecutive']};
let conditionRowsReady = false;
let conditionRowDrafts = [];
let conditionRowPending = '';
let conditionRowEditing = false;
let conditionRowSerial = 0;
const conditionRowElements = new Map();
const conditionRowFeatureElements = new Map();

function rowKeyForRule(rule) {
  if(!rule||typeof rule.type!=='string'||!rule.params||typeof rule.params!=='object')return undefined;
  return Object.entries(advancedCatalog).find(([,c])=>c.type===rule.type
    && (c.type!=='partition'||c.scheme===rule.params.scheme)
    && (c.type!=='values'||c.field===rule.params.field))?.[0];
}

function emptyRowDraft(key) {
  const c=advancedCatalog[key], params={};
  if(c.type==='dan') Object.assign(params,{digits:[],counts:[],count_mode:'distinct'});
  else if(c.type==='partition') Object.assign(params,{scheme:c.scheme,patterns:[]});
  else if(c.type==='direction') Object.assign(params,{reference:'',lottery_type:state.lotteryType,patterns:[]});
  else if(c.type==='sorted') Object.assign(params,{rank:'min',values:[]});
  else if(c.type==='values') Object.assign(params,{field:c.field,values:[]});
  else if(c.type.startsWith('pair_')) Object.assign(params,{pair:'ht',values:[]});
  else if(c.type==='unordered') Object.assign(params,{pairs:[],mode:'any'});
  else Object.assign(params,{values:[]});
  return {key,params,token:++conditionRowSerial};
}

function rowDraftRule(draft) {
  const c=advancedCatalog[draft.key], p=draft.params;
  if(!c) throw new Error('已存条件分类无法显示，请勿覆盖方案。');
  const selected=Object.values(p).filter(Array.isArray).some(v=>v.length);
  if(c.type==='direction' && (p.reference!=='' || selected)) {
    if(!/^[0-9]{3}$/.test(p.reference)||p.lottery_type!==state.lotteryType||!p.patterns.length) throw new Error('走势：请填写当前彩种三位手动参考号码并选择至少一种升降平形态，或清空该行。');
  }
  if(!selected) return null; // An empty row is explicitly not enabled.
  if(c.type==='dan' && (!p.digits.length||!p.counts.length)) throw new Error('胆码：请同时选择数字和恰好出现个数，或清空该胆组。');
  if(c.type==='direction' && (!/^[0-9]{3}$/.test(p.reference)||p.lottery_type!==state.lotteryType)) throw new Error('走势：请选择当前彩种并填写三位手动参考号码，例如007。');
  return {type:c.type,params:JSON.parse(JSON.stringify(p))};
}

function deriveRowRules(drafts) {
  const rules=drafts.map(rowDraftRule).filter(Boolean);
  if(rules.length>32) throw new Error('最多启用32项分类条件，请清除多余条件。');
  if(rules.filter(r=>r.type==='dan').length>12) throw new Error('胆码最多12组。');
  return rules;
}

function conditionRowsSnapshot() {
  return conditionRowsReady ? JSON.parse(JSON.stringify(conditionRowDrafts.map(({key,params})=>({key,params})))) : null;
}
function unmappedRowsError() {
  return state.advancedRules.some(rule=>rule.type!=='forecast'&&!rowKeyForRule(rule)) ? '已存条件无法在当前界面完整显示，请勿覆盖；请保留原方案或明确新建。' : '';
}
function conditionRowsError() { return conditionRowsReady ? unmappedRowsError()||conditionRowPending : ''; }

function fillRowControls(draft, root) {
  for(const [key,value] of Object.entries(draft.params)) {
    if(Array.isArray(value)) $$(`[data-adv="${key}"]`,root).forEach(input=>{input.checked=value.map(String).includes(input.value);});
    else {
      const input=$(`[data-row-field="${key}"]`,root);
      if(input) input.value=value;
    }
  }
}

function rowFieldMarkup(draft) {
  // Reuse the existing Chinese field/options factory. It only opens an editor;
  // it never mutates conditions or computes numbers. Give every clone unique IDs.
  openAdvancedCategory(draft.key,false);
  return $('#advanced-fields').innerHTML.replace(/id="adv-([^"]+)"/g,(_,suffix)=>`id="row-${draft.token}-${suffix}" data-row-field="${suffix}"`)
    .replace(/for="adv-([^"]+)"/g,(_,suffix)=>`for="row-${draft.token}-${suffix}"`);
}

function rowQuickMarkup(draft) {
  const c=advancedCatalog[draft.key];
  if(c.type!=='partition') return '';
  if(['size','parity','site_prime'].includes(c.scheme)) {
    const positive={size:'B',parity:'O',site_prime:'P'}[c.scheme];
    const label={size:'大号',parity:'单号',site_prime:'网站质'}[c.scheme];
    return `<div class="row-shortcuts"><span>不定位个数：</span>${advancedRange(3).map(n=>`<button type="button" data-row-count="${n}" data-row-symbol="${positive}">恰好${n}个${label}</button>`).join('')}</div>`;
  }
  return '';
}

function renderRowDrafts(keys=[...conditionRowOrder,...extendedConditionRowKeys()]) {
  if(!conditionRowsReady) return;
  for(const key of keys.filter(k=>k!=='pair')) {
    const container=conditionRowElements.get(key)?.controls || $(`#row-controls-${key}`);
    container.innerHTML=conditionRowDrafts.filter(d=>d.key===key).map((draft,index)=>
      `<div class="inline-clause" data-inline-token="${draft.token}" data-inline-key="${key}"><div class="row-clause-heading"><strong>${key==='dan'?'胆组':'条件'} ${index+1}</strong><div><button type="button" data-row-all>全选取值</button><button type="button" data-row-clear>清空</button><button type="button" data-row-remove>移除此条</button></div></div>${rowQuickMarkup(draft)}${rowFieldMarkup(draft)}</div>`).join('');
    for(const draft of conditionRowDrafts.filter(d=>d.key===key)) fillRowControls(draft,$(`[data-inline-token="${draft.token}"]`,container));
  }
  updateConditionRowBadges();
}

function syncConditionRows() {
  if(!conditionRowsReady||conditionRowEditing) return;
  conditionRowPending='';
  conditionRowDrafts=state.advancedRules.filter(rule=>rule.type!=='forecast').map(rule=>{
    const key=rowKeyForRule(rule);
    if(!key) { conditionRowPending='已存条件无法在当前界面完整显示，请勿覆盖；仍可导出原方案。'; return null; }
    return {key,params:JSON.parse(JSON.stringify(rule.params)),token:++conditionRowSerial};
  }).filter(Boolean);
  for(const key of conditionRowOrder.filter(k=>k!=='pair')) if(!conditionRowDrafts.some(d=>d.key===key)) conditionRowDrafts.push(emptyRowDraft(key));
  renderRowDrafts();
}

function restoreConditionRows(snapshot) {
  if(!conditionRowsReady) return;
  if(!snapshot) {syncConditionRows();return;}
  conditionRowDrafts=JSON.parse(JSON.stringify(snapshot)).map(d=>({...d,token:++conditionRowSerial}));
  conditionRowPending='';
  try { deriveRowRules(conditionRowDrafts); } catch(error) { conditionRowPending=error.message; }
  renderRowDrafts();
}

function updateConditionRowBadges() {
  if(!conditionRowsReady) return;
  renderConditionDescription();
  const total=conditionCount();
  $('#condition-count').textContent=`${total}项`;
  $('#summary-conditions').textContent=`${total}项`;
  $('#min-matches').max=String(Math.max(1,total));
  for(const key of [...conditionRowOrder,...extendedConditionRowKeys()]) {
    const badge=conditionRowElements.get(key)?.badge || $(`#row-status-${key}`);
    if(!badge) continue;
    let count=0, incomplete=false;
    if(key==='pair') count=$$('input[name=pattern]:checked').length?1:0;
    else for(const d of conditionRowDrafts.filter(d=>d.key===key)) {
      try {if(rowDraftRule(d))count++;} catch(_) {incomplete=true;}
    }
    if(key==='sum'&&$('#sum-enabled').checked) count++;
    if(key==='span'&&$('#span-enabled').checked) count++;
    count+=(rowLegacyFeatures[key]||[]).filter(field=>(conditionRowFeatureElements.get(field)||$(`#feature-${field}-enabled`)).checked).length;
    badge.textContent=incomplete?'未填完整':count?`已启用 ${count}项`:'未启用';
    badge.classList.toggle('enabled',count>0&&!incomplete);
  }
  const status=$('#row-draft-status');
  if(status) status.textContent=conditionRowsError()||'空白行不限制号码；点选后自动预览。一个胆组或形态多选行算一项。';
  const summary=$('#row-condition-summary');
  if(summary) summary.textContent=$('#condition-description').textContent;
}

function commitRowDrafts() {
  conditionRowPending='';
  try {
    if(unmappedRowsError())throw new Error(unmappedRowsError());
    const rules=[...state.advancedRules.filter(rule=>rule.type==='forecast'),...deriveRowRules(conditionRowDrafts)];
    if(rules.length>32)throw new Error('最多启用32项条件（包括AI预测快照）。');
    if(rules.filter(r=>r.type==='dan'||r.type==='forecast'&&r.params.section==='dan').length>12)throw new Error('胆码最多12组（包括AI独胆快照）。');
    state.advancedRules=rules;
  } catch(error) {conditionRowPending=error.message;}
  conditionRowEditing=true;
  try {renderAdvancedRules(); updateConditionSummary();} finally {conditionRowEditing=false;}
  updateConditionRowBadges();
}

function readRowDraft(draft,root) {
  for(const [key,previous] of Object.entries(draft.params)) {
    if(Array.isArray(previous)) {
      const numeric=['digits','counts','values'].includes(key)&&advancedCatalog[draft.key].type!=='shape';
      draft.params[key]=$$(`[data-adv="${key}"]:checked`,root).map(input=>numeric?Number(input.value):input.value);
    } else if(key==='lottery_type') draft.params[key]=state.lotteryType;
    else {
      const input=$(`[data-row-field="${key}"]`,root);
      if(input) draft.params[key]=input.value;
    }
  }
}

function openConditionRow(key) {
  if(!conditionRowsReady) return false;
  const aliases={position:'position-card',pattern:'row-pair',pair:'row-pair',logic:'logic-card',
    big:'row-size',odd:'row-parity',consecutive:'row-cyclic'};
  const id=aliases[key]||`row-${key}`;
  const target=$(`#${id}`); if(!target) return false;
  if(extendedConditionRowKeys().includes(key)) {
    if(!conditionRowDrafts.some(d=>d.key===key)) {conditionRowDrafts.push(emptyRowDraft(key));renderRowDrafts([key]);}
    if($('.extended-rows')) $('.extended-rows').open=true;
  }
  target.open=true;target.scrollIntoView?.({behavior:'smooth',block:'start'});
  return true;
}

function initializeConditionRows() {
  const root=$('#condition-rows');if(conditionRowsReady||!root) return;
  root.innerHTML=conditionRowOrder.map(key=>{
    const c=key==='pair'?{name:'成对',help:'豹子三位相同，组三恰有两位相同，组六三位不同。选择多个类型取并集。'}:advancedCatalog[key];
    return `<details class="condition-row" id="row-${key}" ${['dan','size','parity','sum','span','pair'].includes(key)?'open':''}><summary><strong>${c.name}</strong><span class="row-enable-badge" id="row-status-${key}">未启用</span></summary><div class="condition-row-body"><div class="condition-row-controls"><div id="row-controls-${key}"></div>${key==='pair'?'':`<button type="button" data-row-add="${key}">＋ 增加${key==='dan'?'胆组':'一条条件'}</button>`}<div id="row-legacy-${key}"></div></div><aside class="condition-help"><strong>说明与例子</strong><p>${escapeHtml(c.help)}</p>${key==='dan'?'<p class="row-warning">出现2表示恰好2，不是至少2。最多12组。</p>':''}</aside></div></details>`;
  }).join('')+'<p id="row-draft-status" role="status"></p>';
  const extendedRoot=$('#extended-condition-rows');
  if(extendedRoot) extendedRoot.innerHTML=extendedConditionRowKeys().map(key=>{
    const c=advancedCatalog[key];
    return `<details class="extended-condition-row" id="row-${key}"><summary><strong>${escapeHtml(c.name)}</strong><span class="row-enable-badge" id="row-status-${key}">未启用</span></summary><div class="condition-row-body"><div class="condition-row-controls"><div id="row-controls-${key}"></div><button type="button" data-row-add="${key}">＋ 增加一条条件</button></div><aside class="condition-help"><strong>说明与例子</strong><p>${escapeHtml(c.help)}</p></aside></div></details>`;
  }).join('');
  // Move real existing controls, never clone IDs or replace their event handlers.
  $('#row-controls-pair').append($('#shape-card .rule-row'));
  $('#row-legacy-sum').append($('#sum-enabled').closest('.rule-row'));
  $('#row-legacy-span').append($('#span-enabled').closest('.rule-row'));
  for(const [key,fields] of Object.entries(rowLegacyFeatures)) {
    for(const field of fields) $(`#row-legacy-${key}`).append($(`#feature-${field}-enabled`).closest('.rule-row'));
  }
  $('.more-conditions > summary').textContent='其他原有条件：重号个数 · 保留旧方案';
  $('#feature-card header').textContent='原有重号条件';
  $('#shape-card').hidden=true;$('#advanced-editor').hidden=true;
  $('.more-conditions').open=false;
  // Arrange the real existing category buttons in the approved 4×5 order.
  // Keep legacy combination/reset shortcuts in a separate tools disclosure.
  const grid=$('.toolbox .tool-grid');
  const catalogue=['position','dan','big','odd','prime','sorted','sum','tail','span','consecutive',
    'pair','bigmiddle','mod','pairSum','pairTail','pairDiff','pairCombined','unordered','direction','concave'];
  const buttons=$$('.toolbox [data-tool], .toolbox [data-category]');
  for(const key of catalogue) {
    const button=buttons.find(b=>b.dataset.tool===key||b.dataset.category===key);
    if(button){grid.append(button);if(key==='position')button.textContent='定位';if(key==='sum')button.textContent='和值';if(key==='span')button.textContent='跨度';}
  }
  $$('.toolbox .tool-grid').filter(g=>g!==grid&&g!==$('#extended-condition-tools')&&g!==$('#supplemental-condition-tools')).forEach(g=>{g.hidden=true;});
  const tools=document.createElement('details');tools.className='catalog-extra-tools';
  tools.innerHTML='<summary>组合与重置工具</summary>';
  buttons.filter(b=>['pattern','logic','reset'].includes(b.dataset.tool)).forEach(b=>tools.append(b));
  $('.toolbox').append(tools);
  $('.toolbox > p').textContent='点击分类定位到对应行；直接勾选取值。空白行不限制号码，每项旁边都有说明。';
  for(const key of [...conditionRowOrder,...extendedConditionRowKeys()]) {
    conditionRowElements.set(key,{controls:$(`#row-controls-${key}`),badge:$(`#row-status-${key}`)});
  }
  for(const field of Object.values(rowLegacyFeatures).flat())conditionRowFeatureElements.set(field,$(`#feature-${field}-enabled`));
  conditionRowsReady=true;syncConditionRows();
  const changed=event=>{
    if(event.type==='input'&&event.target.type==='checkbox')return;
    const row=event.target.closest('[data-inline-token]');if(!row)return;
    const draft=conditionRowDrafts.find(d=>d.token===Number(row.dataset.inlineToken));
    if(draft){readRowDraft(draft,row);commitRowDrafts();}
  };
  for(const eventRoot of [root,extendedRoot].filter(Boolean)) {
  eventRoot.addEventListener('change',changed);
  eventRoot.addEventListener('input',changed);
  eventRoot.addEventListener('click',event=>{
    const add=event.target.closest('[data-row-add]');
    if(add){
      const key=add.dataset.rowAdd;
      if(conditionRowDrafts.length>=50+extendedConditionRowKeys().length || conditionRowDrafts.filter(d=>d.key===key).length>=(key==='dan'?12:32)) {toast('该分类已达到允许条数，请先移除多余条目。');return;}
      conditionRowDrafts.push(emptyRowDraft(key));renderRowDrafts([key]);recordWorkbenchHistory();return;
    }
    const row=event.target.closest('[data-inline-token]');if(!row)return;
    const draft=conditionRowDrafts.find(d=>d.token===Number(row.dataset.inlineToken));if(!draft)return;
    if(event.target.closest('[data-row-remove]')) {
      conditionRowDrafts=conditionRowDrafts.filter(d=>d!==draft);
      if(!conditionRowDrafts.some(d=>d.key===draft.key))conditionRowDrafts.push(emptyRowDraft(draft.key));
      renderRowDrafts([draft.key]);commitRowDrafts();return;
    }
    const clear=event.target.closest('[data-row-clear]'), all=event.target.closest('[data-row-all]'), shortcut=event.target.closest('[data-row-count]');
    if(!clear&&!all&&!shortcut)return;
    if(clear||all) $$('input[type=checkbox]',row).forEach(input=>{input.checked=!!all;});
    if(clear&&draft.key==='direction') $('[data-row-field="reference"]',row).value='';
    if(shortcut) $$('[data-adv="patterns"]',row).forEach(input=>{input.checked=[...input.value].filter(c=>c===shortcut.dataset.rowSymbol).length===Number(shortcut.dataset.rowCount);});
    readRowDraft(draft,row);commitRowDrafts();
  });
  }
  $('.toolbox [data-category="pair"]')?.addEventListener('click',event=>{event.stopImmediatePropagation();openConditionRow('pair');},true);
  $$('.toolbox [data-tool]').forEach(button=>button.addEventListener('click',event=>{
    if(['position','sum','span','pattern','logic'].includes(button.dataset.tool)) {
      // New row navigation does not silently enable old shortcut conditions.
      event.stopImmediatePropagation();openConditionRow(button.dataset.tool);
    }
  },true));
  $('#nav-plans')?.addEventListener('click',event=>{event.preventDefault();selectPage('workbench');$('.plan-drawer').open=true;$('.plan-drawer').scrollIntoView?.({behavior:'smooth',block:'start'});});
  for(const position of ['hundreds','tens','units']) {
    const caption=$(`[data-digit-mode="${position}"]`).parentElement;
    const button=document.createElement('button');button.type='button';button.textContent='全选';
    button.addEventListener('click',()=>{state.digits[position]=new Set(advancedRange(9));renderPositionButtons();updateConditionSummary();});
    caption.append(button);
  }
  const panel=$('.result-panel');const summary=document.createElement('div');
  summary.className='result-condition-summary';summary.innerHTML='<strong>当前条件汇总</strong><p id="row-condition-summary"></p>';
  panel.append(summary);
}
